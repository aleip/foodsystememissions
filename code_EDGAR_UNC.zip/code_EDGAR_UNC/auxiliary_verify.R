loadRData <- function(fileName){
  # copied from http://stackoverflow.com/questions/5577221/how-can-i-load-an-object-into-a-variable-name-that-i-specify-from-an-r-data-file 
  #loads an RData file, and returns it
  load(fileName)
  get(ls()[ls() != "fileName"])
} # end function

#----------------------------------------------------------------------
cat <- c('1' = 'Energy',    
         '1A'= 'Energy - fuel combustion', 
         '1B'= 'Energy - fugitive emission from fuels',
         '1B1'='Energy - fugitive emission from fuels - Solid fuels',           #*
         '1B2'='Energy - fugitive emission from fuels - Oil and natural gas',   #*
         '1A1' = 'Energy industries', 
         '1A2' = 'Manifacturing Industries',
         '1A3' = 'Transport',
         '2'=  'Industrial processes and product use', 
         '3'=  'Agricolt, forest,  land use',
         '3A' = 'Livestock',
         '3A1'= 'Agricolture - Live stock - Enteric fermentation',              #*
         '3A2'= 'Agricolture - Live stock - Manure management',                 #*
         '3C7'='Agricolture - Rice cultivation',                                #*
         '4'  =  'Waste', 
         '4A' = 'Waste - Solid waste disposal',                                 #*
         '4D' = 'Waste - Wastewater treatment and discharge',                   #*
         '5'  = 'Other',
        
         '1.A'  = 'Energy - fuel combustion', 
         '1.B'  = 'Energy - fugitive emission from fuels',
         '1.B.1'= 'Energy - fugitive emission from fuels - Solid fuels',         #*
         '1.B.2'= 'Energy - fugitive emission from fuels - Oil and natural gas', #*
         '3.A'  = 'Livestock',
         '3.A.1'= 'Agricolture - Live stock - Enteric fermentation',            #*
         '3.A.2'= 'Agricolture - Live stock - Manure management',               #*
         '3.C.7'= 'Agricolture - Rice cultivation',                             #*
         '4.A'  = 'Waste - Solid waste disposal',                               #*
         '4.D'  = 'Waste - Wastewater treatment and discharge',
         '2.B'  = 'Chemical industry',
         '3.C.4'= 'Direct N2O from managed soils',  
         '3.C.5'= 'indirect N2O from managed soils',
         '3.C.6'= 'Indirect N2O from Manure Management',
         '5.A'  = 'Indirect N2O from deposition of Nox and NH3'   ,             #*
         '1.A.1' = 'Energy industries', 
         '1.A.2'=  'Manifacturing Industries',
         '1.A.3'=  'Transport',
         
         'AGS' = 'Agricoltural soils', 
         'AWB' = 'Agricoltural waste burning', 
         'CHE' = 'Production of chemicals', 
         'ENE' = 'Power industry', 
         'ENF' = 'Enteric fermentation', 
         'IND' = 'Manifacturing industry',
         'RCO' = 'Residential',
         'REF' = 'Oil refinery',
         'TRF' = 'Tranformation industry', 
         'SWD' = 'Solid waste disposal', 
         'IRO' = 'Production of Iron and Steel',
         'MNM' = 'MAnure management', 
         'PRO' = 'Fuel production_transmission', 
         'TNR' = 'Non-road transport' , 
         'TRO' = 'Road transport', 
         'WWT' = 'waste water'          )




f.get_emi_cat <- function(emi.cat){
  #  emi.cat<-c( '1A', '1B1','1B2', '2', '3A',  '3C7', '4A', '4D') 
 # 3.A.2
  s.emi <- as.character(cat[ names(cat) %in% emi.cat ])
  return(s.emi)
  
}
#-----------------------------------------------------------------------
f.get_emi_cat_vector <- function(emi.cat){ # string of values
  s.emi<- NULL
  for (k in 1:length(emi.cat)){
    s.emi <- c(s.emi, as.character(cat[ names(cat) %in%  emi.cat[k]     ]))
  }
  return(s.emi)
}





