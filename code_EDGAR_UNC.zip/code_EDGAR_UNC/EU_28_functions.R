
f.aggregate.EU28.country <- function(hold.g, bCorr){
  emi.EU28 <- hold.g %>% group_by(country) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                                         emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, bCorr), # FALSE = correlated
                                                         emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, bCorr) )
  
  
  
  # emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
  #                                  emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
  #                                 emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )
  
  names(emi.EU28) <- c('category', 'emi.tot.cat','unc.emi.cat.min', 'unc.emi.cat.max' )
  
  # names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.EU28, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  for (i in 1:length(CI.range.cat)/2){
    emi.EU28[i,5] <- emi.EU28$emi.tot.cat[i]*(1-abs(CI.range.cat[i]))#/1000
    emi.EU28[i,6] <- emi.EU28$emi.tot.cat[i]*(1+CI.range.cat[i+10])#/1000
  } 
  emi.EU28$country <- 'EU28'
  emi.EU28$emi.tot.cat <- emi.EU28$emi.tot.cat#/1000
  # ****
  
  return(emi.EU28)
  
} # end function


f.aggregate.EU28 <- function(hold.g, bCorr){
  emi.EU28 <- hold.g %>% group_by(cat) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                           emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, bCorr), # FALSE = correlated
                                           emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, bCorr) )
  
  
  
  # emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
  #                                  emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
  #                                 emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )
  
  names(emi.EU28) <- c('category', 'emi.tot.cat','unc.emi.cat.min', 'unc.emi.cat.max' )
  
  # names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  for (i in 1:length(emi.EU28$category)){
    min.tmp <- f.asymmetric_unc(emi.EU28$unc.emi.cat.min[i], emi.EU28$unc.emi.cat.max[i], emi.EU28$emi.tot.cat[i])[1] 
    max.tmp <- f.asymmetric_unc(emi.EU28$unc.emi.cat.min[i], emi.EU28$unc.emi.cat.max[i], emi.EU28$emi.tot.cat[i])[2] 
    
    emi.EU28[i,5] <- emi.EU28$emi.tot.cat[i]*(1-abs(min.tmp))
    emi.EU28[i,6] <- emi.EU28$emi.tot.cat[i]*(1+max.tmp)
    min.tmp<-NULL; max.tmp<-NULL
  }
  
#  CI.range.cat      <- with(emi.EU28, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
#  for (i in 1:length(CI.range.cat)/2){
#    emi.EU28[i,5] <- emi.EU28$emi.tot.cat[i]*(1-abs(CI.range.cat[i]))#/1000
#    emi.EU28[i,6] <- emi.EU28$emi.tot.cat[i]*(1+CI.range.cat[i+10])#/1000
#  } 
  emi.EU28$country <- 'EU28'
  emi.EU28$emi.tot.cat <- emi.EU28$emi.tot.cat#/1000
  # ****
  
  return(emi.EU28)
  
} # end function



f.find_unc_EU28 <- function(uTable, proc) { # uTable is available from the main program (t.hold)
  
  idx <- NULL
  #    proc <- substring(proc0, 1,11)
  
#  proc <- 'RCO.AGR.DIE'
#  uTable <- loadRData(file=paste0(proc.dir,sUncCorr,'unc.table.Rdata'))
  
  #   proc.x <- substring(uTable$process,1,11)
 #  if(now_run == 'CO2' & b.cat=='Margarita'){ #defined by edgar processes # original
    if( b.cat=='Margarita' | b.cat == 'EDGAR'){ 
    u.row <- uTable[ which(substring(uTable$processes,1,11)==proc),]
  } else { # defined by IPCC codes
    u.row <- uTable[ which(substring(uTable$ipcc06,1,5)==proc & !grepl('x$', uTable$ipccX) ),]
  }
  if (dim(u.row)[1]==0){
    unc.min <- NA ; unc.max <- NA
    ipcc06  <- NA ; ipccX   <- NA
  } else if (dim(u.row)[1]>=1){
    idx <- min(which(!is.na(u.row$unc.min)))
    unc.min <- u.row$unc.min[idx] # [1] corresponds to austria
    unc.max <- u.row$unc.max[idx]
    
    ipcc06 <- u.row$ipcc06[idx]
    ipccX  <- u.row$ipccX[idx]
  }
  return(c(unc.min, unc.max, ipcc06, ipccX))
} 
#*********************************************
f.cat_for_EU28 <- function(summary_unc,aFlag){
  # from 'aggregate for CHE' function
  
  g1 <- list()
  ## 1. aggregate by sector, for each country
  emi.keys <- paste0('^', emi.keys.0 ) 

    kempty <- NULL
    for (k in 1:length(emi.keys)){
      #  if(length(grep(emi.keys[k], unc.table$ipcc06)) >=1){
      if (emi.keys.0[k] == 'TNR.AIR') emi.keys[k] <- emi.keys[k] <- paste(c('^TNR.DAT','^TNR.IAT'), collapse="|")
      if (emi.keys.0[k] == 'REF_TRF') emi.keys[k] <- paste(c('^REF','^TRF'), collapse="|")
      if (emi.keys.0[k] == 'PRU_SOL') emi.keys[k] <- paste(c('^PRU','^SOL'), collapse="|")
      if(dim(subset(summary_unc,  grepl(emi.keys[k], processes)))[1] ==0)  {
        kempty <- c(kempty,k)
        next()}
#    }
  
    if(aFlag==T){
    
   g1[[k]] <- summary_unc %>%   subset(  grepl(emi.keys[k], processes)) %>%  
      summarise(emi.cat.country  = sum(emi, na.rm=T),
                emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), rep(TRUE,length(summary_unc$emi)), as.logical(xFlag)),
                emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), rep(TRUE,length(summary_unc$emi)), as.logical(xFlag)))
#    g1[[k]] <- summary_unc[grepl(emi.keys[k], summary_unc$processes),] %>%  
#      summarise(emi.cat.country  = sum(emi, na.rm=T),
#                emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
#                emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
    } else {

      g1[[k]] <- summary_unc %>%   subset(  grepl(emi.keys[k], processes)) %>%  
        summarise(emi.cat.country  = sum(emi, na.rm=T),
                  emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), rep(FALSE,length(summary_unc$emi)), as.logical(xFlag)),
                  emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), rep(FALSE,length(summary_unc$emi)), as.logical(xFlag)))
      
    }
    
    cat('emi cat = ', emi.keys.0[k], ' *** ')
    
    # ***
    # NOW calculate asymmetric lognormal or normal CI
    # 
    CI.range <-  apply(g1[[k]],1,function(x){f.asymmetric_unc(as.numeric(x[2]),as.numeric(x[3]),as.numeric(x[1]))}) #passed arguments: min, max, mean
    #***
    #  original g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1]) #CI.range[1] should be negative for asymmetric
    minCI <- CI.range[1,]
    maxCI <- CI.range[2,]
    g1[[k]]$CImin <- g1[[k]][[2]]*(1- abs(minCI))
    #  g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1])
    g1[[k]]$CImax <- g1[[k]][[2]]*(1+ maxCI)
    g1[[k]]$CIminPerc <- as.numeric(minCI)
    g1[[k]]$CImaxPerc <- as.numeric(maxCI)
    CI.range <- NULL
    
  }
  g1 <- g1[!sapply(g1, is.null)] # remove empty list elements
  
  #names(g1) <- emi.keys.0
  colnames <- c('tot.subcat','rel.unc.min','rel.unc.max','asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc')
  g1.tot <- lapply(g1, setNames, colnames)
 #  if(now_run=='CO2' & b.cat== 'Margarita') {  # original
    if( (b.cat== 'Margarita' | b.cat == 'EDGAR') &  !is.null(kempty) ){
    names(g1.tot) <- emi.keys.0[-kempty] 
  } else {
    names(g1.tot) <- emi.keys.0
  }
  
  
#  lapply(1:length(g1.tot), function(i) write.csv(g1.tot[[i]], 
#                                                 file = paste0(out.dir,names(g1.tot[i]), ".csv"),
#                                                 row.names = FALSE))
#  
#  gg2 <- melt(g1.tot, id=c('tot.subcat','rel.unc.min','rel.unc.max',
#                           'asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc'))
#  write.csv(gg2, file = paste0(out.dir, now_run, "_EU28.csv"),   row.names = FALSE)
  
  return(g1.tot)
} # end function

f.EU.total <- function(cat0, bFlag){
  # EU total by category
  emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                    emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, bFlag), # FALSE = correlated
                                    emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, bFlag) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1]))/1000)
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2])/1000)
  emi.tot.cat$country <- 'EU28'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat/1000
  # ****
  # end EU  total
  return(emi.tot.cat)
}
