
# confidence interval for the mean of log-normal distribution
library(EnvStats)
library(boot)
library(MASS)
library(dmutate)

set.seed(1)

# Simulated data
data0 = exp(rnorm(1000,mean=10))

norm_data0 <- log(data0)
sigma <- sqrt(var(norm_data0))

mean <- mean(norm_data0)
min  <- mean(norm_data0-2*sigma)
max  <- (mean(norm_data0+2*sigma))

CI <- f.asymmetric_unc (min/mean,max/mean,mean)
mean*(1-abs(CI[1]))
mean*(1+abs(CI[2]))


# Statistic (MLE)
# https://stats.stackexchange.com/questions/33382/how-do-i-calculate-a-confidence-interval-for-the-mean-of-a-log-normal-data-set
mle <- function(dat){
  m = mean(log(dat))
  s = mean((log(dat)-m)^2)
  return(exp(m+s/2))
}

# Bootstrap
boots.out = boot(data=data0, statistic=function(d, ind){mle(d[ind])}, R = 10000)

plot(density(boots.out$t))

# 4 types of Bootstrap confidence intervals
boot.ci(boots.out, conf = 0.95, type = "all")



a <- elnorm(data0, method = "mle/mme", ci = T, ci.type = "two-sided", 
          ci.method = "exact", conf.level = 0.95)

a$interval$limits

# -----
if(bFood){
  out.dir <- 'D:\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\'
  g1.CH4 <- loadRData(file=paste0(out.dir,'CH4_emi_by_categories.Rdata'))
  g1.N2O <- loadRData(file=paste0(out.dir,'N2O_emi_by_categories_max250.Rdata'))
  g1.CO2 <- loadRData(file=paste0(out.dir,'CO2_emi_by_categories.Rdata'))
}


set.seed(13) # for reprudicibility
nsample = 10000
agsn2o <- as.data.frame(g1.N2O$AGS)
# rn <- apply(agsn2o,1,function(x){ exp(rnorm(1000,mean=as.numeric(x[2]), sd=as.numeric(x[4])*as.numeric(x[2])))})

hold1 <- matrix(NA, nrow=nsample, ncol=nrow(agsn2o))
for (i in 1:nrow(agsn2o)){
  m <- agsn2o$tot.subcat[i]
  s <- m*agsn2o$rel.unc.max[i]
  mean <- log(m^2 / sqrt(s^2 + m^2))
  sd <- sqrt(log(1 + (s^2 / m^2)))
  hold1[,i] <- rlnorm(nsample,meanlog=m, sdlog=s) # https://stats.stackexchange.com/questions/68394/plot-log-normal-distribution-in-r
  # hold1[,i] <- rlnorm(1000,mean, sd)           # https://msalganik.wordpress.com/2017/01/21/making-sense-of-the-rlnorm-function-in-r/
  #  rlnorm(n = 1000000, meanlog = 7, sdlog = 75) and exp(rnorm(n = 1000000, mean = 7, sd = 75))
  #  produce the same result.
  idx <- which(is.infinite(hold1[,i]))
  hold1[idx,i] <- median(hold1[,i],na.rm=T)
}

# rn <- apply(agsn2o,1,function(x){ rlnorm(1000,mean=as.numeric(x[2]), sd=as.numeric(x[4])*as.numeric(x[2])))})

# build a covariance matrix following https://stats.seandolinar.com/making-a-covariance-matrix-in-r/

cM <- agsn2o$tot.subcat # colMeans(hold1)

M_mean <- matrix(data=1, nrow=10000) %*% cM
D <- hold1 - M_mean
C <- (nrow(agsn2o)-1)^-1 *t(D) %*% D

C[is.infinite(C) | is.na(C)] <- median(C, na.rm=T)

# now add all distributions 
## need cov matrix
cov.matrix <- cov(log(hold1)) #,use = "pairwise.complete.obs")
cov.matrix[is.infinite(cov.matrix) | is.na(cov.matrix)] <- median(cov.matrix, na.rm=T)

# https://stats.seandolinar.com/making-a-covariance-matrix-in-r/
sample <- mvrnorm(n=10000, mu=agsn2o$tot.subcat, Sigma= C, empirical=F) # use empirical = TRUE to specify empirical 

sample <- rlmvnorm(n=10000, mu=agsn2o$tot.subcat, Sigma=C,tol=1, empirical=F) # use empirical = TRUE to specify empirical 
# not population parameters for ?? and ??. This 
# results in the covariance matrix of sample 
# having exactly the values we specified
sum    <- rowSums(sample)
sum[sum<0]<-mean(sum)
quantile(sum, probs=c(0, 0.05, 0.95, 0.5))


a <- elnorm(sum, method = "mle/mme", ci = T, ci.type = "two-sided", 
            ci.method = "exact", conf.level = 0.95)

a$interval$limits




# ---- redo with rnorm ----
# https://stackoverflow.com/questions/40406382/compute-covariance-matrix-on-our-own-without-using-cov


set.seed(13) # for reprudicibility
nsample = 10000
agsn2o <- as.data.frame(g1.N2O$AGS)
# rn <- apply(agsn2o,1,function(x){ exp(rnorm(1000,mean=as.numeric(x[2]), sd=as.numeric(x[4])*as.numeric(x[2])))})

hold1 <- matrix(NA, nrow=nsample, ncol=nrow(agsn2o))
for (i in 1:nrow(agsn2o)){
  m <- agsn2o$tot.subcat[i]
  s <- 0.5*m*agsn2o$rel.unc.max[i]
#  mean <- log(m^2 / sqrt(s^2 + m^2))
#  sd <- sqrt(log(1 + (s^2 / m^2)))
  hold1[,i] <- rnorm(nsample,mean=m, sd=s) # https://stats.stackexchange.com/questions/68394/plot-log-normal-distribution-in-r
  # hold1[,i] <- rlnorm(1000,mean, sd)           # https://msalganik.wordpress.com/2017/01/21/making-sense-of-the-rlnorm-function-in-r/
  #  rlnorm(n = 1000000, meanlog = 7, sdlog = 75) and exp(rnorm(n = 1000000, mean = 7, sd = 75))
  #  produce the same result.
  idx <- which(is.infinite(hold1[,i]))
  hold1[idx,i] <- median(hold1[,i],na.rm=T)
}

# rn <- apply(agsn2o,1,function(x){ rlnorm(1000,mean=as.numeric(x[2]), sd=as.numeric(x[4])*as.numeric(x[2])))})

# build a covariance matrix following https://stats.seandolinar.com/making-a-covariance-matrix-in-r/

cM <- agsn2o$tot.subcat # colMeans(hold1)

M_mean <- matrix(data=1, nrow=10000) %*% cM
D <- hold1 - M_mean
C <- (nrow(agsn2o)-1)^-1 *t(D) %*% D

C[is.infinite(C) | is.na(C)] <- median(C, na.rm=T)

# C / tcrossprod(diag(C) ^ 0.5) convert covariance to correlation to check


# https://stats.seandolinar.com/making-a-covariance-matrix-in-r/
sample <- mvrnorm(n=10000, mu=agsn2o$tot.subcat, Sigma= C, empirical=F) # use empirical = TRUE to specify empirical 

# sample <- rlmvnorm(n=10000, mu=agsn2o$tot.subcat, Sigma=C,tol=1e-5, empirical=F) # use empirical = TRUE to specify empirical 
# not population parameters for ?? and ??. This 
# results in the covariance matrix of sample 
# having exactly the values we specified
sum    <- rowSums(sample)
sum[sum<0]<-mean(sum)
# quantile(sum, probs=c(0, 0.05, 0.95, 0.5))
q <- quantile(sum, probs=c(0, 0.05, 0.95, 0.5))
qn <- as.numeric(q)
f.asymmetric_unc(q[2]/sum(cM),q[3]/sum(cM),sum(cM))


