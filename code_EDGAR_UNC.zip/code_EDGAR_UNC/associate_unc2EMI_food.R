#' Title
#'



f.emi_share_unc <- function(unc.summary)
  # E.solazzo 27 November 2019
  # to deal with additional unc introduced by food share emission
  
{
  
  # loop over unc.summary
  # load unc.summary
  emi <- read.csv(file=paste0(data.emi,'CH4_emi_food_2015.csv'), sep=',', header=T)
  unc.summary <- loadRData(file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\CH4\\emi_by_category_EDGAR_UncCorr_CH4_Emission_unc.Rdata')
  unc.summary.food <- data.frame(matrix(NA))# ,nrow=2*nrow(emi),ncol=10) )
  
#  prog <- seq(1,length(emi$Process.code),500)
#  idx <- which(grepl('TNR.DAT' ,emi$Process.code))
#  for (p in idx ){
  k <- 0; proc0p <- '' ; emip <- -999 
  for (p in 1:length(emi$Process.code) ){
    proc0    <- emi$Process.code[p]
    country  <- emi$Country[p]
        if( any(p==prog)) { cat('process ', proc, 'for country ', as.character(country), ' *** ', round(100*p/length(emi$Process.code),2),'%','\n' )}
    
    proc <- substring(proc0, 1,15)
    u.row <- unc.summary[unc.summary$processes==proc  & unc.summary$country==country & !is.na(unc.summary$emi) ,]
    #    u.row <- na.omit(u.row)
    u.row.idx <- which(unc.summary$processes==proc  & unc.summary$country==country & !is.na(unc.summary$emi))
    
    if (dim(u.row)[1]>=1 &  !is.na(emi$X2015[p])){
#      if(dim(u.row)[1] > 1 & proc0==proc0p & emi$X2015[p] == emip) next()
#      proc0p <- proc0 ; emip <- emi$X2015[p] # store current vlaues for comparison at next loop; 
                                             # this check is necessary to avoid overcounting rows
      for (j in 1:dim(u.row)[1]){
        k <- k+1 
        # deal with emission share uncertainty
        #    substr15 <- paste(paste0('^',substring(proc0, 1,7)), paste0(substring(proc0, 13,15), '$'), collapse='&')
        substr15a <- paste0('^',substring(proc0, 1,7) )
        substr15b <- paste0(substring(proc0, 13,15), '$')
        
        sbstr11 <- paste0('^',substring(proc0, 1,11),'$')
        sbstr7  <- paste0('^',substring(proc0, 1,7),'$')
        sbstr3  <- paste0('^',substring(proc0, 1,3),'$')
        sbstr <- c(sbstr11, sbstr7,sbstr3, substr15a)
        
        if (any(grepl(sbstr11, emi.share$process) | grepl(sbstr7, emi.share$process) | grepl(sbstr3, emi.share$process) |
                (grepl (substr15a, emi.share$process) & grepl(substr15b, emi.share$process)))){
 #         cat('process ', proc, ' for country ', as.character(country), '\n')
          #     browser()
          emi.share.row <- which(sapply(sbstr,function(x){grepl(x,emi.share$process )}), arr.ind=TRUE)[1]
          emi.share.min <- emi.share[emi.share.row,'min']/100
          emi.share.max <- emi.share[emi.share.row,'max']/100
          
          unc.comb.min <- sqrt(u.row[j,]$unc.min^2+ emi.share.min^2)
          unc.comb.max <- sqrt(u.row[j,]$unc.max^2+ emi.share.max^2)
          
          unc.emi.min <- emi$X2015[p]*(1-abs(unc.comb.min))
          unc.emi.max <- emi$X2015[p]*(1+unc.comb.max)
          
          unc.summary.food[k,1] <- u.row[j,]$processes
          unc.summary.food[k,2] <- u.row[j,]$ipcc06
          unc.summary.food[k,3] <- as.character(emi$IPCC06[p])
          unc.summary.food[k,4] <- u.row[j,]$country
          unc.summary.food[k,5] <- as.logical(u.row[j,]$iFlag)
          unc.summary.food[k,6] <- emi$X2015[p]*25
          unc.summary.food[k,7] <- unc.emi.min
          unc.summary.food[k,8] <- unc.emi.max
          unc.summary.food[k,9]  <-  unc.comb.min
          unc.summary.food[k,10] <-  unc.comb.max
          unc.summary.food[k,11] <- 'food_low_conf'
          
        } else { # u.row not empty: two possibilities: 1) needs extra unc due to food fraction
          #                                     2) fine as it is, no extra modification required 
          unc.summary.food[k,1]  <- u.row[j,]$processes
          unc.summary.food[k,2]  <- u.row[j,]$ipcc06
          unc.summary.food[k,3]  <- as.character(emi$IPCC06[p])
          unc.summary.food[k,4]  <- u.row[j,]$country
          unc.summary.food[k,5]  <- as.logical(u.row[j,]$iFlag)
          unc.summary.food[k,6]  <- emi$X2015[p]*25
          unc.summary.food[k,7]  <- unc.summary[u.row.idx[j], 'unc.emi.min']
          unc.summary.food[k,8]  <- unc.summary[u.row.idx[j], 'unc.emi.max']
          unc.summary.food[k,9]  <- unc.summary[u.row.idx[j], 'unc.min']
          unc.summary.food[k,10] <- unc.summary[u.row.idx[j], 'unc.max']
          unc.summary.food[k,11] <- 'food_high_conf'
          
        } 
#        cat('j= ', j, 'of ',  dim(u.row)[1], '\n')
      } # end loop over dim u.row
    } else{
      # cat('skip')
      next()
      
    }
 #   cat(unc.summary.food[k,], '\n')
  }
    names(unc.summary.food) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max', 'confidence')
    unc.summary.food.c <- unc.summary.food %>% group_by(country)%>%distinct(emi,.keep_all=T)
    # names(unc.summary.food.c) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max')
  
  # check
    tot<-unc.summary.food.c %>% group_by(country)%>%summarise(emi=sum(emi)/25)
    tot.true <- emi %>% group_by(Country)%>%summarise(emi=sum(X2015,na.rm=T))
    names(tot)<-names(tot.true)
    merge(tot, tot.true, by='Country')

  
#  save(unc.summary,      file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_Emission_unc.Rdata'))
  write.csv(unc.summary.food.c, file=paste0(out.dir,now_run,'_Emission_unc_food_c.csv'))
  write.csv(unc.summary.food, file=paste0(out.dir,now_run,'_Emission_unc_food.csv'))
}# end function
  





