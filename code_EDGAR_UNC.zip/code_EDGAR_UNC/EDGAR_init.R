
# init file for EDGAR uncertainty methane scripting
# E. SOlazzo, June 2018

## 1 kiloton [kt] = Teragram [Tg]

options(repos="https://CRAN.R-project.org")

library(readxl) 
# library(plyr)
library(dplyr)

library(countrycode)
library(googleVis)
library(reshape2)
library(data.table)
library(ggplot2)
library(gridExtra)
#library(MASS) # if montecarlo
#library(EnvStats)
library(rlist)
library(Cairo)
library(beanplot)
library(rpivotTable)
library(htmlwidgets)
library(tibble)
#w.dir    <- 'D:\\work\\GhG_move\\VERIFY\\EDGAR\\'
w.dir    <- 'E:\\D_extra\\work\\GhG_move\\VERIFY\\EDGAR\\'
data.dir <- paste0(w.dir,'data\\')  #  these directories are Ok for methane
out.dir  <- paste0(w.dir,'out\\')   #  but then are upated for N2O later
proc.dir <- paste0(w.dir,'proc\\')  #
fig.dir  <- paste0(w.dir,'figs\\')  #
food.dir <- 'D:\\work\\GhG_move\\EDGAR\\IPCC_food\\'

data.dir.fix <- paste0(w.dir,'data\\')  #  this won't change with GHG gas


source('functions_EDGAR_unc_1.R')

source('functions_combining_uncertainty.R')
source('expand_countries.R')
source('auxiliary_verify.R')
source('associate_unc2EMI.R')
source('gvis_chart.R')
source('waste_sector.R')
source('plotting_Edgar_category.R')
source('associate_unc2EMI_bSens.R')
source('aggregate_for_CHE.R')


country.info    <- read.csv(file=paste0(w.dir,'EDGAR_country.csv'), sep=',', header=T)
world.countries <- read.csv(file=paste0(data.dir,'world_countries.csv'), sep=',', header=F)
names(world.countries) <- c('fullname','ISO2','ISO3','numID')
source('country_operation.R') #load the 'country.group' list

# ***************************************************
# set this 
GHG     <- c('CH4', 'N2O', 'CO2')
now_run <- GHG[2]
bFood <- F # shall process only food sector (T) or all sectors (F)?
#********
bCat <- c('b.cat.UNFCCC','b.cat.methane','b.cat.tot','b.cat.N2O', 'b.cat.CO2', 'Margarita', 'EDGAR') 
#********************\
b.cat <- bCat[3]   # categories to analyse #2 for methane and 4 for N2O
bCountryTot <- F   # decide whether after the sector aggregation to also do the country aggregation
#********************\
bPlot <- F # shall do the gvis plotting
#********************\
bUncCorrFact   <- F # shall use the correction factor for large uncertainties Eq3.3 of IPCC chp 3 pg 3.60
bAsymmetricUnc <- T  # shall calculate the boosted uncertainty or stick to min and max? 
# 
# add check on 'bUncCorrFact' and 'bAsymmetricUnc'
 bFactAsym <- (bUncCorrFact & bAsymmetricUnc)
 # bFactAsym is true only if  'bUncCorrFact' and 'bAsymmetricUnc' are both true
 if (any(bUncCorrFact, bAsymmetricUnc) & !bFactAsym){
   message('* check bFactAsym flag: both bUncCorrFact and bAsymmetricUnc have to be either TRUE or FALSE *')
 }
 
 # *******************************************
sUncCorr <- ''
#if (bFactAsym) { #(bUncCorrFact & bAsymmetricUnc) { # original
  if (  bAsymmetricUnc){  # modification of 08 Jan 2020
  sUncCorr <-'UncCorr_'
} else {
  sUncCorr <-'UncNorm_'
}
#********************\

if(now_run == 'CH4'){
  sYear <- '2015' #2012'
  fig.dir  <- paste0(w.dir,'figs\\CH4\\2015\\')
  out.dir  <- paste0(w.dir,'out\\CH4\\2015\\')# NOBoostFact\\')
  proc.dir <- paste0(w.dir,'proc\\CH4\\2015\\')
#  data.dir <- paste0(w.dir,'data\\CH4')
  ## set aggregation string 
  if (bCountryTot){
    sCatcAgg <- 'country_total_'
  } else {
    sCatAgg <- 'emi_by_category_'
  }
  ## set category string 
  if(b.cat=='b.cat.UNFCCC'){
    emi.keys.0 <- c( '1A', '1B1','1B2', '2', '3A',  '3C7', '4A', '4D') 
    #   emi.keys.0 <- c('1A','1B1','1B2','2','3A1','3A2','3C7','4A','4D')
    
    sCatEmi <- 'UNFCCC_cat_'
  }else if (b.cat=='b.cat.methane'){
    #  emi.keys.0 <- c( '1.A', '1.B.1','1.B.2', '2', '3.A',  '3.C.7', '4.A', '4.D') 
    emi.keys.0 <- c('1.A','1.B.1','1.B.2','2','3.A.1','3.A.2','3.C.7','4.A','4.D')
    sCatEmi <- 'methane_cat_'
  } else if (b.cat=='b.cat.tot'){
    emi.keys.0 <- c( '1', '2', '3',  '4', '5')
    sCatEmi <- 'total_cat_'
  }else if (b.cat=='EDGAR'){
    emi.keys.0 <- c('AGS', 'AWB', 'CHE', 'ENE', 'ENF','FFF',  'IND','IRO',
                    'MNM', 'PRO', 'RCO','REF','SWD','TNR', 'TRF','TRO',  'WWT' )
    sCatEmi <- 'EDGAR_'
  }
  
} else if (now_run=='N2O'){
  sYear <-    '2015'# '2012' #
  # *** # set this    *****
  b.cat <- bCat[3] 
  # *********************** 
  
  sCatAgg <- 'emi_by_category_'
  data.dir <- paste0(w.dir,'data\\N2O\\')  
  out.dir  <- paste0(w.dir,'out\\N2O\\', sYear, '\\')# NOBoostFact\\')
  proc.dir <- paste0(w.dir,'proc\\N2O\\', sYear, '\\')#NOBoostFact\\')
  fig.dir  <- paste0(w.dir,'figs\\N2O\\', sYear, '\\')#NOBoostFact\\')
  
  if (b.cat=='b.cat.tot'){
    emi.keys.0 <- c( '1', '2', '3',  '4', '5')
    sCatEmi <- 'total_cat_'
  } else if (b.cat=='b.cat.N2O'){
    emi.keys.0 <- c( '1.A', '2.B','3.A', '3.C.1', '3.C.4',  '3.C.5', '3.C.6',  '4','5.A')
    sCatEmi <- 'specific_cat_'
  }else if (b.cat=='EDGAR'){
    emi.keys.0 <- c('AGS', 'AWB', 'CHE', 'ENE', 'FFF', 'IND','MNM','N2O', 'PRO','PRU',
                    'RCO','REF', 'SWD','TRF' , 'TNR', 'TRO', 'WWT', 'IDE')
   
    sCatEmi <- 'EDGAR_'
  }
  
  
}  else if (now_run=='CO2'){
  sYear <- '2015' #2012#2018 #
  # *** # set this    *****
  b.cat <- bCat[5] #bCat[3]  # bCat[6] : CHE; #bCat[7] : EDGAR 
  if (b.cat== bCat[6]) sCatEmi <- 'CHE_'
  if (b.cat== bCat[5]) sCatEmi <- 'specific_cat_'
  sCatAgg <- 'emi_by_category_'
  
  if(b.cat=='Margatita' & now_run !='CO2') {message('* check bCat flag: Margarita can be run for CO2 only *')}
  # ***********************  
  if (b.cat=='b.cat.tot'){
    emi.keys.0 <- c( '1', '2', '3', '4', '5')
  } else if (b.cat=='b.cat.CO2'){
    emi.keys.0 <- c( '1.A.1', '1.A.2','1.A.3','1.B', '2','3', '5')
    data.dir <- paste0(w.dir,'data\\CO2\\')  
    out.dir  <- paste0(w.dir,'out\\CO2\\2015\\') #booklet\\')
    proc.dir <- paste0(w.dir,'proc\\CO2\\2015\\') #booklet\\')
    fig.dir  <- paste0(w.dir,'figs\\CO2\\2015\\') #booklet\\')
  } else if(b.cat=='Margarita'){
    # emi.keys.0 <- c('ENE','IND','RCO','REF_TRF', 'SWD.INC', 'IRO',
    #                 'NFE','NEU','NMM','CHE', 'TNR.AIR','TNR.ILW',
    #                 'TNR.SEA', 'TNR.OTH', 'PRO','AGS','PRU_SOL', 'TRO',
    #                 'TNR.DAT.AVG.CDS',
    #                 'TNR.DAT.AVG.CRS',
    #                 'TNR.DAT.AVG.LTO',
    #                 'TNR.DAT.GJE.CDS',
    #                 'TNR.DAT.GJE.CRS',
    #                 'TNR.DAT.GJE.LTO',
    #                 'TNR.DAT.JET.CDS',
    #                 'TNR.DAT.JET.CRS',
    #                 'TNR.DAT.JET.LTO')
    # 
    
    emi.keys.0 <- c('ENE','MANUFACTURING','RCO','AVIATION','TRANSPORT','OTHER','SWD.INC')
    
    sCatEmi <- 'CHE_'
    country.info <- read.csv(file=paste0(data.dir.fix,'world_countries_CHE.csv'), sep=',', header=T) #overwrite
    out.dir  <- paste0(w.dir,'out\\CO2\\CHE\\')
    proc.dir <- paste0(w.dir,'proc\\CO2\\CHE\\')
    fig.dir  <- paste0(w.dir,'figs\\CO2\\CHE\\')
    data.dir <- paste0(w.dir,'data\\CO2\\')
    
  }else if (b.cat=='EDGAR' ){
    emi.keys.0 <- c('AGS','CHE','ENE', 'FFF', 'IND', 'IRO', 'NEU', 'NFE', 
                    'NMM', 'PRO' ,'RCO', 'REF', 'SOL', 'SWD', 'TNR', 'TRF', 'TRO')
    
     sCatEmi <- 'EDGAR_' #sCatAgg <- 'EDGAR_';
  
  data.dir <- paste0(w.dir,'data\\CO2\\')  
  out.dir  <- paste0(w.dir,'out\\CO2\\2015\\') #booklet\\')
  proc.dir <- paste0(w.dir,'proc\\CO2\\2015\\') #booklet\\')
  fig.dir  <- paste0(w.dir,'figs\\CO2\\2015\\') #booklet\\')
  }
}


if(bFood){
  data.emi <- paste0(food.dir, 'data\\')
  out.dir  <- paste0(food.dir, 'out\\') 
  proc.dir <- paste0(food.dir, 'proc\\')
  fig.dir  <- paste0(food.dir, 'figs\\')
  
  emi.share <- read.csv(file=paste0(data.emi,'sector_specific_uncertainty.csv'), header=T, sep=',', stringsAsFactors = F)
}
#************************************************
ipcc_cat.0 <-c()

# rice operation
act.in <- read.csv(file=paste0(data.dir.fix,'rice_activity.csv'), sep=',', header=T)

# remove empty columns 
idx <- which(apply(act.in, 2, function(x){length(which(is.na(x)))==length(x)}))
act.in <- act.in[,-idx]
rm(idx)
# replace old values with most recent ones where available
num.col <- dim(act.in)[2]
idx.new <- which(!is.na(act.in[,num.col]))
idx.numeric.column <- which(sapply(act.in,is.numeric))
act.in[idx.new,min(idx.numeric.column)] <- act.in[idx.new,max( idx.numeric.column)] 
act.in <- act.in[,-max( idx.numeric.column)]
rm(idx.new)