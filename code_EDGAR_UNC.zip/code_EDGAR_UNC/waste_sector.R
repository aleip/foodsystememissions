

f.WWT_unc <- function(proc, country){ # called from f.associate_unc2EM(proc, country) 
  country <- as.character(country)

  fdev <- country.info$ind[which(country.info$ISO3 == country) ]
  unc_Bo <- 30

  if (substring(proc,1,7)== 'WWT.DOM'){ # domestic waste water
    if (substring(proc,13,15)== 'BLA')  {unc_MCF <- 50} # domestic waste water # sanitation: Bucket latrine
    if (substring(proc,13,15)== 'ILA')  {unc_MCF <- 50}  # sanitation: Improved latrine
    if (substring(proc,13,15)== 'LAT')  {unc_MCF <- 50} # sanitation: Latrines (public or open pit)
    if (substring(proc,13,15)== 'S2R')  {unc_MCF <- 20} # sanitation: Sewer to raw discharge
    if (substring(proc,13,19)== 'S2W.NOC')  {unc_MCF <- 20} # 	sanitation: Sewer to WWTP
    if (substring(proc,13,19)== 'S2W.WRE')  {unc_MCF <- 0}   #  sanitation: Sewer to WWTP with recovery
    if (substring(proc,13,15)== 'SEP')  {unc_MCF <- 0}       #  sanitation: Septic tank
    
    if (fdev =='I'){
      unc_Tij <- 5
    } else {
      unc_Tij <- 50
    }
    unc_u <- 15
    WWT.AD.unc <- sqrt(5^2+30^2+20^2) # uncetainty on activity data (TOW = P*BOD*I*const, 
                                      # assuming 20% uncertainty on the correction factor I (no distinctio between collected and uncollected))
    
    unc.emi <- sqrt(unc_u^2 + unc_Tij^2 + unc_Bo^2 +  unc_MCF^2 +   WWT.AD.unc^2)  
    unc.emi.min <- unc.emi
    unc.emi.max <- unc.emi

    } else if (substring(proc,1,7)== 'WWT.IND'){ # industrial waste water
      unc_MCF <- 50
      if (substring(proc,13,15)== 'RAW') {unc_MCF <- 100}
      
      WWT.AD.unc.min <- sqrt(25^2+50^2)
      WWT.AD.unc.max <- sqrt(25^2+100^2)
      
      unc.emi.min <- sqrt( unc_Bo^2 +  unc_MCF^2 +   WWT.AD.unc.min^2)  
      unc.emi.max <- sqrt( unc_Bo^2 +  unc_MCF^2 +   WWT.AD.unc.max^2)  
  }
  unc.WWT <- c(unc.emi.min, unc.emi.max)
  return(unc.WWT)

} # end function



# #v solid waste
# D.max <- 1   # (developing countries)
# D.min <- 0.3 # (industrialised)
# 
# MCF.min <- 0.10
# MCF.max <- 0.50
# 
# DOC.max <- 0.2
# DOC.min <- 0.1
# 
# DOCf.max <- 0.2
# DOCf.min <- 0.1
# 
# f <- 0.05
# k <- 0.1 #effects of k seems negligible
# 
# 
# unc.SWD.max <- sqrt(D.max^2 + MCF.max^2+DOCf.max^2+f^2)
# unc.SWD.min <- sqrt(D.min^2 + MCF.min^2+DOCf.min^2+f^2)
# 
# # kdist <- rnorm(10000, mean=2, sd=0.5)
# # kerr <- 1-(exp(-kdist)/kdist)*exp(-kdist)
# # plot(density(kerr))#
# 
# #quantile(density(kerr))


