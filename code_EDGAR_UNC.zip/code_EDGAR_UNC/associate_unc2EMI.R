#' Title
#'
#' @param uTable 
#'# called from main
#' @return
#' @export
#' at this point the unc distribution is still symmetric about the mean value
#' @examples
f.associate_unc2EM_CH4 <- function(uTable,sDate){ # uTable is available from the main program (t.hold)
  
  # read in the EMission and associate each emi category to uncertainty
  # uTable <- loadRData(file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\CH4\\UncCorr_2015_full_unc.Rdata') 
 
if(sYear == '2015')  {
  emi <- read.csv(file=paste0(data.dir,'CH4\\CH4_EmiV5FT2018_GWP.csv'), sep=',', header=T)
} else if (sYear == '2012'){
  emi <- read.csv(file=paste0(data.dir,'CH4_EMI_v432.csv'), sep=',', header=T)
}
 
   
  if(bFood) emi <- read.csv(file=paste0(data.emi,'CH4_emi_food_2015.csv'), sep=',', header=T)
#  emi <- read.csv(file=paste0(data.dir,'CH4_EMI_v42.csv'), sep=',', header=T)
  unc.summary <- data.frame(matrix(NA,nrow=nrow(emi),ncol=10) )
# uTable$u.EM.min <- NA
  
  prog <- seq(1,length(emi$Process.code),500)
  for (p in 1:length(emi$Process.code) ){
     proc0    <- emi$Process.code[p]
     country  <- emi$Country[p]
     
     proc <- substring(proc0, 1,15)
     last_numeric_column <- as.numeric(which(sapply(emi,function(x){is.numeric(x)})))
     
     if (sYear==substr(colnames(emi)[5],2,5)) {
#     emi.tmp <- emi[p,dim(emi)[2]]     # last numeric column 
       emi.tmp <- emi[p,last_numeric_column]
     } else {
       cat(' * warning in routine f.associate_unc2EM_CH4 * ', '\n')
     }
#     if(is.na(emi.tmp)){
#      #get last non NA value
#       emi.tmp <- ifelse(is.numeric(emi[p,max(which(!is.na(emi[p,])))]), emi[p,max(which(!is.na(emi[p,])))], NA)
#     }
     
     
    if( any(p==prog)) { cat('process ', proc, 'for country ', as.character(country), ' *** ', round(100*p/length(emi$Process.code),2),'%','\n' )}
     
#     u.row <- uTable[proc==uTable$process  & uTable$country==country,]
     u.row <- uTable[uTable$process==proc  & uTable$country==country,]
#     if (dim(u.row)[1]==0){
#       string <- paste0('ohi ohi, cazzi amari for process ', proc, ' and country ', as.character(country) )#, '\n')
#       cat(string, file=paste0(out.dir, sDate,'_warning_emi.text'), sep='\n', append=T)
#       next()
#     }
     
     if (dim(u.row)[1]==0){
       proc <- substring(proc0, 1,11)
       u.row <- uTable[substring(as.character(uTable$process),1,11)==proc  & uTable$country==country,]
     }
     if (dim(u.row)[1]>0){
       u.row <- u.row[1,]
     } else {
       
       
       proc <- substring(proc0, 1,7)
       u.row <- uTable[substring(as.character(uTable$process),1,7)==proc  & uTable$country==country,]
       
     }
     if (dim(u.row)[1]>0){
       u.row <- u.row[1,]
     } else {
       
       proc <- substring(proc0, 1,3)
       u.row <- uTable[substring(as.character(uTable$process),1,3)==proc  & uTable$country==country,]
     }
     if (dim(u.row)[1]>0){
       u.row <- u.row[1,]
     }  else {
       
       string <- paste0('warning:no entry for process ', proc, ' and country ', as.character(country) )#, '\n')
       cat(string, file=paste0(out.dir, sDate,'_', now_run,'_warning_emi.text'), sep='\n', append=T)
       next()
     }
     
     
     # case of biofuel in sector 1A
     if(grepl('1A', emi$IPCC06[p]) & grepl('x',  emi$IPCC06[p])  ) {
       u.row$unc_tot_min <- f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
       u.row$unc_tot_max <- f.comb_unc(0.8,0.8)
       
       tmp <- f.unc_fact(u.row$unc_tot_min, u.row$unc_tot_min)
       u.row$unc_tot_min_fact <- tmp[1]
       u.row$unc_tot_max_fact <- tmp[2]
       tmp <- NULL
       
     }
     if (substring(proc, 1,3) == 'WWT') { # case of waste water treatment
       
       unc.WWT <- f.WWT_unc(as.character(proc0), country)
       
       u.row$unc_tot_min <- unc.WWT[1]/100
       u.row$unc_tot_max <- unc.WWT[2]/100
       
       tmp <- f.unc_fact(u.row$unc_tot_min, u.row$unc_tot_min)
       u.row$unc_tot_min_fact <- tmp[1]
       u.row$unc_tot_max_fact <- tmp[2]
       tmp <- NULL
     }

     # if(bUncCorrFact){
     #   CI.range <- f.large_asymmetric_unc(u.row$unc_tot_min_fact, u.row$unc_tot_max_fact, emi.tmp)
     #   #     the call to f.large_asymmetric_unc returns CI.range composed by c(unc.tot.min , unc.tot.max, CI.min, CI.max)
     # } else {
     #   
     #   tmp.min     <- as.numeric(u.row$unc_tot_min); tmp.max <- as.numeric(u.row$unc_tot_max)
     #   tmp.min.unc <- ifelse(emi.tmp > emi.tmp*tmp.min, emi.tmp - emi.tmp*tmp.min, 
     #                         1/(1+tmp.min) ) #following Olivier et al 2002, table 9
     #   tmp.max.unc <- emi.tmp+(emi.tmp*tmp.max)
     #   
     #   CI.range <- c(   tmp.min, tmp.max, tmp.min.unc,  tmp.max.unc    )
     # }

     unc.summary[p,1] <- u.row$process
     unc.summary[p,2] <- u.row$ipcc06
     unc.summary[p,3] <- as.character(emi$IPCC06[p])
     unc.summary[p,4] <- u.row$country
     unc.summary[p,5] <- as.logical(u.row$cFlag)
     unc.summary[p,6] <- emi.tmp
     # symmetric distribution about the mean value, even negative values are accepted
     unc.summary[p,7] <- emi.tmp-(emi.tmp*as.numeric(u.row$unc_tot_min_fact))
     unc.summary[p,8] <- emi.tmp+(emi.tmp*as.numeric(u.row$unc_tot_max_fact))
     unc.summary[p,9]   <- as.numeric(u.row$unc_tot_min_fact)
     unc.summary[p,10]  <- as.numeric(u.row$unc_tot_max_fact)
#     unc.summary[p,7] <- emi.tmp-(emi.tmp*abs(CI.range[3])) #CI.range[3] should be negative unc.emi.min
#     unc.summary[p,8] <- emi.tmp+(emi.tmp*CI.range[4])
#     unc.summary[p,9]   <- as.numeric(CI.range[1])
#     unc.summary[p,10]  <- as.numeric(CI.range[2]) #as.numeric(u.row$unc_tot_max)
     
  }
  
  names(unc.summary) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max')

  save(unc.summary,      file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,'CH4_Emission_unc.Rdata'))
  write.csv(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,'CH4_Emission_unc.csv'))

  return(unc.summary)
} 
#' Title
#'
#' @param uTable 
#'# called from main
#' @return
#' @export
#' at this point the unc distribution is still symmetric about the mean value
#' @examples
f.associate_unc2EM_N2O <- function(uTable,sDate){ # uTable is available from the main program (t.hold)
  
  # read in the EMission and associate each emi category to uncertainty
  # uTable <- loadRData(file=paste0(out.dir,'full_unc.Rdata')) 
#  uTable <- t.hold
  if(bFood) emi <- read.csv(file=paste0(data.emi,'N2O_emi_food_2015.csv'), sep=',', header=T)
  if(sYear == '2015')  {
    emi <- read.csv(file=paste0(data.dir,'N2O_EmiV5FT2018_GWP.csv'), sep=',', header=T)
  } else if (sYear == '2012'){
  emi <- read.csv(file=paste0(data.dir,now_run,'_EMI_v432.csv'), sep=',', header=T)
  }
  #  emi <- read.csv(file=paste0(data.dir,'CH4_EMI_v42.csv'), sep=',', header=T)
  unc.summary <- data.frame(matrix(NA,nrow=nrow(emi),ncol=10) )
  # uTable$u.EM.min <- NA
  
  prog <- seq(1,length(emi$Process.code),500)
  for (p in 1:length(emi$Process.code) ){
    proc0    <- emi$Process.code[p]
    country  <- emi$Country[p]
    
    proc <- substring(proc0, 1,15)
    emi.tmp <- emi[p,dim(emi)[2]]     # last numeric column 
    
    
    if( any(p==prog)) { cat('process ', proc, 'for country ', as.character(country), ' *** ', round(100*p/length(emi$Process.code),2),'%','\n' )}
    
    #     u.row <- uTable[proc==uTable$process  & uTable$country==country,]
    u.row <- uTable[uTable$process==proc  & uTable$country==country,]
    # if (dim(u.row)[1]==0){
    #   string <- paste0('ohi ohi, cazzi amari for process ', proc, ' and country ', as.character(country) )#, '\n')
    #   cat(string, file=paste0(out.dir, sDate, '_', now_run,'_warning_emi.text'), sep='\n', append=T)
    #   next()
    # }
    if (dim(u.row)[1]==0){
      proc <- substring(proc0, 1,11)
      u.row <- uTable[substring(as.character(uTable$process),1,11)==proc  & uTable$country==country,]
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    } else {
      
      
      proc <- substring(proc0, 1,7)
      u.row <- uTable[substring(as.character(uTable$process),1,7)==proc  & uTable$country==country,]
      
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    } else {
      
      proc <- substring(proc0, 1,3)
      u.row <- uTable[substring(as.character(uTable$process),1,3)==proc  & uTable$country==country,]
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    }  else {
      
      string <- paste0('warning:no entry for process ', proc, ' and country ', as.character(country) )#, '\n')
      cat(string, file=paste0(out.dir, sDate,'_', now_run,'_warning_emi.text'), sep='\n', append=T)
      next()
    }
    
    if(now_run == 'CH4'){
      # case of biofuel in sector 1A
      if(grepl('1A', emi$IPCC06[p]) & grepl('x',  emi$IPCC06[p])  ) {
        u.row$unc_tot_min <- f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
        u.row$unc_tot_max <- f.comb_unc(0.8,0.8)
        
        tmp <- f.unc_fact(u.row$unc_tot_min, u.row$unc_tot_min)
        u.row$unc_tot_min_fact <- tmp[1]
        u.row$unc_tot_max_fact <- tmp[2]
        tmp <- NULL
        
      }
      if (substring(proc, 1,3) == 'WWT') { # case of waste water treatment
        
        unc.WWT <- f.WWT_unc(as.character(proc0), country)
        
        u.row$unc_tot_min <- unc.WWT[1]/100
        u.row$unc_tot_max <- unc.WWT[2]/100
        
        tmp <- f.unc_fact(u.row$unc_tot_min, u.row$unc_tot_min)
        u.row$unc_tot_min_fact <- tmp[1]
        u.row$unc_tot_max_fact <- tmp[2]
        tmp <- NULL
      }
    }
    
    unc.summary[p,1] <- u.row$process
    unc.summary[p,2] <- u.row$ipcc06
    unc.summary[p,3] <- as.character(emi$IPCC06[p])
    unc.summary[p,4] <- u.row$country
    unc.summary[p,5] <- as.logical(u.row$cFlag)
    unc.summary[p,6] <- emi.tmp
    # symmetric distribution about the mean value, even negative values are accepted
    unc.summary[p,7] <- emi.tmp-(emi.tmp*as.numeric(u.row$unc_tot_min_fact))
    unc.summary[p,8] <- emi.tmp+(emi.tmp*as.numeric(u.row$unc_tot_max_fact))
    unc.summary[p,9]   <- as.numeric(u.row$unc_tot_min_fact)
    unc.summary[p,10]  <- as.numeric(u.row$unc_tot_max_fact)
    
  }
  
  names(unc.summary) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max')
  
  save(unc.summary,      file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_',sYear,'_Emission_unc_max250.Rdata'))
  write.csv(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_',sYear,'_Emission_unc_max250.csv'))
  
  return(unc.summary)
} 

#' Title
#'
#' @param uTable 
#'# called from main
#' @return
#' @export
#' at this point the unc distribution is still symmetric about the mean value
#' @examples
f.associate_unc2EM_CO2 <- function(uTable,sDate){ # uTable is available from the main program (t.hold)
  # debug: 
  # read in the EMission and associate each emi category to uncertainty
  # uTable <- loadRData(file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\CO2\\2015\\UncCorr_full_unc.Rdata') 
  
  if(sYear == '2015')  {
    emi <- read.csv(file=paste0(data.dir,'CO2_emi_2015_V5FT2018.csv'), sep=',', header=T)
  } else if (sYear == '2012'){
    
    #  emi <- read.csv(file=paste0(data.dir,now_run,'_EMI_v5.0_2018.csv'), sep=',', header=T)
    emi <- read.csv(file=paste0(data.dir,now_run,'_CHE_v432_FT2015.csv'), sep=',', header=T) # CO2_EMI_CHE_2015
  } 
  
  
  if(bFood)  { emi <- read.csv(file=paste0(data.emi,'CO2_emi_food_2015.csv'), sep=',', header=T) }
  #  emi <- read.csv(file=paste0(data.dir,now_run,'_EMI_v432.csv'), sep=',', header=T)
  #  emi <- read.csv(file=paste0(data.dir,'CH4_EMI_v42.csv'), sep=',', header=T)
  unc.summary <- data.frame(matrix(NA,nrow=nrow(emi),ncol=10) )
  
  
  prog <- seq(1,length(emi$Process.code),500)
  
  for (p in 1:length(emi$Process.code) ){
    proc0    <- emi$Process.code[p]
    country  <- emi$Country[p]
    
    proc <- substring(proc0, 1,15)
    emi.tmp <- emi[p,dim(emi)[2]]          # emissions in the  last numeric column 
    if(is.na(emi[p,dim(emi)[2]])) next()   # if no emission for given process and country move to next
    
    if( any(p==prog)) { cat('process ', proc, 'for country ', as.character(country), ' *** ', round(100*p/length(emi$Process.code),2),'%','\n' )}
    
    #     u.row <- uTable[proc==uTable$process  & uTable$country==country,]
    u.row <- uTable[uTable$process==proc  & uTable$country==country,]
    # original    
    #    if (dim(u.row)[1]==0){
    #      string <- paste0('warning:no entry for process ', proc, ' and country ', as.character(country) )#, '\n')
    #      cat(string, file=paste0(out.dir, sDate,'_', now_run,'_warning_emi.text'), sep='\n', append=T)
    #      next()
    # start modifications 27 sept 2019  
    if (dim(u.row)[1]==0){
      proc <- substring(proc0, 1,11)
      u.row <- uTable[substring(as.character(uTable$process),1,11)==proc  & uTable$country==country,]
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    } else {
      
      
      proc <- substring(proc0, 1,7)
      u.row <- uTable[substring(as.character(uTable$process),1,7)==proc  & uTable$country==country,]
      
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    } else {
      
      proc <- substring(proc0, 1,3)
      u.row <- uTable[substring(as.character(uTable$process),1,3)==proc  & uTable$country==country,]
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    }  else {
      
      string <- paste0('warning:no entry for process ', proc, ' and country ', as.character(country) )#, '\n')
      cat(string, file=paste0(out.dir, sDate,'_', now_run,'_warning_emi.text'), sep='\n', append=T)
      next()
    }
    unc.summary[p,1] <- u.row$process
    unc.summary[p,2] <- u.row$ipcc06
    unc.summary[p,3] <- as.character(emi$IPCC06[p])
    unc.summary[p,4] <- u.row$country
    unc.summary[p,5] <- as.logical(u.row$cFlag)
    unc.summary[p,6] <- emi.tmp
    # symmetric distribution about the mean value, even negative values are accepted
    unc.summary[p,7] <- emi.tmp-(emi.tmp*as.numeric(u.row$unc_tot_min_fact))
    unc.summary[p,8] <- emi.tmp+(emi.tmp*as.numeric(u.row$unc_tot_max_fact))
    unc.summary[p,9]   <- as.numeric(u.row$unc_tot_min_fact)
    unc.summary[p,10]  <- as.numeric(u.row$unc_tot_max_fact)
    
  }
  
  names(unc.summary) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max')
  
  save(unc.summary,      file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_Emission_unc.Rdata'))
  write.csv(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_Emission_unc.csv'))
  
  return(unc.summary)
} 
  