

# install.packages("plot3D")
#install.packages("ggridges")

library("plot3D")
library(ggridges)
library(ggplot2)
library(reshape2)
library(RColorBrewer)
library(dplyr)
library(EnvStats)


theme_set(theme_ridges())
data <- read.csv('D:\\work\\GhG_move\\VERIFY\\synthesis\\data\\test1_BU_TD_CH4_EU28_2015.csv')
ns <- 10000

mean_BU <- data[data$type=='BU'|data$type=='REF' ,'CH4_EU28']
# sd_BU <- c(3000,6800,2550) #gains, EDGAR,UNFCCC
sd_BU <- c(1500,2124,675) #0.675) #gains, EDGAR,UNFCCC
BUmean <- log(mean_BU^2 / sqrt(sd_BU^2 + mean_BU^2))          # https://gist.github.com/msalganik/7d8762e69b3954b3a5a2ec437f62d6e9
BUsd <- sqrt(log(1 + (sd_BU^2 / mean_BU^2)))

TD <- data[data$type=='TD' ,'CH4_EU28']
TD_median <- median(TD)
TD_sd <- sqrt(var(TD))
TDmean <- log(TD_median^2 / sqrt(TD_sd^2 + TD_median^2))      # https://gist.github.com/msalganik/7d8762e69b3954b3a5a2ec437f62d6e9
TDsd <- sqrt(log(1 + (TD_sd^2 / TD_median^2)))
# colnames(norm.mat) <- paste0('emi',as.character(seq(1:ncol(norm.mat))) )
TD3 <- TD[-which(TD==max(TD))]
TD3_median <- median(TD3)
TD3_sd <- sqrt(var(TD3))
TD3mean <- log(TD3_median^2 / sqrt(TD3_sd^2 + TD3_median^2))  # https://gist.github.com/msalganik/7d8762e69b3954b3a5a2ec437f62d6e9
TD3sd <- sqrt(log(1 + (TD3_sd^2 / TD3_median^2)))


lmean <- c(BUmean, TDmean,TD3mean)
lsd <- c(BUsd,TDsd,TD3sd )

# norm.mat <- mapply(function(x,y){rlnorm(x,y,n=ns)},x=lmean, y=lsd)

min.t <- c(0,0,0,min(TD),min(TD3))
norm.mat <- mapply(function(x,y,z){rlnormTrunc(meanlog=x,sdlog=y,n=ns, min=z)},x=lmean, y=lsd, z=min.t)
norm.mat <- data.frame(norm.mat)
names(norm.mat) <- c(as.character(data[data$type=='BU'|data$type=='REF' ,'y_2015']), 'top_down4','top_down3')
# now deal with Top Down

dd <- melt(norm.mat)

#dd$type <- ifelse(dd$variable=='top_down','TD',ifelse(dd$variable=='UNFCCC','REF','BU'))


# dd1 <- dd[-which(dd$variable=='UNFCCC'),]
# dd1$variable <- factor(dd1$variable)
# dd2 <- dd[dd$variable=='UNFCCC',]
# dd2$variable <- factor(dd2$variable)

myPalette <- colorRampPalette(rev(brewer.pal(11, "Spectral")))
 
 
 
 inv_lines<- data.frame(variable = c('UNFCCC', "EDGARv5", "GAINS", "top_down4",'top_down3'),
                        x0 = c(18370.53, 23609.00, 16087, TD_median,TD3_median))
 inv_lines$median <- 'median'
 
 myorder <- c('UNFCCC', "EDGARv5", "GAINS", "top_down4",'top_down3')
 
 dd <- dd %>% mutate(variable = factor(variable, levels = rev(myorder)))
#  dd$variable <- factor(dd$variable, levels=c('UNFCCC', "EDGARv5", "GAINS", "top_down"))
 inv_lines <- inv_lines %>% mutate(variable = factor(variable, levels = rev(myorder)))
 
# https://stackoverflow.com/questions/56640360/how-to-add-geom-segment-to-geom-density-ridges-gradient
# https://cran.r-project.org/web/packages/ggridges/vignettes/introduction.html
p <- ggplot(dd,aes(x = value, y = variable, fill=(..quantile..)),variable) +
  
     geom_density_ridges_gradient(
       jittered_points = FALSE, calc_ecdf = TRUE, 
                                quantile_lines = c(TRUE),
                                quantiles =c(0.025,0.975),
                                scale=1.5, color='grey50', size=0.3) + #xlim(0,60000) + 
     geom_segment(data = inv_lines, 
                  aes(x = x0, xend = x0, fill='median',
                   y = as.numeric(variable),
                   yend=as.numeric(variable)  + c(1.5,.4,.5,0.25,0.25)),
                   color = "red", inherit.aes = F) +  #scale_y_discrete(expand = c(0.01, 0)) +
     # scale_color_manual(name = "quantile",
     #               limits = c(1, "median"),
     #               values = alpha("firebrick1", c(1,0)),
     #               labels = c( "IQR", "median")) +
     scale_fill_manual(name = "quantile",
                      limits = c(1:2, "median"),
                      values = c('gray70', "cadetblue",'red'), 
                      na.value = "gray60",
                      labels = c( 'Tails', "95% CI", "median")) +
     scale_x_continuous(breaks=seq(0,60000,10000), expand=c(0,0), limits=c(0,60000))+
     annotate('point', x=TD, y=2.1,  color=myPalette(1), size=5, shape='+') +
     annotate('point', x=TD3, y=1.1, color=myPalette(1), size=5, shape='+') +
#  scale_x_continuous(expand = c(0, 0)) +
#  scale_y_discrete(expand = expand_scale(mult = c(0.01, .7)))+
     
     annotate('text', x=45000, y=2.5, color=myPalette(2), size=4,                  # top down4
              label='+ Top down ensemble distribution \n sampled from 4 models') + 
     annotate('text', x=45000, y=1.5, color=myPalette(2), size=4,                  # top down3
          label='+ Top down ensemble distribution \n sampled from 3 models \n (excluding Flexinvert_NILU)') +
     annotate('text', x=45000, y=5.4, color=myPalette(2), size=4,                  # UNFCCC
           label='UNFCCC includes LULUCF ') +          # 
     annotate('text', x=45000, y=4.4, color=myPalette(2), size=4,                  # EDGAR
           label='anthropogenic only') +
     annotate('text', x=43000, y=3.4, color=myPalette(2), size=4,                  # GAINS
           label='anthropogenic only; \nassumed sd of 20%')               +
     
     labs(title = 'EU28 emissions CH4 2015') +
     xlab('CH4 emissions kT') + ylab('') 


ggsave( filename = 'D:\\work\\GhG_move\\VERIFY\\synthesis\\Truncated_LN_CH4_EU28_2015.png', p,
        width = 10, height = 8, dpi = 300, units = "in", device='png')

# https://stats.stackexchange.com/questions/12209/percentage-of-overlapping-regions-of-two-normal-distributions
# https://stats.stackexchange.com/questions/78849/measure-for-separability/78855#78855
separability.measures <- function ( Vector.1 , Vector.2 ) {
  # convert vectors to matrices in case they are not
  Matrix.1 <- as.matrix (Vector.1)
  Matrix.2 <- as.matrix (Vector.2)
  # define means
  mean.Matrix.1 <- mean ( Matrix.1 )
  mean.Matrix.2 <- mean ( Matrix.2 )
  # define difference of means
  mean.difference <- mean.Matrix.1 - mean.Matrix.2
  # define covariances for supplied matrices
  cv.Matrix.1 <- cov ( Matrix.1 )
  cv.Matrix.2 <- cov ( Matrix.2 )
  # define the halfsum of cv's as "p"
  p <- ( cv.Matrix.1 + cv.Matrix.2 ) / 2
  # --%<------------------------------------------------------------------------
  # calculate the Bhattacharryya index
  bh.distance <- 0.125 *t ( mean.difference ) * p^ ( -1 ) * mean.difference +
    0.5 * log (det ( p ) / sqrt (det ( cv.Matrix.1 ) * det ( cv.Matrix.2 )
    )
    )
  # --%<------------------------------------------------------------------------
  # calculate Jeffries-Matusita
  # following formula is bound between 0 and 2.0
  jm.distance <- 2 * ( 1 - exp ( -bh.distance ) )
  # also found in the bibliography:
  # jm.distance <- 1000 * sqrt (   2 * ( 1 - exp ( -bh.distance ) )   )
  # the latter formula is bound between 0 and 1414.0
  # --%<------------------------------------------------------------------------
  # calculate the divergence
  # trace (is the sum of the diagonal elements) of a square matrix
  trace.of.matrix <- function ( SquareMatrix ) {
    sum ( diag ( SquareMatrix ) ) }
  # term 1
  divergence.term.1 <- 1/2 * trace.of.matrix (( cv.Matrix.1 - cv.Matrix.2 ) * 
                                                ( cv.Matrix.2^ (-1) - cv.Matrix.1^ (-1) )
  )
  # term 2
  divergence.term.2 <- 1/2 * trace.of.matrix (( cv.Matrix.1^ (-1) + cv.Matrix.2^ (-1) ) *
                                                ( mean.Matrix.1 - mean.Matrix.2 ) *
                                                t ( mean.Matrix.1 - mean.Matrix.2 )
  )
  # divergence
  divergence <- divergence.term.1 + divergence.term.2
  # --%<------------------------------------------------------------------------
  # and the transformed divergence
  transformed.divergence  <- 2 * ( 1 - exp ( - ( divergence / 8 ) ) )
  indices <- data.frame(
    jm=jm.distance,bh=bh.distance,div=divergence,tdiv=transformed.divergence)
  return(indices)
}
}




#  w <- ggplot(data=dd2, aes(x=value, y=variable,fill=(..quantile..))) +
#    geom_density(
#      jittered_points = FALSE, 
#      calc_ecdf = TRUE, 
#      quantile_lines = c(TRUE),
#      quantiles =c(0.05,0.95),
#      scale=0., color='white', size=0.3)+ xlim(-50,60000) + 
#      theme(axis.title.y=element_blank() ,axis.title.x=element_blank()  )+ 
#    scale_color_manual(name = "quantile",
#                       limits = c(1, "median"),
#                       values = alpha("firebrick1", c(1,0)),
#                       labels = c( "IQR", "median")) +
#    scale_fill_manual(name = "quantile",
#                      limits = c(1:2, "median"),
#                      values = c('gray30', "cadetblue",'red'), 
#                      na.value = "gray30",
#                      labels = c( 'NA', "95% CI", "median"))
# 
#     
# 
# pga <- grid.arrange(p, w, ncol = 1, nrow = 2, heights = c(8.25,1.75) )#, heights = 3)


#mean_se(log(lcomb$value))
#
#w+geom_point()+stat_summary(fun.y='median', fun.ymin = min, fun.ymax = max) ,
#                                                        colour = c("red", 'black', 'green' ) )

ModifiedCox <- function(x){ #https://tonyladson.wordpress.com/2016/02/05/confidence-interval-for-the-mean-of-non-normal-data/
  n <- length(x)
  y <- log(x)
  y.m <- median(y)
  y.var <- var(y)
  
  my.t <- qt(0.975, df = n-1) # 95% Confidence interval
  
  my.mean <- median(x)
  upper <- y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  lower <- y.m + y.var/2 - my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  
  return(list(upper = exp(upper), mean = my.mean, lower = exp(lower)))
  
}

ModifiedCox_efi <- function(x){ # based on bond et al paper
  n <- length(x)
  y <- log(x)
  y.m <- mean(y)
  y.sd <- sqrt(var(y))
  
  my.t <- qt(0.975, df = n-1) # 95% Confidence interval
  
  my.mean <- mean(x)
 # upper <- y.m + (y.sd/sqrt(n-1))*my.t   #   y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
#  lower <-  y.m - (y.sd/sqrt(n-1))*my.t 
  upper <- y.m + (y.sd)*my.t   #   y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  lower <-  y.m - (y.sd)*my.t 
  
  return(list(upper = exp(upper), mean = my.mean, lower = exp(lower)))
  
}



# 
# set.seed(123)
# draws1 <- rlnorm(n = 1000000, mean = 7, sd = 75)
# mean(draws1)
# sd(draws1)
# 
# draws2 <- rlnorm(n = 1000000, meanlog = log(7), sdlog = log(75))
# mean(draws2)
# sd(draws2)
# 
# m <- 7
# s <- 75
# location <- log(m^2 / sqrt(s^2 + m^2))
# shape <- sqrt(log(1 + (s^2 / m^2)))
# print(paste("location:", location))
# print(paste("shape:", shape))
# draws3 <- rlnorm(n = 1000000, location, shape)
# mean(draws3)
# sd(draws3)
# plot(density(draws3[draws3 < 20]))





