
#functions ---- 
library('miceadds') ; library('dplyr')
library('reshape2')
library('ggplot2')
library('ggthemes')
source('aggregate_GHG_functions.R')


#script starts---- 
# out.dir <- "C:\\Users\\efsolazzo\\Google Drive\\VERIFY\\ghg_edgar\\"



out.dir <- "D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\"

g1.CO2 <- loadRData(file=paste0(out.dir,'CO2\\','emi_by_category_EDGAR__CO2_UncCorr_2015_emi_by_categories.Rdata'))
g1.N2O <- loadRData(file=paste0(out.dir,'N2O\\','emi_by_category_EDGAR__N2O_UncCorr_2015_emi_by_categories.Rdata'))
g1.CH4 <- loadRData(file=paste0(out.dir,'CH4\\','emi_by_category_EDGAR__CH4_UncCorr_2015_emi_by_categories.Rdata'))

#food# 
g1.CH4 <- loadRData(file=paste0(out.dir,'CH4_emi_by_categories.Rdata'))
g1.N2O <- loadRData(file=paste0(out.dir,'N2O_emi_by_categories.Rdata'))
g1.CO2 <- loadRData(file=paste0(out.dir,'CO2_emi_by_categories.Rdata'))


g2.CO2 <- f.prepare_data(g1.CO2, 'magnitude'); g2.N2O <- f.prepare_data(g1.N2O, 'magnitude') ; g2.CH4 <- f.prepare_data(g1.CH4, 'magnitude') # asym unc (magnitude)
g2.CO2.EU <- f.prepare_data(g1.CO2, 'perc')  ; g2.N2O.EU <- f.prepare_data(g1.N2O, 'perc'); g2.CH4.EU <- f.prepare_data(g1.CH4, 'perc') # rel unc (%)

g2 <- list(g2.CO2,g2.CH4,g2.N2O) ; g2.EU <- list(g2.CO2.EU,g2.CH4.EU,g2.N2O.EU)
names(g2) <- c('CO2','CH4','N2O'); names(g2.EU) <- c('CO2','CH4','N2O')
g2.tot    <- melt(g2,id.vars=c('country','emi','asym.unc.min','asym.unc.max', 'sector'))
# p0 <- f.plot_all_countries(g2.tot)
g2.EU.tot <-  melt(g2.EU,id.vars=c('country','emi','rel.unc.min','rel.unc.max', 'sector'))
# extract EU28 ----
# ************************************************* 
# generate the inventory for EU28, that is the emission from each fuel/category and associate the uncertanty from
# any EU28 country (set to Austria in function )
# starts from unc.table
EU28.cc <- f.get_country_code(EU28)
g2.EU28 <- g2.EU.tot[g2.EU.tot$country %in%  EU28.cc,]

EU28.GHG.sector <- f.EU28_calc(g2.EU28, 'Tier1'); EU28.GHG.sector$tier <- rep('Tier1', length(EU28.GHG.sector$sector))
EU28.GHG.sector.2 <- f.EU28_calc(g2.EU28, 'Tier2') ; EU28.GHG.sector.2$tier <- rep('Tier2', length(EU28.GHG.sector.2$sector))
EU28 <- merge(EU28.GHG.sector, EU28.GHG.sector.2, by=intersect(names(EU28.GHG.sector), names(EU28.GHG.sector.2)), all=T)
u1.EU28 <-EU28 %>% group_by( sector, tier) %>% mutate(comb_unc_max = f.tot_unc(emi,asym.unc.max, F),
                                                       comb_unc_min = f.tot_unc(emi,asym.unc.min, F),
                                                       emi.tot = sum(emi, na.rm=T))

p1<- ggplot(data=EU28) +  geom_bar(aes(x=sector,y=emi,  fill=L1),position='stack', stat='identity') + coord_flip()+
  facet_grid( tier~.)+#, scale='free') +
  geom_errorbar(data=u1.EU28, aes(x=sector, ymin=emi.tot-comb_unc_min*emi.tot, ymax=emi.tot+comb_unc_max*emi.tot))+
  #  facet_grid( country~.) + 
  # ylim(-100,1.5e+07) +
  theme_hc() +
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
  ylab( paste0(' EDGAR GHG emission 2015 (kTonnes/year)' ) )+ 
  #   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
  # coord_polar(start = 0)
  theme(legend.position="bottom")
#poster----
datap=EU28[EU28$tier=='Tier1',]
datap <- datap[-which(datap$sector=='IRO' | datap$sector=='AWB' | datap$sector=='TNR' | datap$sector=='TRF'),] 
uncp <- u1.EU28[u1.EU28$tier=='Tier1',]
uncp <- uncp[-which(uncp$sector=='IRO' | uncp$sector=='AWB' | uncp$sector=='TNR' | uncp$sector=='TRF'),] 
poster <- ggplot(datap) +  geom_bar(aes(x=sector,y=emi,  fill=L1),position='stack', stat='identity') + coord_flip()+
#  facet_grid( tier~.)+#, scale='free') +
  geom_errorbar(data=uncp, aes(x=sector, ymin=emi.tot-comb_unc_min*emi.tot, ymax=emi.tot+comb_unc_max*emi.tot))+
  #  facet_grid( country~.) + 
  # ylim(-100,1.5e+07) +
  theme_hc() +
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
  ylab( paste0(' EDGAR GHG emission 2015 (kTonnes/year)' ) )+ 
  #   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
  # coord_polar(start = 0)
  theme(legend.position="bottom")

ggsave(filename='D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\GHG\\EU28_poster.png',
       plot = poster ,dpi=150,type='cairo')

# ---- total EU28
# g2.EU.tot <- na.omit(unique(g2.EU.tot))
EU28w <- EU28 %>% group_by(tier, L1) %>% summarise(unc.max = f.aggregate_subcategory.tot(emi,unc.max, FALSE),
                                                unc.min = f.aggregate_subcategory.tot(emi,unc.min, FALSE),
                                                    emi = sum(emi, na.rm=T))
#  gh <- na.omit(unique(gh))
EU28w <- data.frame(EU28w); EU28w <- na.omit(unique(EU28w))

EU28wu <- EU28w %>% group_by(tier) %>% summarise(comb_unc_max = f.tot_unc(emi,unc.max, T),
                                                 comb_unc_min = f.tot_unc(emi,unc.min, T),
                                                      emi.tot = sum(emi, na.rm=T)) 
EU28wu <- data.frame(EU28wu); EU28wu <- na.omit(unique(EU28wu))
EU28wu$perc <- paste(as.character(round(100*(EU28wu$comb_unc_max+EU28wu$comb_unc_min)/2,1)), '%')
EU28w$country <- rep('EU28', length(EU28w$L1)) ; EU28wu$country <- rep('EU28', length(EU28wu$tier))

p2 <- ggplot(EU28w) + geom_bar(aes(x=country,y=emi,  fill=L1),position='stack', stat='identity') +
  facet_grid(tier~.) +#, scale='free') +
  geom_errorbar(data=EU28wu, aes(x=country, ymin=emi.tot-comb_unc_min*emi.tot, ymax=emi.tot+comb_unc_max*emi.tot))+
  scale_y_continuous(position = "right")+
  theme_hc() +
  theme(axis.title.y=element_blank(), legend.title = element_blank(), axis.title.x=element_blank())+
  theme(legend.position="none")+
  geom_label(data=EU28wu, aes(label= perc, x= country,  y=5.15e+06),     color = "black",
            fill="#69b3a2") +
  theme(
    strip.background = element_blank(),
    strip.text.y =  element_blank() ,  
    plot.margin = margin(0, 0, 2, 0, "cm"))


# pt <- grid.arrange(p3, p2, ncol = 1, nrow = 2, widths = c(8.,2) )#, heights = 3)

 pga <- grid.arrange(p1, p2, ncol = 2, nrow = 1, widths = c(8.,2) )#, heights = 3)

ggsave(filename='D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\GHG\\EU_28_tier_plus_whole.png',
       plot = pga ,dpi=150,type='cairo')


g2.subset <- g2.tot[(g2.tot$country =='USA' | g2.tot$country =='CHN' ),] # | g2.tot$country == 'IDN'),]
g2.plot <- unique(g2.subset); g2.plot <- na.omit(g2.plot)
EU28.GHG.country <- data.frame(EU28.GHG.country)
EU28.GHG.sector$asym.unc.max<-EU28.GHG.sector$asym.unc.max
EU28.GHG.sector$asym.unc.min<-EU28.GHG.sector$asym.unc.min
EU28.GHG.sector$unc.max <- NULL ; EU28.GHG.sector$unc.min <- NULL 


EU28.GHG.sector$country <- rep('EU28', length(EU28.GHG.sector$sector))
g3.plot <- merge(EU28.GHG.sector, g2.plot, by=intersect(names(EU28.GHG.sector), names(g2.plot)), all=T)


u1 <- g3.plot %>% group_by(country, sector) %>% mutate(comb_unc_max = f.tot_unc(emi,asym.unc.max, F),
                                                       comb_unc_min = f.tot_unc(emi,asym.unc.min, F),
                                                       emi.tot = sum(emi, na.rm=T))

#  ----
chn   <- f.extract_country_var(g2.EU.tot, 'CHN') 
usa   <- f.extract_country_var(g2.EU.tot, 'USA') 
world <- f.extract_country_var(g2.EU.tot, 'world') 

# ----



p1 <- ggplot(data=g3.plot)+
  geom_bar(aes(x=sector,y=emi,  fill=L1),position='stack', stat='identity') +
  facet_grid( country~.)+#, scale='free') +
  geom_errorbar(data=u1, aes(x=sector, ymin=emi.tot-comb_unc_min*emi.tot, ymax=emi.tot+comb_unc_max*emi.tot))+
#  facet_grid( country~.) + 
  # ylim(-100,1.5e+07) +
  theme_hc() +
   theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
  ylab( paste0(' EDGAR GHG emission 2015 (kTonnes/year)' ) )+ 
#   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
  # coord_polar(start = 0)
   theme(legend.position="bottom")




# g3 <- na.omit(unique(g2.tot))  
# u2 <- g3%>% group_by(country) %>% summarise(emi.tot = sum(emi, na.rm=T))
# 
# 
# # from g1.tot
# tot.emi.world <- lapply(g1.tot, function(x){sum(x$tot.subcat, na.rm=T)})
# unc.min <- lapply(g1.tot, function(x){f.aggregate_subcategory.tot(x$tot.subcat, x$rel.unc.min, TRUE)})
# unc.max <- lapply(g1.tot, function(x){f.aggregate_subcategory.tot(x$tot.subcat, x$rel.unc.max, TRUE)})

