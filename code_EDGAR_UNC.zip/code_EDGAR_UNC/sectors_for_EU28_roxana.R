# ROXANA 28 march 2019: 
# total uncertainty for each individual countries 
# also EU total!!!!
# add Norway and Switzerland 

EU28.cc    <- f.get_country_code(EU28)
EU28_NS.cc <- f.get_country_code(EU28_NS)

emi.keys.0 <- c('1.A','1.B.1','1.B.2','2','3.A.1','3.A.2','3.C.7','4.A','4.D')

# unc.table1 <- loadRData (file=paste0(out.dir,'CH4_Emission_unc.Rdata'))

g1 <- loadRData( file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr, '_', sYear,'emi_by_categories.Rdata')) # by sector

g2.tot <- load(paste0(out.dir,sCatAgg,sCatEmi, '_', now_run, '_',sUncCorr, 'emi_tot_by_country.Rdata')) # by country (created in MAin)
          
#*************************************************

#extract EU28 countries

g.c <- lapply(g1, function(x){x[x$country %in%  EU28.cc,]}) 
 # or 
g.c <- subset(g2.tot, country %in% EU28.cc)

#  ***** start running from here when looking at different Edgar version
## debug ( not rellay a debug, but more a on-the-fly run )

 #  g.c <- lapply(g1.tot, function(x){x[x$country %in%  EU28.cc,]})

## end debug 


# g2    <- melt(g.c, id.vars=c('country', 'tot.subcat','asym.unc.min','asym.unc.max'))

# save(g2, file=paste0(out.dir,'CH4_EDGAR_EU28.Rdata'))
# save(g2, file=paste0(out.dir,'CH4_EDGAR_v42_EU28.Rdata'))
# write.csv(g2, file=paste0(out.dir,'CH4_EDGAR_EU28.csv'))

#emi.EU28 <- g2 %>% group_by(L1) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
#                                emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
#                                emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )


# EU28 total by category

g3  <- do.call('rbind', g.c) 
g3$cat <- as.character(rep(names(g.c),  sapply(g.c, lengths)[1,]))

save(g3, file=paste0(out.dir,'CH4_EDGAR_EU28_', sYear, '.Rdata'))
write.csv(g3, file=paste0(out.dir,'CH4_EDGAR_EU28', sYear,'.csv'))
EU28.corr   <- f.aggregate.EU28(g3, FALSE) # FALSE = correlated
EU28.uncorr <- f.aggregate.EU28(g3, TRUE ) # TRUE = uncorrelated

# produce EU total as if EU was one country and use the median country uncertainty for each sector
EU28.one.entry.cat <- g3 %>% group_by(cat) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                                      unc.min <- median(asym.min.perc, na.rm=T),
                                                      unc.max <- median(asym.max.perc, na.rm=T))

names(EU28.one.entry.cat) <- c('category','emission','unc.min.perc','unc.max.perc')
EU28.one.entry.tot <- data.frame( 'category'='EU28','emission'= sum(EU28.one.entry.cat$emission, na.rm=T), 'unc.min.perc'=-.15,'unc.max.perc'=17)

EU28.one.entry <- merge(EU28.one.entry.cat,EU28.one.entry.tot,all=T)
#*******************************************************************************

EU.tot.corr   <- f.EU.total(g3, FALSE)
EU.tot.uncorr <- f.EU.total(g3, TRUE)

EU.tot <- rbind(EU.tot.corr,EU.tot.uncorr)
EU.tot$group <- c('corr','uncorr')
EU.tot$country <- c('EU28', 'EU28')
 
# plotting
EU28.corr$group='correlated' ; EU28.uncorr$group="uncorrelated"; 
EU28.one.entry.cat$group<-'EU_as_whole'; 
EU28.one.entry.cat <- data.frame(EU28.one.entry.cat)
EU28.one.entry.cat$min <- EU28.one.entry.cat[,2]*(1-abs(EU28.one.entry.cat[,3]))
EU28.one.entry.cat$max <- EU28.one.entry.cat[,2]*(1+abs(EU28.one.entry.cat[,4]))
bb <-  rbind(EU28.corr, EU28.uncorr)
bb$unc.emi.cat.min <- NULL
bb$unc.emi.cat.max <- NULL
bb$country <- NULL
names(bb) <- c('category','emission', 'min','max','group')
bb$max[9]  <- bb$emission[9]*bb$max[8]/bb$emission[8]
bb$max[18] <- bb$emission[18]*bb$max[17]/bb$emission[17]

EU28.one.entry.cat$unc.min.perc <- NULL
EU28.one.entry.cat$unc.max.perc <- NULL

bb <-rbind(bb,EU28.one.entry.cat)

p <- ggplot(data=bb, aes(x=category,y=emission, group=group))+
   geom_pointrange(aes(ymin=min,ymax=max,color=group), position=position_dodge(width=0.6), size=1)+
   theme(legend.position = 'bottom',
         legend.title = element_blank(),
         axis.title.x = element_blank(),
         text=element_text(size=18))+
   ggtitle('CH4 emission EU28 - 2012')


w <-ggplot(data=EU.tot, aes(x=country,y=emi.tot.cat))+
          geom_pointrange(aes(ymin=CImin,ymax=CImax,color=group), position=position_dodge(width=0.6), size=1) +
  ylim(0,NA)+   xlab('') +
  theme(axis.title.y=element_blank(), text = element_text(size = 16),plot.title = element_text(size = 14, face = "bold"))+
  theme(legend.position = "none")


pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.,2) )#, heights = 3)

 ggsave(filename=paste0(fig.dir, 'CH4_EU_28.png'),
        plot = pga ,dpi=150,type='cairo')

 rpivotTable(emi.EU28)

tmp<-data.frame(g3)

write.csv(tmp, file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\EU28_category_countries.csv')

detach(package:plyr)
f.aggregate.EU28 <- function(hold.g, bCorr){
  emi.EU28 <- hold.g %>% group_by(cat) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                                    emi.unc.tot.min = f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, bCorr), # FALSE = correlated
                                                    emi.unc.tot.max = f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, bCorr) )
  
  
  
  # emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
  #                                  emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
  #                                 emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )
  
  names(emi.EU28) <- c('category', 'emi.tot.cat','unc.emi.cat.min', 'unc.emi.cat.max' )
  
  # names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.EU28, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  for (i in 1:length(CI.range.cat)/2){
    emi.EU28[i,5] <- emi.EU28$emi.tot.cat[i]*(1-abs(CI.range.cat[i]))#/1000
    emi.EU28[i,6] <- emi.EU28$emi.tot.cat[i]*(1+CI.range.cat[i+10])#/1000
  } 
  emi.EU28$country <- 'EU28'
  emi.EU28$emi.tot.cat <- emi.EU28$emi.tot.cat#/1000
  # ****
  
  return(emi.EU28)
  
} # end function

f.aggregate.EU28.country <- function(hold.g, bCorr){
  emi.EU28 <- hold.g %>% group_by(country) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                                     emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, bCorr), # FALSE = correlated
                                                     emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, bCorr) )
  
  
  
  # emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
  #                                  emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
  #                                 emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )
  
  names(emi.EU28) <- c('category', 'emi.tot.cat','unc.emi.cat.min', 'unc.emi.cat.max' )
  
  # names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.EU28, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  for (i in 1:length(CI.range.cat)/2){
    emi.EU28[i,5] <- emi.EU28$emi.tot.cat[i]*(1-abs(CI.range.cat[i]))#/1000
    emi.EU28[i,6] <- emi.EU28$emi.tot.cat[i]*(1+CI.range.cat[i+10])#/1000
  } 
  emi.EU28$country <- 'EU28'
  emi.EU28$emi.tot.cat <- emi.EU28$emi.tot.cat#/1000
  # ****
  
  return(emi.EU28)
  
} # end function


f.EU.total <- function(cat0, bFlag){
  # EU total by category
  emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                    emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, bFlag), # FALSE = correlated
                                    emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, bFlag) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1]))/1000)
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2])/1000)
  emi.tot.cat$country <- 'EU28'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat/1000
  # ****
  # end EU  total
  return(emi.tot.cat)
}


f.EU.total.2 <- function(cat0){
  # EU total by category
  emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                    emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # = correlated
                                    emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1])))
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2]))
  emi.tot.cat$country <- 'EU28_NS'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat
  # ****
  # end EU  total
  return(emi.tot.cat)
}

EU28_NS_tot <- f.EU.total.2(g.c)

g.c[nrow(g.c) + 1,] = list(country="EU28_NS",
                           tot.country=EU28_NS_tot$emi.tot.cat, 
                           rel.unc.min= EU28_NS_tot$unc.emi.cat.min,
                           rel.unc.max= EU28_NS_tot$unc.emi.cat.max, 
                           asym.unc.min=EU28_NS_tot$CImin,
                           asym.unc.max=EU28_NS_tot$CImax)
write.csv(g.c, file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\EU28_countries_tot_countries.csv')

#---- update ocober 2019 ----

# get g1.tot for methane from main (based on ipcc06 not processes)

g2.cc <- f.prepare_data(g1.tot, 'perc')  # rel unc (%)

#g2 <- list(g2.CO2,g2.CH4,g2.N2O) ; g2.EU <- list(g2.CO2.EU,g2.CH4.EU,g2.N2O.EU)
#names(g2) <- c('CO2','CH4','N2O'); names(g2.EU) <- c('CO2','CH4','N2O')
g2.EU.tot <-  melt(g2.cc,id.vars=c('country','emi','rel.unc.min','rel.unc.max', 'sector'))
# extract EU28 
# ************************************************* 
# generate the inventory for EU28, that is the emission from each fuel/category and associate the uncertanty from
# any EU28 country (set to Austria in function )
# starts from unc.table
EU28.cc <- f.get_country_code(EU28)
g2.EU28 <- g2.EU.tot[g2.EU.tot$country %in%  EU28.cc,]

EU28.GHG <- unique(g2.EU28)

  
  
  EU28.GHG.sector <- EU28.GHG %>% group_by(sector) %>% 
    summarise(unc.max = f.aggregate_subcategory.tot(emi,rel.unc.max, FALSE),
              unc.min = f.aggregate_subcategory.tot(emi,rel.unc.min, FALSE),
              emi = sum(emi, na.rm=T))

EU28.GHG.sector <- data.frame(EU28.GHG.sector)
CI.range <-  apply(EU28.GHG.sector,1, function(x){f.asymmetric_unc(x[3],x[2],x[4])})
#minCI <- CI.range[1]
#maxCI <- CI.range[2]
EU28.GHG.sector$asym.unc.min <- EU28.GHG.sector$emi*(1- abs(CI.range[1,])) #CI.range[1] should be negative for asymmetric distribution
EU28.GHG.sector$asym.unc.max <- EU28.GHG.sector$emi*(1+ CI.range[2,])
# write.csv(EU28.GHG.sector, file=paste0('D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\EU28_methane_',sYear,'_sector.csv'))
write.csv(EU28.GHG.sector, file=paste0('D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\EU28_N2O_',sYear,'_sector.csv'))

if (now_run=='CH4' | now_run == 'methane') {
  EU28_country <- EU28.GHG[(EU28.GHG$sector=='3.A.1' | EU28.GHG$sector=='3.A.2' | EU28.GHG$sector=='3.C.7' | EU28.GHG$sector=='3.C.1'),  ]
} else if ( now_run == 'N2O' ){
  EU28_country <- EU28.GHG[(EU28.GHG$sector=='3.A' | EU28.GHG$sector=='3.C.1' | EU28.GHG$sector=='3.C.4' 
                                                                                 | EU28.GHG$sector=='3.C.5' | EU28.GHG$sector=='3.C.6'), ]
}

EU28_country_sector <- EU28_country %>% group_by(country) %>% 
  summarise(unc.max = f.aggregate_subcategory.tot(emi,rel.unc.max, TRUE),
            unc.min = f.aggregate_subcategory.tot(emi,rel.unc.min, TRUE),
            emi = sum(emi, na.rm=T))

EU28_country_sector <- data.frame(EU28_country_sector)
write.csv(EU28_country_sector, file=paste0('D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\Country_',now_run, '_',sYear,'_sector.csv'))
# write.csv(EU28_country_sector, file=paste0('D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\Country_methane_',sYear,'_sector.csv'))

