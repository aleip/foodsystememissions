# https://www.r-bloggers.com/psa-rs-rnorm-and-mvrnorm-use-different-spreads/
# R has two commonly-used random-Normal generators: rnorm and MASS::mvrnorm. 
# I was foolish and assumed that their parameterizations were equivalent 
# when you're generating univariate data. But nope:
#   
# Base R can generate univariate draws with rnorm(n, mean, sd), 
# which uses the standard deviation for the spread.

# The MASS package has a multivariate equivalent, mvrnorm(n, mu, Sigma), 
# which uses the variance-covariance matrix for the spread. In the univariate case, Sigma is the variance.
# I was using mvrnorm to generate a univariate random variable, but giving it 
# the standard deviation instead of the variance. It took me two weeks of debugging to find this problem.
# ***

emi1 <- vector()
emi2 <- vector()

#for (i in 1:10){
  ad <- rnorm(1000, mean=5,  sd=0.05) # sd half the 95% CI; sd is not the percentage uncertainty! it has dimensions!
  ef <- rnorm(1000, mean=21, sd=0.5)
  cov1 <- matrix(c(0.05^2,0,0,0.5^2), nrow=2)
  emi1 <- mvrnorm(1000, c(5,21), cov1)
  emi1 <- apply(emi1,1,prod)
#}
  
#for (i in 1:10){
  
  ad <- rnorm(1000, mean=5,  sd=0.1)
  ef <- rnorm(1000, mean=21, sd=0.20) 
  
  emi2 <- ad*ef
#}
sigma1 <- sqrt(var(emi1))
sigma2 <- sqrt(var(emi2))
sd.emi.perc <- vector(); k<-1
for (r in seq(0,1,0.1)){
  
  
  cov.matrix <- matrix(c(sigma1^2, rep(r*sigma1*sigma2,2), sigma2^2), nrow=2  )
  
  sample <- mvrnorm(10000, c(mean(emi1), mean(emi2)), cov.matrix, empirical=F) # use empirical = TRUE to specify empirical 
  # not population parameters for ?? and ??. This 
  # results in the covariance matrix of sample 
  # having exactly the values we specified
  sum    <- rowSums(sample)
  
  unc.MC <- sqrt(var(sum))
  
  sd.emi.perc[k] <- unc.MC/(mean(emi1)+mean(emi2))
  k <- k+1
}
plot(sd.emi.perc)
# sqrt((0.05^2+0.5^2)*mean(emi1)^2+ (0.1^2+0.2^2)*mean(emi2)^2)/((mean(emi1)+mean(emi2)))

sqrt(((0.05/5)^2+(0.5/21)^2)^2+((0.1/5)+(0.2/21)^2)^2)



uEF <- rnorm(10000,1,sd=0.25)  # unc of 50% -> +/- 50% is 95% CI -> mean+2*sigma=1.5 -> sigma=0.25 
uAD <- rnorm(10000,1,sd=0.025) # unc of 5% -> mean+2*sigma= 1.05 -> sigma= 0.05/2 = 0.025

emi <- uEF*uAD 
sqrt(0.5^2 + 0.05^2)
# .... small experiment ....
# small experiment: 5 ADs and EFs to generate emissions. ADs have all the same uncertainty of 5%;
#                   EFs have all the same unc of 50%
#                   1. First do the simple sum of Emis (generated as EF*AD) and look at quantiles
#                   2. Second do the mvrnorm() with covariance matrix diagonal. 
#                        Both cases have non correlation and shall be comparable, this step is necessary to understand 
#                         how to explici the variance in the mvrnorm() (if is var(emi) or var(emi)/2). 
#                         Seems that var(emi) is the right option
#                   3. do the same with full cov matrix          

ef1 <- rnorm(100000,4,sd=1)       ; AD1 <- rnorm(100000,6,sd=6/40)
ef2 <- rnorm(100000,200,sd=50)    ; AD2 <- rnorm(100000,11, sd=11/40)
ef3 <- rnorm(100000,55,sd=13.75)  ; AD3 <- rnorm(100000,0.32, sd=0.32/40)
ef4 <- rnorm(100000,0.7,sd=1.175) ; AD4 <- rnorm(100000,320, sd=320/40)
ef5 <- rnorm(100000,20,sd=5)      ; AD5 <- rnorm(100000,4, sd=4/40)

# emiT <- 4*6 + 200*11 + 55*0.32 + 0.7*320 + 20*4 = 2545.6

ef <- list(ef1, ef2, ef3, ef4, ef5)
ad <- list(AD1, AD2, AD3, AD4, AD5)

emi0 <- 0; sigma2 <- NULL; emi2 <- NULL
for (i in 1:5){
  emi   <- ef[[i]]*ad[[i]]
  sigma2 <- c(sqrt(var(emi)), sigma2)
  emi2 <- c(mean(emi), emi2)
  emi0   <- emi0 + emi # all uncorrelated
}
# case 1
quantile(emi0,probs =c(0, 0.05, 0.95, 0.5))


# case 2
cov.matrix1 <- matrix(c(sigma2[1]^2,0,0,0,0,
                       0, sigma2[2]^2,0,0,0,
                       0,0, sigma2[3]^2, 0,0,
                       0,0,0, sigma2[4]^2, 0,
                       0,0,0,0, sigma2[5]^2),
                      nrow=5  )


sample1 <- mvrnorm(100000, c(emi2[1],emi2[2],emi2[3],emi2[4],emi2[5] ), cov.matrix1, empirical=F) # use empirical = TRUE to specify empirical 
# not population parameters for ?? and ??. This 
# results in the covariance matrix of sample 
# having exactly the values we specified
sum1    <- rowSums(sample1)
quantile(sum1, probs=c(0, 0.05, 0.95, 0.5))


# case 3
cov.matrix <- matrix(c(sigma2[1]^2,sigma2[1]*sigma2[2],sigma2[1]*sigma2[3]  , sigma2[1]*sigma2[4],sigma2[1]*sigma2[5],
                       sigma2[1]*sigma2[2], sigma2[2]^2,sigma2[2]*sigma2[3]  , sigma2[2]*sigma2[4],sigma2[2]*sigma2[5],
                       sigma2[1]*sigma2[3], sigma2[2]*sigma2[3], sigma2[3]^2, sigma2[3]*sigma2[4],sigma2[3]*sigma2[5],
                       sigma2[1]*sigma2[4], sigma2[2]*sigma2[4], sigma2[3]*sigma2[4], sigma2[4]^2, sigma2[4]*sigma2[5],
                       sigma2[1]*sigma2[5], sigma2[2]*sigma2[5], sigma2[3]*sigma2[5], sigma2[4]*sigma2[5], sigma2[5]^2),
                     nrow=5  )


sample <- mvrnorm(100000, c(emi2[1],emi2[2],emi2[3],emi2[4],emi2[5] ), cov.matrix, empirical=F) # use empirical = TRUE to specify empirical 
# not population parameters for ?? and ??. This 
# results in the covariance matrix of sample 
# having exactly the values we specified
sum    <- rowSums(sample)
quantile(sum, probs=c(0, 0.05, 0.95, 0.5))

unc.MC <- sqrt(var(sum))

# ....
# now, would have been the same to have simplified with 5 emissions of one and then multiply the real totasl emisissions
# by the percentage uncertainty?

uEF <- rnorm(10000,1,sd=0.25)  # unc of 50% -> +/- 50% is 95% CI -> mean+2*sigma=1.5 -> sigma=0.25 
uAD <- rnorm(10000,1,sd=0.025) # unc of 5% -> mean+2*sigma= 1.05 -> sigma= 0.05/2 = 0.025

emiS <- uEF*uAD*5 
# var(emiS)
quantile(emiS, probs=c(0, 0.05, 0.95, 0.5))

cov.matrixS <- matrix(c(rep(var(emiS),5),rep(var(emiS),5),rep(var(emiS),5),rep(var(emiS),5),rep(var(emiS),5)),nrow=5  )
cov.matrixS <- cov.matrixS/4
cov.matrixS <- matrix(c(var(emiS)/4,rep(0,4),0,var(emiS)/4,rep(0,3),
                        0,0, var(emiS)/4,0,0,
                        0,0,0, var(emiS)/4,0,
                        0,0,0,0,var(emiS)/4),nrow=5  )


sampleS <- mvrnorm(100000, c(1,1,1,1,1 ), cov.matrixS, empirical=F) # use empirical = TRUE to specify empirical 
# not population parameters for ?? and ??. This 
# results in the covariance matrix of sample 
# having exactly the values we specified
sumS    <- rowSums(sampleS)
quantile(sumS, probs=c(0, 0.05, 0.95, 0.5))
