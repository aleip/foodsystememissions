

#' Title
#'
#' @param cat.emi.country 
#'
#' @return
#' @export
#' E.Solazzo, JRC
#' October 2018
#' @examples
f.plot_cat <- function(cat.emi.country, bPlot){
  
  
  # debug:  
  ## either this 
  # cat.emi.country <- g1.tot
  ## or
  #   cat.emi.country   <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run,  '_', sUncCorr,'emi_by_categories.Rdata') )  # 
  # end debug
  
  
  ## cat.emi.country is g1.tot produced from the main(), that is based on the 'unc.table' produced by 'associate_unc2emi.R'. 
  ## g.tot already went through the 'f.asymmetric_unc()', thus the call should not be replicated here  
  dt.h <- list()
  for (t in 1:length(cat.emi.country)){
    emi.tot.cat <- NULL; cat0 <- NULL  
    sCat <- f.get_emi_cat(emi.keys.0[t])
    
    cat0 <- cat.emi.country[[t]]
    if (all(is.na(cat0))) { next()}
    
    # world's total by category
    emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                      emi.unc.tot.min = f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
                                      emi.unc.tot.max = f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )
    names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
    
    CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
    emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1]))/1000)
    emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2])/1000)
    emi.tot.cat$country <- 'world'
    emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat/1000
    # ****
    # end world  total
    names(country.info) <- c('country','country_ext','group','ind','group_ID')
    
    cat0 <- merge(cat0, country.info, by=c('country'))
    dt <- cat0[order(cat0$tot.subcat, decreasing=T),]
    
    dt$tot.subcat <- dt$tot.subcat/1000
    dt$range <- cut(100*dt$asym.max.perc, breaks=c(0,10,20,40,60,100,Inf), 
                    labels=c('High','Med-High','Medium','Med-Low','Low','Very Low'))
  
#   fdev     <- country.info$ind[which(dt$country %in% country.info$ISO3 ) ]
#   dt$fdev <- fdev
    a <- ifelse(dt$ind=='I', 'red', 'blue')
    
    if(bPlot){
      p <- ggplot(dt[1:35,]) +
        geom_pointrange(aes(x=reorder(country,-tot.subcat), y=tot.subcat, 
                            ymin=asym.unc.min/1000, 
                            ymax=asym.unc.max/1000)) + 
        ylab( paste0(now_run,' EDGAR emission (Tg)' )) +  xlab('')    +
        ggtitle(paste0('EDGAR ',now_run,' ', sYear, ' - ' , emi.keys.0[t], ': ', sCat))+
        theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5, color=a),
              text = element_text(size = 14), 
              plot.title = element_text(size = 14, face = "bold")) + 
        ylim(0,max(dt$tot.subcat*(1+dt$asym.max.perc), na.rm=T)*1.075)  +
        geom_text(data=dt[1:35,], aes(x=reorder(country,-tot.subcat), y=max((tot.subcat*(1+asym.max.perc))*1.03, na.rm=T), 
                                       label=paste0('+',as.character(round (100*asym.max.perc,0)),'%'), 
                                      color=range),angle=90,show.legend = FALSE) +
        geom_point(data=dt[1:35,], aes(x=reorder(country,-tot.subcat), y=max((tot.subcat*(1+asym.max.perc))+10, na.rm=T), 
                                       color=range), alpha = 0) +
        guides(colour = guide_legend("Confidence", override.aes = list(size = 7, alpha = 1))) +
        theme(legend.position = c(0.85, 0.6))
        
      
      
      w <- ggplot(data=emi.tot.cat) +
        geom_pointrange(aes(x=country, y=emi.tot.cat, 
                            ymin=CImin , 
                            ymax=CImax), 
                        color='blue' )+ 
        ylim(0,NA)+
        xlab('') +theme(axis.title.y=element_blank(),   
                        text = element_text(size = 14))
      
      
      pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)
      
      ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,sCat,'_total_emission.png'),
             device='png', width = 12, height = 7.5, units = "in",
             dpi = 260, pga)
      
    }else {
      dt.h <- list.append(dt.h, dt)
    
    }
  }
  
  return(dt.h)
} # end function


f.plot_country <- function(tot.emi.country){
  # debug:  
  ## either this 
  # tot.emi.country <- g2.tot
  ## or
  #   tot.emi.country   <- loadRData(file=paste0(out.dir,sCatAgg,sCatEmi, '_', now_run, '_',sUncCorr, 'emi_tot_by_country.Rdata') )  # 
  # end debug                        
  
  # world's total by category
  emi.tot.cat <- tot.emi.country %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                    emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # FALSE = correlated
                                    emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1]))/1000)
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2])/1000)
  emi.tot.cat$country <- 'world'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat/1000
  # ****
  # end world  total
  
  
  dt <- tot.emi.country[order(tot.emi.country$tot.country, decreasing=T),]
  dt$tot.country <- dt$tot.country/1000
  
  p <- ggplot(dt[1:35,]) +
    geom_pointrange(aes(x=reorder(country,-tot.country), y=tot.country, 
                        ymin=asym.unc.min/1000, 
                        ymax=asym.unc.max/1000)) + 
    ylab(paste0(now_run, ' EDGAR emission (Tg)') ) +  xlab('')    + 
    ggtitle(paste0('EDGAR ',now_run, ' emission ', sYear ,' - Global' )) +
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5),text = element_text(size = 16), 
          plot.title = element_text(size = 14, face = "bold"))  
   
  
  
  w <- ggplot(data=emi.tot.cat) +
    geom_pointrange(aes(x=country, y=emi.tot.cat, 
                        ymin=CImin , 
                        ymax=CImax), 
                    color='blue' )+ 
    ylim(0,NA)+
    xlab('') +theme(axis.title.y=element_blank()  )
  
  
  pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)
  
  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi, '_',sUncCorr ,'_GLOBAL_emission.tiff'),
         device='tiff', width = 12, height = 7.5, units = "in",
         dpi = 260, pga)
  
#*****************************************************************  
# this point forward the code deals with plotting the contribution to uncertainty due to different categories.
# the total uncertainty is apportioned to the proportion of variance of each category, 
# including the remaining of variance from variances of categories not included in the main ones   

#*****************************************************************

 #*** debug
#  g1   <- loadRData(file = paste0(out.dir,sCatAgg, sCatEmi, '_', now_run,  '_', sUncCorr,'emi_by_categories.Rdata') )  # 
#  g2   <- loadRData(file = paste0(out.dir,sCatAgg, sCatEmi, '_', now_run,  '_emi_tot_by_country.Rdata') )
#  unc.table <- loadRData(file=paste0(proc.dir,'unc.table.Rdata'))
 #*** end debug 

#  emi.keys.0 <- c( '1.A', '1.B.1','1.B.2', '3.A.1','3.A.2','3.C.7',  '4.A', '4.D') # test removing rice sector
#  emi.keys <- paste0('^', emi.keys.0 )
 #  cat <- NULL 
 #  
 #  # from unc.table, select only the categories in emi.keys
 #  # equivalent to:  cat <- subset(unc.table,grepl(paste(emi.keys, collapse="|"), ipcc06))
 #  for (k in 1:length(emi.keys)){
 #    cat.tmp <-  subset(unc.table,grepl(emi.keys[k], ipcc06))
 #    cat.tmp$proc <- emi.keys.0[k]
 #    cat <- rbind(cat, cat.tmp)
 #    cat.tmp <- NULL
 #  }
 #  
 #  # GLOBAL: var.cat contains the variance of each sector, for all world
 #  var.cat <- ddply(cat, .(proc), summarise, var.cat = var(emi, na.rm=T))
 #  
 #  # var.cat.country contains the variance of each category for each country
 #  var.cat.country <- ddply(cat, .(country,proc), summarise, var.cat = var(emi, na.rm=T))
 #  
 #  var.cat.tot <- with(var.cat, sum(var.cat, na.rm=T))
 #  # other categories 
 #  ## indexes of matching categories
 #  cat.tmp   <-  which(grepl(paste(emi.keys, collapse="|"), unc.table$ipcc06)) 
 #  ## now remove them
 #  other.cat <-  unc.table[-cat.tmp,]
 #    
 #  
 #  # find the variance of the 'other categories'
 #  for (r in unique(other.cat$ipcc06)){
 #    var.other.cat <- ddply(other.cat, .(ipcc06), summarise, var.cat = var(emi, na.rm=T))
 #    var.other.cat.country <- ddply(other.cat, .(country, ipcc06), summarise, var.cat = var(emi, na.rm=T))
 #  }
 #  ## total variance of other sectors is the sum of the variance of the 'other categories' 
 #  var.other.cat <- with(var.other.cat,sum(var.cat, na.rm=T)) 
 #  ## Variance of 'other sectors' by country
 #  var.other.cat.country <- ddply(var.other.cat.country, .(country), summarise, var.other.contry=sum(var.cat, na.rm=T)) #total variance of other sectors
 #  var.cat.country.tot   <- ddply(var.cat.country,.(country), summarise, var.country=sum(var.cat,na.rm=T))
 #  var.country.tot       <- merge(var.other.cat.country,var.cat.country.tot, by='country')
 #  var.country.tot$tot   <- apply(var.country.tot, 1, function(x){(sum(as.numeric(x[2]),as.numeric(x[3]), na.rm=T))})
 # 
 #  # share of uncertainty as proportion of variance of each category to the total variance
 #  # that is the sum of the variance of each category plus the variance of the 'other categories'
 #  k<-1
 #  for (c in var.cat.country$country){
 #    tot <- var.country.tot[which(var.country.tot$country==c),'tot']
 #    var.cat.country[k,4] <- ifelse(is.na(as.numeric(var.cat.country[k,'var.cat'])), NA, 100*as.numeric(var.cat.country[k,'var.cat'])/tot)
 #    k<-k+1
 #  }
 #  names(var.cat.country) <- c('country',  'proc', 'var.cat', 'share')
 #  
 #  var.cat.country <- var.cat.country[-which(is.na(var.cat.country$share)),] # mmmhhhh
 #  
 #  
 #  #* GLOBAL:  share of the total variance by each sector
 #  var.cat$share <- 100*(round(var.cat$var.cat/(var.other.cat+var.cat.tot),3)) 
 #  var.cat <- rbind( var.cat, c('other',var.other.cat, 100*(round(var.other.cat/(var.other.cat+var.cat.tot),3)) ))
 #  ## combine with emi.tot.cat
 #  var.cat$emi.global <- emi.tot.cat$emi.tot.cat
 #  var.cat$CImin <-  emi.tot.cat$CImin ; var.cat$CImax <-  emi.tot.cat$CImax
 #  ## for asymmetric distribution the upper part is the distance between the upper unc and the mean
 #  var.cat$plus  <- apply(var.cat, 1, function(x){0.01*as.numeric(x[3])*(as.numeric(x[6])-as.numeric(x[4]))})
 #  ## the lower part is the distance betwwen the mean and the lower unc
 #  var.cat$minus <- apply(var.cat, 1, function(x){0.01*as.numeric(x[3])*(as.numeric(x[4])-as.numeric(x[5]))})
 #  
 #  
 #    setDT(var.cat)[ , `:=`(startp=start  <- c(emi.global + c(0, cumsum(head(plus, -1)))),
 #                                       endp = start + plus)]
 #    setDT(var.cat)[ , `:=`(startm=start  <- c(emi.global - c(0, cumsum(head(minus, -1)))),
 #                                       endm = start -minus)]  
 #  
 #  #* end GLOBAL
 #  
 #  # COUNTRY: now build up the coordinates of the share portion for plotting
 #  var.share <- merge(var.cat.country, dt, by='country', all=T)
 # #***SAVE***
 # #   write.csv(var.share, file=paste0(proc.dir, 'share_of_variance_by_cat_and_country.csv'))
 # # *********
 #  # for asymmetric distribution the upper part is the distance between the upper unc and the mean
 #  var.share$plus  <- apply(var.share, 1, function(x){0.01*as.numeric(x[4])*(0.001*as.numeric(x[9])-as.numeric(x[5]))})
 #  # the lower part is the distance betwwen the mean and the lower unc
 #  var.share$minus <- apply(var.share, 1, function(x){0.01*as.numeric(x[4])*(as.numeric(x[5])-0.001*as.numeric(x[8]))})
 # 
 #  for (c in var.share$country){
 #    setDT(var.share)[country==c , `:=`(startp=start  <- c(tot.country + c(0, cumsum(head(plus, -1)))),
 #                                       endp = start + plus)]
 #    setDT(var.share)[country==c , `:=`(startm=start  <- c(tot.country - c(0, cumsum(head(minus, -1)))),
 #                                       endm = start -minus)]  
 #  }
 #  var.cat$country <- 'world'
 #  # 
 #   dt1 <- var.share[order(var.share$tot.country, decreasing=T),]
 #   q   <- ggplot(dt1[1:350,], aes(x=reorder(country,-tot.country),y=tot.country))
 #   z   <- q +  
 #        geom_errorbar(aes(ymin= asym.unc.min/1000 , ymax=asym.unc.max/1000), width=0.5, size=0.5) + 
 #        geom_segment(data= dt1[1:350,], aes(x = country, xend = country, y = startp, yend = endp, color = proc), size=3, alpha=0.6, stat='identity') +
 #        geom_segment(data= dt1[1:350,], aes(x = country, xend = country, y = startm, yend = endm, color = proc), size=3, alpha=0.6, stat='identity') +
 #        geom_point(size=2, shape=21, fill='white', alpha=0.5) +
 #        ylab(' CH4 emission (Tg)' ) +  xlab('')    +
 #        theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5))+  
 #        theme(legend.position = c(0.8, 0.8))+guides(color=guide_legend(title="IPCC categories"))+
 #        ggtitle(paste0('EDGAR CH4 emission 2012 - Global' ))
 # 
 #  y <- ggplot(data=var.cat) +
 #    xlab('') +theme(axis.title.y=element_blank()   )+
 #    theme(legend.position = "none")+
 #    geom_segment(data= var.cat, aes(x = country, xend = country, y = startp, yend = endp, color = proc), size=3, alpha=0.6, stat='identity') +
 #    geom_segment(data= var.cat, aes(x = country, xend = country, y = startm, yend = endm, color = proc), size=3, alpha=0.6, stat='identity') +
 #    geom_pointrange(aes(x=country, y=emi.global, 
 #                        ymin=CImin , 
 #                        ymax=CImax), 
 #                    color='blue', shape=21 , fill='white')
 #    
 #  pga <- grid.arrange(z, y, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)
 #  
 #  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,'_GLOBAL_emission_unc_share.tiff'),
 #         device='tiff', width = 12, height = 7.5, units = "in",
 #         dpi = 160, pga)
  cat <- NULL 
  
  # from unc.table, select only the categories in emi.keys
  # equivalent to:  cat <- subset(unc.table,grepl(paste(emi.keys, collapse="|"), ipcc06))
  for (k in 1:length(emi.keys)){
    cat.tmp <-  subset(unc.table,grepl(emi.keys[k], ipcc06))
    cat.tmp$proc <- emi.keys.0[k]
    cat <- rbind(cat, cat.tmp)
    cat.tmp <- NULL
  }
  
  # GLOBAL: var.cat contains the variance of each sector, for all world
  var.cat <- ddply(cat, .(proc), summarise, var.cat = var(emi, na.rm=T), sum.cat=sum(emi, na.rm=T)) #ddply(cat, .(proc), summarise, var.cat = var(emi, na.rm=T))
  
  # var.cat.country contains the variance of each category for each country
  var.cat.country <- ddply(cat, .(country,proc), summarise, var.cat = var(emi, na.rm=T), sum.cat=sum(emi, na.rm=T))
  
  var.cat.tot <- with(var.cat, sum(var.cat, na.rm=T)) # total variance
  emi.cat.tot <- with(var.cat, sum(sum.cat, na.rm=T)) # total emission
  
  # other categories 
  ## indexes of matching categories
  cat.tmp   <-  which(grepl(paste(emi.keys, collapse="|"), unc.table$ipcc06)) 
  ## now remove them
  other.cat <-  unc.table[-cat.tmp,]
  
  
  # find the variance of the 'other categories'
  #for (r in unique(other.cat$ipcc06)){
  var.other.cat <- ddply(other.cat, .(ipcc06), summarise, var.cat = var(emi, na.rm=T), sum.cat=sum(emi, na.rm=T))
  var.other.cat.country <- ddply(other.cat, .(country, ipcc06), summarise, var.cat = var(emi, na.rm=T), sum.cat=sum(emi, na.rm=T))
  #}
  
  ## total variance of other sectors is the sum of the variance of the 'other categories' 
  #var.other.cat1 <- with(var.other.cat, sum(var.cat, na.rm=T)) 
  emi.other.cat <- with(var.other.cat, sum(sum.cat, na.rm=T)) # total emission by other categories
  ## Variance of 'other sectors' by country
  var.other.cat.country <- ddply(var.other.cat.country, .(country), summarise, var.other.country=sum(var.cat, na.rm=T),emi.other.country=sum(sum.cat, na.rm=T)) #total variance of other sectors
  var.cat.country.tot   <- ddply(var.cat.country,.(country), summarise, var.country=sum(var.cat,na.rm=T), emi.country=sum(sum.cat, na.rm=T))
  var.country.tot       <- merge(var.other.cat.country,var.cat.country.tot, by='country')
  var.country.tot$tot   <- apply(var.country.tot, 1, function(x){(sum(as.numeric(x[2]),as.numeric(x[4]), na.rm=T))}) # total variance (categories + other categories) by country
  var.country.tot$emisum   <- apply(var.country.tot, 1, function(x){(sum(as.numeric(x[3]),as.numeric(x[5]), na.rm=T))}) # total emission (categories + other categories) by country
  
  # share of uncertainty as proportion of variance of each category to the total variance
  # that is the sum of the variance of each category plus the variance of the 'other categories'
  k<-1
  for (c in var.cat.country$country){
    tot <- var.country.tot[which(var.country.tot$country==c),'emisum']; tot<- as.numeric(tot)
    var.cat.country[k,5] <- ifelse(is.na(as.numeric(var.cat.country[k,'var.cat'])), NA, 
                                   as.numeric(var.cat.country[k,'var.cat'])*as.numeric(var.cat.country[k,'sum.cat'])/tot)
    
    k<-k+1
  }
  names(var.cat.country) <- c('country',  'proc', 'var.cat', 'emi.cat',   'share')
  
  tmp <-  ddply(var.cat.country, .(country), summarise, sumshare=sum(share, na.rm=T)) 
  
  # do the proportion between the share and the percentage (transform the share in %)
  k<-1
  for (c in var.cat.country$country){
    sumshare <- tmp[which(tmp$country==c),'sumshare']
    var.cat.country[k,6] <- ifelse(is.na(as.numeric(var.cat.country[k,'share'])), NA, 100*var.cat.country[k,'share']/sumshare)
    k<-k+1
  }
  var.cat.country$share <- NULL
  names(var.cat.country) <- c('country',  'proc', 'var.cat', 'emi.cat',   'share') # now the share is in %
  var.cat.country <- var.cat.country[-which(is.na(var.cat.country$share)),] # mmmhhhh
  
  
  
  # COUNTRY: now build up the coordinates of the share portion for plotting
  var.share <- merge(var.cat.country, dt, by='country', all=T)
  #***SAVE***
  #   write.csv(var.share, file=paste0(proc.dir, 'share_of_variance_by_cat_and_country.csv'))
  # *********
  # for asymmetric distribution the upper part is the distance between the upper unc and the mean
  var.share$plus  <- apply(var.share, 1, function(x){0.01*as.numeric(x[5])*(0.001*as.numeric(x[10])-as.numeric(x[6]))})
  # the lower part is the distance betwwen the mean and the lower unc
  var.share$minus <- apply(var.share, 1, function(x){0.01*as.numeric(x[5])*(as.numeric(x[6])-0.001*as.numeric(x[9]))})
  
  for (c in var.share$country){
    setDT(var.share)[country==c , `:=`(startp=start  <- c(tot.country + c(0, cumsum(head(plus, -1)))),
                                       endp = start + plus)]
    setDT(var.share)[country==c , `:=`(startm=start  <- c(tot.country - c(0, cumsum(head(minus, -1)))),
                                       endm = start -minus)]  
  }
  
  
  #* GLOBAL:  share of the total variance by each sector
  var.cat$share <- round(var.cat$var.cat*var.cat$sum.cat/(var.other.cat$sum.cat+emi.cat.tot),3)
  share.percent <- as.numeric(var.cat$share)*100/sum( as.numeric(var.cat$share)) 
  var.cat$share <- share.percent
  var.cat <- rbind( var.cat, c('other',sum(var.other.cat$sum.cat),emi.other.cat,   round(var.other.cat$var.cat* emi.other.cat/(sum(var.other.cat$sum.cat)+emi.cat.tot),3)) )
  ## combine with emi.tot.cat
  var.cat$emi.global <- emi.cat.tot
  var.cat$CImin <-  emi.tot.cat$CImin ; var.cat$CImax <-  emi.tot.cat$CImax
  ## for asymmetric distribution the upper part is the distance between the upper unc and the mean
  var.cat$plus  <- apply(var.cat, 1, function(x){0.01*as.numeric(x[4])*(as.numeric(x[7])-0.001*as.numeric(x[5]))})
  ## the lower part is the distance betwwen the mean and the lower unc
  var.cat$minus <- apply(var.cat, 1, function(x){0.01*as.numeric(x[4])*(0.001*as.numeric(x[5])-as.numeric(x[6]))})
  
  
  setDT(var.cat)[ , `:=`(startp=start  <- c(emi.global/1000 + c(0, cumsum(head(plus, -1)))),
                         endp = start + plus)]
  setDT(var.cat)[ , `:=`(startm=start  <- c(emi.global/1000 - c(0, cumsum(head(minus, -1)))),
                         endm = start -minus)]  
  
  #* end GLOBAL
  # 
  var.cat$country <- 'world'
  dt1 <- var.share[order(var.share$tot.country, decreasing=T),]
  dt1<-data.frame(dt1)
  q   <- ggplot(dt1[1:350,], aes(x=reorder(country,-tot.country),y=tot.country))
  z   <- q +  
    geom_errorbar(aes(ymin= as.numeric(asym.unc.min)/1000 , ymax=as.numeric(asym.unc.max)/1000), width=0.5, size=0.5) + 
    geom_segment(data= dt1[1:350,], aes(x = country, xend = country, y = startp, yend = endp, color = proc), size=3, alpha=0.6, stat='identity') +
    geom_segment(data= dt1[1:350,], aes(x = country, xend = country, y = startm, yend = endm, color = proc), size=3, alpha=0.6, stat='identity') +
    geom_point(size=2, shape=21, fill='white', alpha=0.5) +
    ylab(' CH4 emission (Tg)' ) +  xlab('')    +
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5))+  
    theme(legend.position = c(0.8, 0.8))+guides(color=guide_legend(title="IPCC categories"))+
    ggtitle(paste0('EDGAR CH4 emission 2012 - Global' ))
  
  y <- ggplot(data=var.cat) +
    xlab('') +theme(axis.title.y=element_blank()   )+
  #  theme(legend.position = "none")+
    geom_segment(data= var.cat, aes(x = country, xend = country, y = startp, yend = endp, color = proc), size=3, alpha=0.6, stat='identity') +
    geom_segment(data= var.cat, aes(x = country, xend = country, y = startm, yend = endm, color = proc), size=3, alpha=0.6, stat='identity') +
    geom_pointrange(aes(x=country, y=emi.global/1000, 
                        ymin=CImin , 
                        ymax=CImax), 
                    color='blue', shape=21 , fill='white')
  
  pga <- grid.arrange(z, y, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)
  
  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,'_GLOBAL_emission_var_share.tiff'),
         device='tiff', width = 12, height = 7.5, units = "in",
         dpi = 260, pga)
  
} # end function

#' Title
#'
#' @param tot.emi.country 
#' @param unc.table 
#'
#' @return
#' @export
#'
#' @examples
f.cat_share_plot <- function(tot.emi.country, unc.table){
# debug   
  # tot.emi.country   <- loadRData(file=paste0(out.dir,sCatAgg,sCatEmi, '_', now_run, '_',sUncCorr, 'emi_tot_by_country.Rdata') ) 
#                                  
# debug   
  # unc.table <- loadRData(file=(paste0(proc.dir,sUncCorr,'unc.table.Rdata')))
  
  # this function does the plot of total emission per country with the uncertainty 
  # color coded by the share of uncertainty of various categories
  # the share of uncertianty is calculated as 
  # (max-min)*emi/((MAX-MIN)*EMI), where the capital ones refer to the country gran-total, while the lower case ones 
  # refer to category. thus no variance here!
  
  # need to run the function f.plot_country() up to the creation of dt...very ugly piece of code!
  
  cat <- NULL 
  emi.keys <- paste0('^', emi.keys.0 )
  # from unc.table, select only the categories in emi.keys
  # equivalent to:  cat <- subset(unc.table,grepl(paste(emi.keys, collapse="|"), ipcc06))
  for (k in 1:length(emi.keys)){
    cat.tmp <-  subset(unc.table,grepl(emi.keys[k], ipcc06))
    cat.tmp$proc <- emi.keys.0[k]
    cat <- rbind(cat, cat.tmp)
    cat.tmp <- NULL
  }
  
  summary.cat <- ddply(cat, .(proc, country), summarise,  emi=sum(emi, na.rm=T), 
                       unc.min = sum(abs(unc.emi.min), na.rm=T), unc.max=sum(unc.emi.max, na.rm=T)) 
  
  summary.country <- ddply(unc.table, .(country), summarise,  emi=sum(emi, na.rm=T)) 
  
  mc <- merge(summary.country, dt, by='country', all=T)
  mc$other     <- 0.001*mc$emi - mc$tot.country  
  
  weight_other <- mc$other/mc$tot.country   #mc$tot.subcat #
  
  mc0         <- data.frame(matrix(vector(), nrow(mc), ncol(summary.cat)))
  names(mc0)  <- names(summary.cat)
  mc0$country <- mc$country ; mc0$emi <- mc$other 
  mc0$proc    <- 'other';
  
  mm <- merge(summary.cat,mc0, by = intersect(names(summary.cat), names(mc0)), all=T) # add category 'other'
  
  mt <- subset(mc, select=c('country', 'emi'))
  mm1 <- merge(mm, mt,by='country', all=T)
  names(mm1) <- c('country',  'proc',        'emi',      'unc.min',      'unc.max',        'tot.country')
  # mm <- merge(summary.cat, mc, by='country', all=T)
  # mm1$share <- with(mm1, 100*(unc.max-unc.min)*emi/tot.country)
  
  tp1 <- subset(tot.emi.country, select=-c(rel.unc.min, rel.unc.max ))
  
  mm2       <- merge(mm1, tp1, by='country', all=T)
  mm2$share <- with(mm2, (unc.max-unc.min)*emi/((asym.unc.max-asym.unc.min)*tot.country.x))
  
  mm2[mm2$proc=='other','share'] <- weight_other # the contribution of 'other' to the uncertainty 
                                                 # set to be the same as their weight in terms of emission
  
  tp2 <- ddply(mm2, .(country), summarise,  shp=sum(share, na.rm=T)) 
  k<-1
  for (c in mm2$country){
    sumshare <- tp2[which(tp2$country==c),'shp']
    mm2[k,11] <- 100*mm2$share[k]/sumshare
    k<-k+1
  }
  mm2$share <- NULL
  names(mm2) <- c('country',  'proc' ,  'emi'  ,  'unc.min' ,   'unc.max' ,'tot.country' ,
                  'tot.country.y' ,'asym.unc.min', 'asym.unc.max','share')
  write.csv(mm2, file=paste0(proc.dir,sCatAgg, sCatEmi,'_',  now_run, '_', sUncCorr,'_emission_summary_table.csv'))
  rP <- rpivotTable(mm2,cols='proc', rows = 'country', vals='share', aggregatorName="Sum", 
              rendererName='Horizontal Stacked Bar Chart', 
              inclusion=list(country=list('CHN', 'IND','USA', 'BRA',   'RUS', 'IDN','IRN', 'JPN','DEU', 'SAU')), width="100%", height="400px")
  
  saveWidget(rP,file=paste0(fig.dir,'rP.html'))
  # tp3 <- ddply(mm2, .(country), summarise,  shp=sum(share, na.rm=T))  check the total is 100%
  
  # for asymmetric distribution the upper part is the distance between the upper unc and the mean
  mm2$plus  <- apply(mm2, 1, function(x){0.01*as.numeric(x[10])*(as.numeric(x[9])-as.numeric(x[6]))})
  # the lower part is the distance betwwen the mean and the lower unc
  mm2$minus <- apply(mm2, 1, function(x){0.01*as.numeric(x[10])*(as.numeric(x[6])-as.numeric(x[8]))})
  
  
  for (c in mm2$country){
    setDT(mm2)[country==c , `:=`(startp=start  <- c(tot.country + c(0, cumsum(head(plus, -1)))),
                                 endp = start + plus)]
    setDT(mm2)[country==c , `:=`(startm=start  <- c(tot.country - c(0, cumsum(head(minus, -1)))),
                                 endm = start -minus)]  
  }
  
  dt1 <- mm2[order(mm2$tot.country, decreasing=T),]
  dt1<-data.frame(dt1)
  q   <- ggplot(dt1[1:350,], aes(x=reorder(country,-tot.country),y=tot.country.y/1000))
  z   <- q +  
    geom_errorbar(aes(ymin= as.numeric(asym.unc.min)/1000 , ymax=as.numeric(asym.unc.max)/1000), width=0.5, size=0.5) + 
    geom_segment(data= dt1[1:350,], aes(x = country, xend = country, y = startp/1000, yend = endp/1000, color = proc), size=6, alpha=0.6, stat='identity') +
    geom_segment(data= dt1[1:350,], aes(x = country, xend = country, y = startm/1000, yend = endm/1000, color = proc), size=6, alpha=0.6, stat='identity') +
    geom_point(size=2, shape=21, fill='white', alpha=0.5) +
    ylab(' CH4 emission (Tg)' ) +  xlab('')    +
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5))+  
    theme(legend.position = c(0.8, 0.8))+guides(color=guide_legend(title="IPCC categories"))+
    ggtitle(paste0('EDGAR CH4 emission 2012 - Global' ))
  
  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,'_GLOBAL_emission_unc_share.tiff'),
         device='tiff', width = 12, height = 7.5, units = "in",
         dpi = 180, z)
  #
  #          ****************************************************************
  #          *******************    do the same for EU28    *****************
  #          ****************************************************************
  #
  dtEU <- mm2[which(mm2$country %in% EU28.cc),]
  q   <- ggplot(dtEU, aes(x=reorder(country,-tot.country),y=tot.country.y/1000))
  z   <- q +  
    geom_errorbar(aes(ymin= as.numeric(asym.unc.min)/1000 , ymax=as.numeric(asym.unc.max)/1000), width=0.5, size=0.5) + 
    geom_segment(data= dtEU, aes(x = country, xend = country, y = startp/1000, yend = endp/1000, color = proc), size=6, alpha=0.6, stat='identity') +
    geom_segment(data= dtEU, aes(x = country, xend = country, y = startm/1000, yend = endm/1000, color = proc), size=6, alpha=0.6, stat='identity') +
    geom_point(size=2, shape=21, fill='white', alpha=0.5) +
    ylab(' CH4 emission (Tg)' ) +  xlab('')    +
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5))+  
    theme(legend.position = c(0.8, 0.8))+guides(color=guide_legend(title="IPCC categories"))+
    ggtitle(paste0('EDGAR CH4 emission 2012 - EU28' ))
  
  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,'_GLOBAL_emission_unc_share_EU28.tiff'),
         device='tiff', width = 12, height = 7.5, units = "in",
         dpi = 180, z)
  
 
  
} # end function
#****************************************************************************
#' Title
#'
#' @param cat.emi.country 
#' @param sSens 
#'
#' @return
#' @export
#'
#' @examples
f.plot_cat_bSens <- function(cat.emi.country, sSens){
  
  
  # debug:  
  ## either this 
  # cat.emi.country <- g1.tot (default one, no sensitivity!)
  ## or
  # cat.emi.country   <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr, '_', sYear,'emi_by_categories.Rdata') )  # 
  
  # end debug                                   
  
  
  ## cat.emi.country is g1.tot produced from the main(), that is based on the 'unc.table' produced by 'associate_unc2emi.R'. 
  ## g.tot already went through the 'f.asymmetric_unc()', thus the call should not be replicated here  
# available options  
#  b1Ax <- F;       if (b1Ax)       {sSens <- '1Ax'}
#  b1A  <- F;       if (b1A)        {sSens <- '1A' }
#  b1a3b <-F;       if (b1a3b)      {sSens <- 'Road'} @#check
#  b1A_fuel  <- T;  if (b1A_fuel)   {sSens <- '1A_fuel' }
#  bRice_sens <- F; if (bRice_sens) {sSens <- 'Rice'}
#  bEnf <- FT;       if (bEnf)       {sSens <- '3A1'}
#  bMnm <- F;       if (bMnm)       {sSens <- '3A2'} 
#  b1B2 <- F;       if (b1B2)       {sSens <- 'Fugitive_Gas'; sSens0 <- '1B2'}
# load the appropriate file:   
#  rm(cat.emi.country.bSens)
# cat.emi.country.bSens   <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr,'_', sYear, '_', sSens,'.Rdata') )  
  
  # emi_keys <- gsub( '.','',emi.keys.0, fixed=T)
  emi_keys1 <- gsub( '.','',names(cat.emi.country), fixed=T)
  emi_keys2 <- gsub( '.','',names(cat.emi.country.bSens), fixed=T)
  if(sSens == 'Rice') {
    sSens0 <- '3C7'
    t1 <-  which(startsWith(sSens0, emi_keys1))
    t2 <-  which(startsWith(sSens0, emi_keys2))
    
  } else if (sSens == '1A_fuel') {
    sSens0 <- 'ENE'
    t1 <-  which(startsWith(sSens0, emi_keys1))
    t2 <-  which(startsWith(sSens0, emi_keys2))
  } else {
    t1 <- which(startsWith(sSens, emi_keys1))
    t2 <- which(startsWith(sSens, emi_keys2))
    if(length(t1==0) | length(t2)==0){
      t1 <- which(startsWith(sSens0, emi_keys1))
      t2 <- which(startsWith(sSens0, emi_keys2))
    }
  }
  
  
  #  for (t in 1:length(cat.emi.country)){
  emi.tot.cat <- NULL; cat0 <- NULL  
  sCat <- f.get_emi_cat(emi.keys.0[t2])
  
  cat0     <- cat.emi.country[[t1]]
  cat.sens <- cat.emi.country.bSens[[t2]]
  
  dt            <- cat0[order(cat0$tot.subcat, decreasing=T),]
  dt$tot.subcat <- dt$tot.subcat/1000
  dt.sens       <- cat.sens[order(cat.sens$tot.subcat, decreasing=T),]
  dt.sens$tot.subcat <- dt.sens$tot.subcat/1000
  dt$sens      <- rep('unperturbed unc', dim(dt)[1])
  dt.sens$sens <- rep('perturbed unc', dim(dt.sens)[1])
  
  dd  <-  rbind(dt,dt.sens)
  dd  <-  dd[order(dd$tot.subcat, decreasing=T),]
  
  
  # world total
  emi.tot.cat      <- f.world_total(data.frame(cat0))
  emi.tot.cat.sens <- f.world_total(data.frame(cat.sens))
  
  emi.tot.cat$sens      <- 'unperturbed unc'
  emi.tot.cat.sens$sens <- 'perturbed unc'
  
  emi.tot <- rbind(as.data.frame(emi.tot.cat), as.data.frame(emi.tot.cat.sens))
  
  if (sSens == '1Ax'){
    leg.tit <- 'unc(1Ax) = 0' # legend title
  }
  if (sSens == '1A') {
    leg.tit <- 'unc(1A) = 100%' # legend title
  }
  if(ssens=='Road'){
    leg.tit <- 'unc(Road) = 40% +10%' 
  }
  if (sSens == 'Rice'){
    leg.tit <- 'unc(Rice) = 120% + 5/10%' # legend title
  }
  if(sSens == '3A1'){
    leg.tit <- 'unc(ENF) = 30%-50%' # legend title
  }
  if(sSens == '3A2'){
    leg.tit <- 'unc(MNM) = 50% + 10%' # legend title
  }
  if(sSens == 'Fugitive_Gas'){
    leg.tit <- 'unc(1B2b) = 100% + 15%' # legend title
  }
  if (sSens == '1A_fuel') {
    leg.tit <- 'unc(ENE) = factor 3' # legend title
  }
  
  p <- ggplot(dd[1:50,]) +
    geom_pointrange(aes(x=reorder(country,-tot.subcat), y=tot.subcat, 
                        ymin=asym.unc.min/1000, 
                        ymax=asym.unc.max/1000, color=sens), position=position_dodge(width=0.6)) + 
    ylab(' CH4 EDGAR emission (Tg)' ) +  xlab('')    +
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5)) + 
    theme(legend.position = c(0.8, 0.8),
          text = element_text(size = 16), 
          plot.title = element_text(size = 14, face = "bold")) + labs(color=leg.tit)+
    ggtitle(paste0('EDGAR CH4 ',sYear,' - ' , emi.keys.0[t2], ': ', sCat))
  
  w <- ggplot(data=emi.tot) +
    geom_pointrange(aes(x=country, y=emi.tot.cat, 
                        ymin=CImin , 
                        ymax=CImax, 
                        color=sens), position=position_dodge(width=0.6) )+ 
    ylim(0,NA)+
    xlab('') +theme(axis.title.y=element_blank(),text = element_text(size = 16)) +
      theme(legend.position = "none")
  
  pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.5,1.5) )
  
  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,sCat,'_total_emission_', sSens,'.png'),
         plot = pga ,dpi=150,type='cairo')
  
} # end function

#************************************************************************************************************
#************************************************************************************************************
#' Title
#'
#' @param cat.emi.country 
#' @param sSens 
#'
#' @return
#' @export
#'
#' @examples
f.plot_cat_bSens_N2O <- function(cat.emi.country, sSens){
  
  
  # debug:  
  ## either this 
  # cat.emi.country <- g1.tot
  ## or
  #   cat.emi.country   <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr,'emi_by_categories.Rdata') )  # 
  
  # end debug                                   
  
  
  ## cat.emi.country is g1.tot produced from the main(), that is based on the 'unc.table' produced by 'associate_unc2emi.R'. 
  ## g.tot already went through the 'f.asymmetric_unc()', thus the call should not be replicated here  
  # available options  
  
#    if (flag==1) { bx   <- T;      sSens <- 'biofuels'}
#    if (flag==2) { b1A  <- T;      sSens <- '1A' }
#    if (flag==3) { bAir <- T;      sSens <- 'Air'}
#    if (flag==4) { bSea <- T;      sSens <- 'Sea'}
#    if (flag==5) { b2B  <- T;      sSens <- 'Chem'}
#    if (flag==6) { b3C4 <- T;      sSens <- 'Direct N2O'}
#    if (flag==7) { b1B2 <- T;      sSens <- 'Fugitive'}
#    if (flag==8) { b4D1 <- T;      sSens <- 'Domestic Wastewater'}
    
  # load the appropriate file:   
    rm(cat.emi.country.bSens)
   cat.emi.country.bSens <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi,'_', now_run, '_', sUncCorr,'emi_by_categories_',sSens, '.Rdata') )  
  
  # emi_keys <- gsub( '.','',emi.keys.0, fixed=T)
  emi_keys1 <- gsub( '.','',names(cat.emi.country), fixed=T)
  emi_keys2 <- gsub( '.','',names(cat.emi.country.bSens), fixed=T)
  if(sSens == 'biofuels') {
    sSens0 <- '1Ax'
    t1 <-  which(startsWith(sSens0, emi_keys1))
    t2 <-  which(startsWith(sSens0, emi_keys2))
   } else if (sSens == 'Air' | sSens == 'Sea'){
      sSens0 <- '1A'
      t1 <-  which(startsWith(sSens0, emi_keys1))
      t2 <-  which(startsWith(sSens0, emi_keys2))
    } else if (sSens == 'Chem'){
      sSens0 <- '2B'
      t1 <-  which(startsWith(sSens0, emi_keys1))
      t2 <-  which(startsWith(sSens0, emi_keys2))
    } else if(sSens== 'Direct N2O'){
      sSens0 <- '3C4'
      t1 <-  which(startsWith(sSens0, emi_keys1))
      t2 <-  which(startsWith(sSens0, emi_keys2))
    } else if(sSens== 'Fugitive'){
      sSens0 <- '1B2'
      t1 <-  which(startsWith(sSens0, emi_keys1))
      t2 <-  which(startsWith(sSens0, emi_keys2))
    } else if (sSens == 'Domestic Wastewater'){
      sSens0 <- '4D1'
      t1 <-  which(startsWith(sSens0, emi_keys1))
      t2 <-  which(startsWith(sSens0, emi_keys2))
    
  } else {
    t1 <- which(startsWith(sSens, emi_keys1))
    t2 <- which(startsWith(sSens, emi_keys2))
    if(length(t1==0) | length(t2)==0){
      t1 <- which(startsWith(sSens0, emi_keys1))
      t2 <- which(startsWith(sSens0, emi_keys2))
    }
  }
  
  #  for (t in 1:length(cat.emi.country)){
  emi.tot.cat <- NULL; cat0 <- NULL  
  sCat <- f.get_emi_cat(emi.keys.0[t2])
  
  cat0     <- cat.emi.country[[t1]]
  cat.sens <- cat.emi.country.bSens[[t2]]
  
  dt            <- cat0[order(cat0$tot.subcat, decreasing=T),]
  dt$tot.subcat <- dt$tot.subcat/1000
  dt.sens       <- cat.sens[order(cat.sens$tot.subcat, decreasing=T),]
  dt.sens$tot.subcat <- dt.sens$tot.subcat/1000
  dt$sens      <- rep('unperturbed unc', dim(dt)[1])
  dt.sens$sens <- rep('perturbed unc', dim(dt.sens)[1])
  
  dd  <-  rbind(dt,dt.sens)
  dd  <-  dd[order(dd$tot.subcat, decreasing=T),]
  
  
  # world total
  emi.tot.cat      <- f.world_total(cat0)
  emi.tot.cat.sens <- f.world_total(cat.sens)
  
  emi.tot.cat$sens      <- 'unperturbed unc'
  emi.tot.cat.sens$sens <- 'perturbed unc'
  
  emi.tot <- rbind(as.data.frame(emi.tot.cat), as.data.frame(emi.tot.cat.sens))
  
  if (sSens == 'biofuels'){
    leg.tit <- 'unc(biofules) = 100%+100%' # legend title
  }
  if (sSens == '1A') {
    leg.tit <- 'unc(1A) = 10/100%+10%' # legend title
  }
  if(sSens=='Air'){
    leg.tit <- 'unc(Air) = 100%+100%' 
  }
  if (sSens == 'Sea'){
    leg.tit <- 'unc(Sea) = 100%+100%' # legend title
  }
  if(sSens == 'Chem'){
    leg.tit <- 'unc(Chem) = 100%+10%' # legend title
  }
  if(sSens == 'Direct N2O'){
    leg.tit <- 'unc(Direct N2O) = 100%+10%' # legend title
  }
  if(sSens == 'Fugitive'){
    leg.tit <- 'unc(1B2b) = 100%+10%' # legend title
  }
  
  p <- ggplot(dd[1:50,]) +
    geom_pointrange(aes(x=reorder(country,-tot.subcat), y=tot.subcat, 
                        ymin=asym.unc.min/1000, 
                        ymax=asym.unc.max/1000, color=sens), position=position_dodge(width=0.6)) + 
    ylab(' N2O EDGAR emission (Tg)' ) +  xlab('')    +
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5)) + 
    theme(legend.position = c(0.7, 0.8),
          text = element_text(size = 16), 
          plot.title = element_text(size = 14, face = "bold")) + labs(color=leg.tit)+
    ggtitle(paste0('EDGAR N2O 2012 - ' , emi.keys.0[t2], ': ', sCat))
  
  w <- ggplot(data=emi.tot) +
    geom_pointrange(aes(x=country, y=emi.tot.cat, 
                        ymin=CImin , 
                        ymax=CImax, 
                        color=sens), position=position_dodge(width=0.6) )+ 
    ylim(0,NA)+
    xlab('') +theme(axis.title.y=element_blank(),text = element_text(size = 16)) +
    theme(legend.position = "none")
  
  pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.5,1.5) )
  
  ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,sCat,'_total_emission_', sSens,'.png'),
         plot = pga ,dpi=150,type='cairo')
  
} # end function

#************************************************************************************************************
#************************************************************************************************************

f.world_total <- function(cat){
  # world's total by category
  emi.tot.cat <- cat %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
                                   emi.unc.tot.min =f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, FALSE), # FALSE = correlated
                                   emi.unc.tot.max = f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, FALSE) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1]))/1000)
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2])/1000)
  emi.tot.cat$country <- 'world'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat/1000
  # ****
  # end world  total
  return(emi.tot.cat)
} # end function

#' Title
#'
#' @param cat.emi.country 
#' @param sSens 
#'
#' @return
#' @export
#' compare the emissions calclated by using two different distributions
#' @examples
f.plot_dist_comparison <- function(){ 
  
  emi.country.asym  <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run,  '_', 'UncCorr_emi_by_categories.Rdata') )  # 
  emi.country.sym   <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run,  '_', 'UncNorm_emi_by_categories.Rdata') )  # 
  
  
  asym <- f.plot_cat(emi.country.asym, FALSE)
  norm <- f.plot_cat(emi.country.sym, FALSE)
  
  names(asym)=names(norm) <- emi.keys.0
  
  emi.tot <- NULL
  for (t in 1:length(asym)){
    
    sCat <- f.get_emi_cat(emi.keys.0[t])
    
    cat.asym <- asym[[t]]
    cat.norm <- norm[[t]]
    
    dt.a            <- cat.asym[order(cat.asym$tot.subcat, decreasing=T),]
    dt.a$tot.subcat <- dt.a$tot.subcat
    dt.n            <- cat.norm[order(cat.norm$tot.subcat, decreasing=T),]
    dt.n$tot.subcat <- dt.n$tot.subcat
    dt.a$unctype    <- rep('log-normal', dim(dt.a)[1])
    dt.n$unctype    <- rep('normal', dim(dt.n)[1])
    
    dd  <-  rbind(dt.a,dt.n)
    dd  <-  dd[order(dd$tot.subcat, decreasing=T),]
    
    
    # world total
    emi.tot.a <- f.world_total(cat.asym)
    emi.tot.n <- f.world_total(cat.norm)
    
    emi.tot.a$unctype <- 'log-normal'
    emi.tot.n$unctype <- 'normal'
    
    emi.tot <- rbind(as.data.frame(emi.tot.a), as.data.frame(emi.tot.n))
    leg.tit <- 'uncertainty distribution'
    
    
    p <- ggplot(dd[1:50,]) +
      geom_pointrange(aes(x=reorder(country,-tot.subcat), y=tot.subcat, 
                          ymin=asym.unc.min/1000, 
                          ymax=asym.unc.max/1000, color=unctype), position=position_dodge(width=0.6)) + 
      ylab(' CH4 EDGAR emission (Tg)' ) +  xlab('')    +
      theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5)) +
      theme(legend.position = c(0.8, 0.8),text = element_text(size = 16), 
            plot.title = element_text(size = 14, face = "bold")) + labs(color=leg.tit)+
      ggtitle(paste0('EDGAR CH4 2012 - ' , emi.keys.0[t], ': ', sCat))
    
    # w <- ggplot(data=emi.tot) +
    #      geom_pointrange(aes(x=country, y=emi.tot.cat, 
    #                      ymin=CImin , 
    #                       ymax=CImax, 
    #                      color=unctype), position=position_dodge(width=0.6) )+ 
    #      ylim(0,NA) + xlab('') + theme(axis.title.y=element_blank()) + theme(legend.position = "none")
#    
#    pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)
    
    ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,sCat,'_UncType.png'),
           plot = p,width = 12, height = 7.5, units = "in", dpi=150,type='cairo')
           #device='tiff', ,
           #dpi = 260, pga)
    
    # do the plot of the distribution of min and max uncertianty fro the two types of distributions
    
    ddm <- melt(dd, id.vars=c('unctype', 'country','asym.max.perc',
                              'asym.min.perc','rel.unc.min','rel.unc.max', 'tot.subcat'))
    
    q <- ggplot(data=ddm, aes(x=variable, y=value/1000)) +
      geom_violin(scale='width' , aes(fill=unctype)) 
    
 #   q+ stat_summary(fun.y=median, geom="point", size=2, color="red", aes(shape=unctype))
    q <- q+xlab(c(''))+ylab('Tg')+scale_x_discrete(labels = c('unc min', 'unc MAX'))+
        # theme(axis.text.x=element_blank())+
       #  theme(legend.position = c(0.8, 10)) +
         ggtitle(paste0('EDGAR CH4 emission 2012 - ' , emi.keys.0[t], ': ', sCat))
   
      
    ggsave(filename=paste0(fig.dir, now_run, sCatAgg,  sCatEmi,sCat,'_minMAXUncType.png'),
           plot = q,dpi=150,type='cairo')
      
    
  } # end loop over categories(t)
    
} # end function
  
