
# 1. extract country total and uncertainty per country
g2.spec.cat  <- loadRData(file=paste0(out.dir, 'specific_cat__', now_run, '_',sUncCorr, 'emi_tot_by_country.Rdata') )
g2.total.cat <- loadRData(file=paste0(out.dir, 'total_cat__',    now_run, '_',sUncCorr, 'emi_tot_by_country.Rdata') )


EU28.cc    <- f.get_country_code(EU28)

gs <- f.extract_EU28(g2.spec.cat, 'specific_cat') # specific categories
gt <- f.extract_EU28(g2.total.cat, 'total_cat')   # cat 1,2,3,4,5 so to have the entire total

gs <- f.extract_ind(g2.spec.cat, 'specific_cat') # specific categories
gt <- f.extract_ind(g2.total.cat, 'total_cat')   # cat 1,2,3,4,5 so to have the entire total


# 2. extract country and sector emissions and uncertainty
load(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr,'emi_by_categories.Rdata')) 
# load(file="D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\N2O\\NOBoostFact\\emi_by_category_specific_cat__N2O_UncNorm_emi_by_categories.Rdata")

g1.EU28 <- lapply(g1.tot,function(x){subset(x,country %in% EU28_NS.cc) })

lapply(1:length(g1.EU28), function(i) write.csv(g1.EU28[[i]], 
                                               file = paste0(out.dir,names(g1.EU28[i]), ".csv"),
                                               row.names = FALSE))

g1.ind <- lapply(g1.tot,function(x){subset(x,country %in% country.ind$ISO3) })

lapply(1:length(g1.ind), function(i) write.csv(g1.ind[[i]], 
                                                file = paste0(out.dir,names(g1.ind[i]), ".csv"),
                                                row.names = FALSE))



#' Title
#'
#' @param g2 
#' @param sCatEmi 
#'
#' @return
#' @export
#'
#' @examples
f.extract_EU28 <- function(g2,sCatEmi){
  
  EU28_NS.cc <- f.get_country_code(EU28_NS)
  g.tmp <- subset(g2, country %in% EU28_NS.cc)
#  g3 <- do.call('rbind', g.tmp) 
#  g3$cat <- as.character(rep(names(g.tmp),  sapply(g.tmp, lengths)[1,]))
  #save(g3, file=paste0(out.dir,now_run,'_EDGAR_EU28.Rdata'))
  
#  g3 <- data.frame(g.tmp)
 # write.csv(g3, file=paste0(out.dir,'EU28_country_sector_', now_run,'_',sCatEmi, '.csv'))
  
  EU28_NS_tot <- f.EU_total_2(g.tmp)
  
  g.tmp[nrow(g.tmp) + 1,] = list(country="EU28_NS",
                                 tot.country = EU28_NS_tot$emi.tot.cat, 
                                 rel.unc.min = EU28_NS_tot$unc.emi.cat.min,
                                 rel.unc.max = EU28_NS_tot$unc.emi.cat.max, 
                                 asym.unc.min= EU28_NS_tot$CImin,
                                 asym.unc.max= EU28_NS_tot$CImax)
  write.csv(g.tmp, file=paste0(out.dir, 'EU28_country_tot_', now_run,'_',sCatEmi,  '.csv') )
  return(g.tmp)
}

#' f.EU_total_2
#'
#' @param cat0 
#'
#' @return
#' @export
#'
#' @examples
f.EU_total_2 <- function(cat0){
  # EU total by category
  emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                    emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # = correlated
                                    emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1])))
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2]))
  emi.tot.cat$country <- 'EU28_NS'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat
  # ****
  # end EU  total
  return(emi.tot.cat)
}

#' Title
#'
#' @param g2 
#' @param sCatEmi 
#'
#' @return
#' @export
#'
#' @examples
f.extract_ind <- function(g2,sCatEmi){
  
#   EU28_NS.cc <- f.get_country_code(EU28_NS)
  g.tmp <- subset(g2, country %in% country.ind$ISO3)
  #  g3 <- do.call('rbind', g.tmp) 
  #  g3$cat <- as.character(rep(names(g.tmp),  sapply(g.tmp, lengths)[1,]))
  #save(g3, file=paste0(out.dir,now_run,'_EDGAR_EU28.Rdata'))
  
  #  g3 <- data.frame(g.tmp)
  # write.csv(g3, file=paste0(out.dir,'EU28_country_sector_', now_run,'_',sCatEmi, '.csv'))
  
  Ind_tot <- f.ind_total_2(g.tmp)
  
  g.tmp[nrow(g.tmp) + 1,] = list(country="Ind",
                                 tot.country = Ind_tot$emi.tot.cat, 
                                 rel.unc.min = Ind_tot$unc.emi.cat.min,
                                 rel.unc.max = Ind_tot$unc.emi.cat.max, 
                                 asym.unc.min= Ind_tot$CImin,
                                 asym.unc.max= Ind_tot$CImax)
  write.csv(g.tmp, file=paste0(out.dir, 'IND_country_tot_', now_run,'_',sCatEmi,  '.csv') )
  return(g.tmp)
}

#' f.EU_total_2
#'
#' @param cat0 
#'
#' @return
#' @export
#'
#' @examples
f.ind_total_2 <- function(cat0){
  # EU total by category
  emi.tot.cat <- cat0 %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                    emi.unc.tot.min <- f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # = correlated
                                    emi.unc.tot.max <- f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
  names(emi.tot.cat) <- c('emi.tot.cat','unc.emi.cat.min','unc.emi.cat.max')
  
  CI.range.cat      <- with(emi.tot.cat, f.asymmetric_unc(unc.emi.cat.min, unc.emi.cat.max, emi.tot.cat) )
  emi.tot.cat$CImin <- with(emi.tot.cat, emi.tot.cat*(1-abs(CI.range.cat[1])))
  emi.tot.cat$CImax <- with(emi.tot.cat, emi.tot.cat*(1+CI.range.cat[2]))
  emi.tot.cat$country <- 'EU28_NS'
  emi.tot.cat$emi.tot.cat <- emi.tot.cat$emi.tot.cat
  # ****
  # end EU  total
  return(emi.tot.cat)
}
