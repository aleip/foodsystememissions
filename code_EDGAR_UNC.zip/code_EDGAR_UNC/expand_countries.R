
# expand countries defined by numerical code

edgar_countries <- read.csv(file=paste0(w.dir,'EDGAR_country.csv'), sep=',', header=T, colClasses = c(rep('character',4),'factor'))


unique.idx <- unique(edgar_countries['group_ID'])


idx.char <- as.character(unique.idx$group_ID)
if(any(idx.char=="")) {
  idx.char<-idx.char[-which(idx.char=="")]
}

countries.in.group <- list()
for (c in 1:length(idx.char)){
  
  c.tmp <- subset(edgar_countries, group_ID==idx.char[c], select=ISO3)
  assign(paste0('group.country.',idx.char[c]) ,c.tmp) # call the subset with the name group.country.#
  countries.in.group[[idx.char[c]]] <- c.tmp
  
}
# check for intersection
#ll <- ls()[grep('group.country.',ls())]
#Reduce(intersect, list(group.country.1,group.country.10,group.country.11,group.country.12,
#                       group.country.13,group.country.14,group.country.15,group.country.16,
#                      group.country.17,group.country.18,group.country.19,group.country.2,
#                      group.country.21,group.country.20,group.country.22,group.country.23,
#                       group.country.24,group.country.26,group.country.27,group.country.28,
#                       group.country.3,group.country.4,group.country.5,group.country.6,group.country.7,
#                       group.country.8,group.country.9))


# countries.in.group <- list(group.country.1,group.country.10,group.country.11,group.country.12,
#                                                   group.country.13,group.country.14,group.country.15,group.country.16,
#                                                  group.country.17,group.country.18,group.country.19,group.country.2,
#                                                  group.country.21,group.country.20,group.country.22,group.country.23,
#                                                   group.country.24,group.country.26,group.country.27,group.country.28,
#                                                   group.country.3,group.country.4,group.country.5,group.country.6,group.country.7,
#                                                   group.country.8,group.country.9)