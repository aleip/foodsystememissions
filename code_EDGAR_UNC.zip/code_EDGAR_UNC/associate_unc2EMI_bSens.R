#' Title
#'
#' @param uTable 
#'# called from main
#'#  b1Ax 
#'   b1A 
#' @return
#' @export
#' at this point the unc distribution is still symmetric about the mean value
#' @examples
f.associate_unc2EM_bSens <- function(uTable, b1Ax, b1A, b1a3b, b1a_fuel, bRice_sens ,bEnf, bMnm, b1B2, sSens)
  
{ # uTable is available from the main program (t.hold)
  
  # read in the EMission and associate each emi category to uncertainty
  # uTable <- loadRData(file=paste0(out.dir,'full_unc.Rdata')) 
  
  
  if(sYear == '2015')  {
    emi <- read.csv(file=paste0(data.dir,'CH4\\CH4_EmiV5FT2018_GWP.csv'), sep=',', header=T)
  } else if (sYear == '2012'){
    emi <- read.csv(file=paste0(data.dir,'CH4_EMI_v432.csv'), sep=',', header=T)
  }
  
  unc.summary <- data.frame(matrix(NA,nrow=nrow(emi),ncol=10) )
  # uTable$u.EM.min <- NA
  
  prog <- seq(1,length(emi$Process.code),500)
  for (p in 1:length(emi$Process.code) ){
    proc0    <- emi$Process.code[p]
    country  <- emi$Country[p]
    
    proc <- substring(proc0, 1,15)
    last_numeric_column <- as.numeric(which(sapply(emi,function(x){is.numeric(x)})))
    
    if (sYear==substr(colnames(emi)[5],2,5)) {
      #     emi.tmp <- emi[p,dim(emi)[2]]     # last numeric column 
      emi.tmp <- emi[p,last_numeric_column]
    } else {
      cat(' * warning in routine f.associate_unc2EM_CH4 * ', '\n')
    }
    
    
    if( any(p==prog)) { cat('process ', proc, 'for country ', as.character(country), ' *** ', round(100*p/length(emi$Process.code),2),'%','\n' )}
    
    #     u.row <- uTable[proc==uTable$process  & uTable$country==country,]
    u.row <- uTable[uTable$process==proc  & uTable$country==country,]
    # if (dim(u.row)[1]==0){
    #   string <- paste0('ohi ohi, cazzi amari for process ', proc, ' and country ', as.character(country) )#, '\n')
    #   cat(string, file=paste0(out.dir, 'warning_emi.text'), sep='\n', append=T)
    #   next()
    # }
    if (dim(u.row)[1]==0){
      proc <- substring(proc0, 1,11)
      u.row <- uTable[substring(as.character(uTable$process),1,11)==proc  & uTable$country==country,]
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    } else {
      
      
      proc <- substring(proc0, 1,7)
      u.row <- uTable[substring(as.character(uTable$process),1,7)==proc  & uTable$country==country,]
      
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    } else {
      
      proc <- substring(proc0, 1,3)
      u.row <- uTable[substring(as.character(uTable$process),1,3)==proc  & uTable$country==country,]
    }
    if (dim(u.row)[1]>0){
      u.row <- u.row[1,]
    }  else {
      
      string <- paste0('warning:no entry for process ', proc, ' and country ', as.character(country) )#, '\n')
      cat(string, file=paste0(out.dir, sDate,'_', now_run,'_', sSens,'_warning_emi.text'), sep='\n', append=T)
      next()
    } 
    
    
    
    
    # case of biofuel in sector 1A
    if(grepl('^1A', emi$IPCC06[p]) & grepl('x$',  emi$IPCC06[p])  ) {
      u.row$unc_tot_min <- f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
      u.row$unc_tot_max <- f.comb_unc(0.8,0.8)
      
      tmp <- f.unc_fact(u.row$unc_tot_min, u.row$unc_tot_min)
      if(b1Ax==TRUE){
        #     cat(as.character(emi$IPCC[p]),'\n')
        u.row$unc_tot_min_fact <- 0 # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
        u.row$unc_tot_max_fact <- 0 # f.comb_unc(0.8,0.8)
      }else{
        u.row$unc_tot_min_fact <- tmp[1]
        u.row$unc_tot_max_fact <- tmp[2]
      }
      tmp <- NULL
    }
    if(b1A==TRUE){
      if(grepl('^1A', emi$IPCC06[p]) & !grepl('x$',  emi$IPCC06[p])  ) {
        
        unc_tmp_min <- f.comb_unc(1,0.1)
        unc_tmp_max <- f.comb_unc(1,0.1) 
        
        unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
        
        #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
        u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
        u.row$unc_tot_max_fact <- unc_tmp_fact[2]
        
      }
    }
    if(b1a3b==TRUE){
      if( substring(proc0, 1,7) == 'TRO.ROA') {
        
        unc_tmp_min <- f.comb_unc(0.4,0.1)
        unc_tmp_max <- f.comb_unc(0.4,0.1) 
        
        unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
        
        #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
        u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
        u.row$unc_tot_max_fact <- unc_tmp_fact[2]
        
      }
    }
    
    
    if(b1a_fuel==TRUE){
      if( substring(proc0, 1,3) == 'ENE') {
        
        unc_tmp_min <- f.comb_unc(0.6,0.1) # factor two lower
        unc_tmp_max <- f.comb_unc(2.0,0.1) # and higher
        
        unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
        
        u.row$unc_tot_min_fact <- unc_tmp_fact[1] 
        u.row$unc_tot_max_fact <- unc_tmp_fact[2]
        
      }
    }
    
    
    if(substring(proc0, 1,7) == 'AGS.RIC' & bRice_sens){
     
      unc_tmp_min <- f.comb_unc(1.2,0.05)
      unc_tmp_max <- f.comb_unc(1.2,0.1) 
      
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      
      #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
      u.row$unc_tot_max_fact <- unc_tmp_fact[2] 
      
      
    }
    
    if(substring(proc0, 1,3) == 'ENF' & bEnf){
      unc_tmp_min <- f.comb_unc(0.3,0.05)
      unc_tmp_max <- f.comb_unc(0.5,0.05) 
      
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      
      #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
      u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    }
    
    
    if(substring(proc0, 1,3) == 'MNM' & bMnm){
      unc_tmp_min <- f.comb_unc(0.5,0.1)
      unc_tmp_max <- f.comb_unc(0.5,0.1) 
      
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      
      #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
      u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    }
    
    if (grepl('^1B2b', emi$IPCC06[p]) & b1B2 ){
      unc_tmp_min <- f.comb_unc(1,0.15)
      unc_tmp_max <- f.comb_unc(1,0.15) 
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] 
      u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    }
    
    if (substring(proc, 1,3) == 'WWT') { # case of waste water treatment
      
      unc.WWT <- f.WWT_unc(as.character(proc0), country)
      
      u.row$unc_tot_min <- unc.WWT[1]/100
      u.row$unc_tot_max <- unc.WWT[2]/100
      
      tmp <- f.unc_fact(u.row$unc_tot_min, u.row$unc_tot_min)
      u.row$unc_tot_min_fact <- tmp[1]
      u.row$unc_tot_max_fact <- tmp[2]
      tmp <- NULL
    }
    
    unc.summary[p,1] <- u.row$process
    unc.summary[p,2] <- u.row$ipcc06
    unc.summary[p,3] <- as.character(emi$IPCC06[p])
    unc.summary[p,4] <- u.row$country
    unc.summary[p,5] <- as.logical(u.row$cFlag)
    unc.summary[p,6] <- emi.tmp
    # symmetric distribution about the mean value, even negative values are accepted
    unc.summary[p,7] <- emi.tmp-(emi.tmp*as.numeric(u.row$unc_tot_min_fact))
    unc.summary[p,8] <- emi.tmp+(emi.tmp*as.numeric(u.row$unc_tot_max_fact))
    unc.summary[p,9]   <- as.numeric(u.row$unc_tot_min_fact)
    unc.summary[p,10]  <- as.numeric(u.row$unc_tot_max_fact)
    
    
  }
  
  names(unc.summary) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max')
  
  save(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,'CH4_Emission_unc_',sSens,'_',sYear,  '.Rdata'))
  write.csv(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,'CH4_Emission_unc_',sSens,'_',sYear,'.csv'))
  
  return(unc.summary)
} 
#-------------------------------------------------------------------------------------------------------------------
#' Title
#'
#' @param uTable 
#'# called from main
#'#  b1Ax 
#'   b1A 
#' @return
#' @export
#' at this point the unc distribution is still symmetric about the mean value
#' @examples
f.associate_unc2EM_bSens_N2O <- function(uTable, bx, b1A, bAir, bSea, b1B2, b2B, b3C4, b4D1,sSens)
  
{ # uTable is available from the main program (t.hold)
  
  # read in the EMission and associate each emi category to uncertainty
  # uTable <- loadRData(file=paste0(out.dir,'full_unc.Rdata')) 
  
  emi <- read.csv(file=paste0(data.dir,now_run,'_EMI_v432.csv'), sep=',', header=T)
  unc.summary <- data.frame(matrix(NA,nrow=nrow(emi),ncol=10) )
  # uTable$u.EM.min <- NA
  
  prog <- seq(1,length(emi$Process.code),500)
  for (p in 1:length(emi$Process.code) ){
    proc0    <- emi$Process.code[p]
    country  <- emi$Country[p]
    
    proc <- substring(proc0, 1,15)
    emi.tmp <- emi[p,dim(emi)[2]]     # last numeric column 
    
    
    if( any(p==prog)) { cat('process ', proc, 'for country ', as.character(country), ' *** ', round(100*p/length(emi$Process.code),2),'%','\n' )}
    
    #     u.row <- uTable[proc==uTable$process  & uTable$country==country,]
    u.row <- uTable[uTable$process==proc  & uTable$country==country,]
    if (dim(u.row)[1]==0){
      string <- paste0('ohi ohi, cazzi amari for process ', proc, ' and country ', as.character(country) )#, '\n')
      cat(string, file=paste0(out.dir, 'warning_emi.text'), sep='\n', append=T)
      next()
    }
    # case of biofuel in all sectors 
    if(bx==TRUE){
      if(grepl('x$',  emi$IPCC06[p])  ){
        #     cat(as.character(emi$IPCC[p]),'\n')
        unc_tmp_min <-  f.comb_unc(1,1) # function(unc.EF, unc.AD) {
        unc_tmp_max <-  f.comb_unc(1,1)
        unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
        
        #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
        u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
        u.row$unc_tot_max_fact <- unc_tmp_fact[2]
      }
    }
#    if (!grepl('x$',  emi$IPCC06[p]) ){ # exclude biofuels
#        if(grepl('^1.A', emi$IPCC06[p]) & b1A==TRUE) {
          
          if(b1A==TRUE){
            if(grepl('^1.A', emi$IPCC06[p]) & !grepl('x$',  emi$IPCC06[p])  ) {
  
          unc_tmp_min <- f.comb_unc(0.1,0.1)
          unc_tmp_max <- f.comb_unc(1,0.1) 
          
          unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
          
          #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
          u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
          u.row$unc_tot_max_fact <- unc_tmp_fact[2]
          
            }
          }
      
        if( substring(proc0, 1,7) == 'TNR.IAT' & bAir) {
          
          unc_tmp_min <- f.comb_unc(1,1)
          unc_tmp_max <- f.comb_unc(1,1) 
          
          unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
          
          #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
          u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
          u.row$unc_tot_max_fact <- unc_tmp_fact[2]
          
        }
      
      if(substring(proc0, 1,7) == 'TNR.SEA' & bSea){
        
        unc_tmp_min <- f.comb_unc(1,1)
        unc_tmp_max <- f.comb_unc(1,1) 
        
        unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
        
        u.row$unc_tot_min_fact <- unc_tmp_fact[1] 
        u.row$unc_tot_max_fact <- unc_tmp_fact[2] 
        
      }
      
      if(substring(proc0, 1,3) == 'CHE' & b2B){
        unc_tmp_min <- f.comb_unc(1,0.1)
        unc_tmp_max <- f.comb_unc(1,0.1) 
        
        unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
        
        u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
        u.row$unc_tot_max_fact <- unc_tmp_fact[2]
      }
      # 
      # 
      # if(substring(proc0, 1,3) == 'MNM' & bMnm){
      #   unc_tmp_min <- f.comb_unc(0.5,0.1)
      #   unc_tmp_max <- f.comb_unc(0.5,0.1) 
      #   
      #   unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      #   
      #   #      tmp <- f.asymmetric_unc(unc_tmp_fact[1],unc_tmp_fact[2], emi.tmp) 
      #   u.row$unc_tot_min_fact <- unc_tmp_fact[1] # f.comb_unc(0.8,0.3) # function(unc.EF, unc.AD) {
      #   u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    
    
    if (grepl('^3.C.4', emi$IPCC06[p]) & b3C4 ){
      unc_tmp_min <- f.comb_unc(1,0.1)
      unc_tmp_max <- f.comb_unc(1,0.1) 
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] 
      u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    }
    if (grepl('^1.B.2.b', emi$IPCC06[p]) & b1B2 ){
      unc_tmp_min <- f.comb_unc(0.1,0.05)
      unc_tmp_max <- f.comb_unc(1,0.1) 
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] 
      u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    }
    
    if (substring(proc, 1,7) == 'WWT.DOM' & b4D1) { # case of waste water treatment
      
      unc_tmp_min <- f.comb_unc(1,0.)
      unc_tmp_max <- f.comb_unc(1,0.) 
      unc_tmp_fact <- f.unc_fact(unc_tmp_min, unc_tmp_max)
      u.row$unc_tot_min_fact <- unc_tmp_fact[1] 
      u.row$unc_tot_max_fact <- unc_tmp_fact[2]
    }
 # } # end check on biofuels
  
  unc.summary[p,1] <- u.row$process
  unc.summary[p,2] <- u.row$ipcc06
  unc.summary[p,3] <- as.character(emi$IPCC06[p])
  unc.summary[p,4] <- u.row$country
  unc.summary[p,5] <- as.logical(u.row$cFlag)
  unc.summary[p,6] <- emi.tmp
  # symmetric distribution about the mean value, even negative values are accepted
  unc.summary[p,7] <- emi.tmp-(emi.tmp*as.numeric(u.row$unc_tot_min_fact))
  unc.summary[p,8] <- emi.tmp+(emi.tmp*as.numeric(u.row$unc_tot_max_fact))
  unc.summary[p,9]   <- as.numeric(u.row$unc_tot_min_fact)
  unc.summary[p,10]  <- as.numeric(u.row$unc_tot_max_fact)
  
  
} # end for loop

names(unc.summary) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max')

save(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_Emission_unc_',sSens,  '.Rdata'))
write.csv(unc.summary, file=paste0(out.dir,sCatAgg, sCatEmi,sUncCorr,now_run,'_Emission_unc_',sSens,'.csv'))

return(unc.summary)
} 

  