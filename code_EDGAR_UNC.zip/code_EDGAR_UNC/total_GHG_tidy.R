source('aggregate_GHG_functions.R')

bFood   <- T
if (!bFood){
out.dir <- "E:\\D_extra\\work\\GhG_move\\VERIFY\\EDGAR\\out\\"

g1.CO2 <- loadRData(file=paste0(out.dir,'CO2\\2015\\emi_by_category_EDGAR__CO2_UncCorr__2015emi_by_categories.Rdata'))
g1.N2O <- loadRData(file=paste0(out.dir,'N2O\\2015\\emi_by_category_EDGAR__N2O_UncCorr__2015emi_by_categories_max250.Rdata'))
g1.CH4 <- loadRData(file=paste0(out.dir,'CH4\\2015\\emi_by_category_EDGAR__CH4_UncCorr__2015emi_by_categories.Rdata'))
}
#food# 

if(bFood){
  out.dir <- 'E:\\D_extra\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\'
  g1.CH4 <- loadRData(file=paste0(out.dir,'CH4_emi_by_categories.Rdata'))
  g1.N2O <- loadRData(file=paste0(out.dir,'N2O_emi_by_categories_max250.Rdata'))
  g1.CO2 <- loadRData(file=paste0(out.dir,'CO2_emi_by_categories.Rdata'))
}

g2.CO2 <- f.prepare_data(g1.CO2, 'perc')  ; # does a melt
g2.N2O <- f.prepare_data(g1.N2O, 'perc'); 
g2.CH4 <- f.prepare_data(g1.CH4, 'perc') # rel unc (%)

if (bFood){
  g2.CH4$emi<- g2.CH4$emi*25
  g2.N2O$emi<- g2.N2O$emi*298
  write.csv(g2.CO2, file=paste0(paste0(out.dir,'CO2_2015_unc_by_country_and_sector.csv')))
  write.csv(g2.CH4, file=paste0(paste0(out.dir,'CH4_2015_unc_by_country_and_sector.csv')))
  write.csv(g2.N2O, file=paste0(paste0(out.dir,'N2O_2015_unc_by_country_and_sector_max250.csv')))
} else {
  write.csv(g2.CO2, file=paste0(paste0(out.dir,'CO2\\2015\\CO2_2015_unc_by_country_and_sector.csv')), sep=',')
  write.csv(g2.CH4, file=paste0(paste0(out.dir,'CH4\\2015\\CH4_2015_unc_by_country_and_sector.csv')), sep=',')
  write.csv(g2.N2O, file=paste0(paste0(out.dir,'N2O\\2015\\N2O_2015_unc_by_country_and_sector.csv')), sep=',')
}


g2 <- list(g2.CO2,g2.CH4,g2.N2O) 
names(g2) <- c('CO2','CH4','N2O'); #names(g2.EU) <- c('CO2','CH4','N2O')
g2.tot    <- reshape2::melt(g2,id.vars=c('country','emi','rel.unc.min','rel.unc.max', 'sector'))
write.csv(g2.tot, file='D:\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\prep_for_compartment_country.csv')
# open the file, add the food_system_compartmetn column and reopen it:
g2.FSC <- read.csv(file='D:\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\total_for_compartment_country.csv')

g2.FSC <- na.omit(g2.FSC)
dataFSC <- g2.FSC %>% group_by(country,Food_system_compartment) %>% 
  summarise(umin = f.aggregate_subcategory.tot(emi, rel.unc.min, T),
            umax = f.aggregate_subcategory.tot(emi, rel.unc.max, T),
            emit = sum(emi, na.rm=T))

write.csv(dataFSC, file='D:\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\total_for_compartment_country_paper.csv')


# subset g2.tot to any country group. if not, the world's total is:
bAsymmetricUnc <- T
GHG.sector <- f.EU28_calc(g2.tot, 'Tier1') # world's total

GHG.sector[[1]] # total
GHG.sector[[2]] # category/gas
if (bFood){
  write.csv(GHG.sector[[2]], file=paste0(out.dir,'total_GHG_by_gas_sector.csv'))
} else {
  write.csv(GHG.sector[[2]], file=paste0(out.dir,'GHG\\total_GHG_by_gas_sector.csv'))
}

unc.share <-GHG.sector[[2]] %>% group_by(L1,sector) %>% summarise(tot.sect = (unc.max*emi)^2/(GHG.sector[[1]]$emi.tot*GHG.sector[[1]]$comb_unc_max)^2)
unc.share[order(unc.share$tot.sect,decreasing = TRUE ),]


# extract annex1 countries
names(annex)<- c('country','classification')
GHG.annex <- merge(annex,g2.tot, by='country' )

g2.annex1 <- g2.tot[GHG.annex$classification=='Annex_I',]
g2.nonannex1 <- g2.tot[GHG.annex$classification=='Non-Annex_I',]

GHG.annex1 <- f.EU28_calc(g2.annex1, 'Tier1') # 
GHG.nonannex1 <- f.EU28_calc(g2.nonannex1, 'Tier1') # 





# plot three GHG separately (dodged with three unc, one each)
p1 <- ggplot(GHG.sector[[2]], aes(x=sector,y=emi, ymin=asym.unc.min, ymax=asym.unc.max, fill=L1))+
  geom_bar(stat='identity', position=position_dodge(0.9))+
  geom_errorbar(position=position_dodge(0.9), width=0.2)+#theme_hc() +
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
  ylab( paste0(' EDGAR GHG emission 2015 (kTonnes/year)' ) )+ ylim(c(0,9e+6))+
  #   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
  # coord_polar(start = 0)
  theme(legend.position=c(0.77,0.9))

GHG.sector[[1]]$country <- 'World'
p2 <- ggplot(GHG.sector[[1]], aes(x=country,y=emi.tot, ymin=CImin, ymax=CImax))+
  geom_bar(stat='identity', fill='steelblue3')+
  geom_errorbar( width=0.2)+#theme_hc() +
  theme(axis.title.x=element_blank(), axis.title.y=element_blank())

p12 <- grid.arrange(p1, p2, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)

ggsave(filename=paste0(out.dir,'GHG\\total_emission.png'),
       device='png', width = 12, height = 7.5, units = "in",
       dpi = 260, p12)

# plot all GHG together (stacked with one uncertainty)


datap <- GHG.sector[[2]][-which(GHG.sector[[2]]$sector=='FFF' | GHG.sector[[2]]$sector=='PRU' | GHG.sector[[2]]$sector=='NEU'),] 
u1.hold <- datap %>% group_by( sector ) %>% mutate(comb_unc_max = f.tot_unc(emi,asym.unc.max, F),
                                                             comb_unc_min = f.tot_unc(emi,asym.unc.min, F),
                                                             emi.tot = sum(emi, na.rm=T))
p1<- ggplot(data=datap) +  geom_bar(aes(x=sector,y=emi,  fill=L1),position='stack', stat='identity') + 
#  facet_grid( tier~.)+#, scale='free') +
  geom_errorbar(data=u1.hold, aes(x=sector, ymin=emi.tot-comb_unc_min*emi.tot, ymax=emi.tot+comb_unc_max*emi.tot), width=0.2, color='grey20')+
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
  ylab( paste0(' EDGAR GHG emission 2015 (kTonnes/year)' ) )+ 
  #   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
  # coord_polar(start = 0)
  theme(legend.position=c(0.77,0.9))    

world.tot <- data.frame('country'='world', 'GHG'=c('CH4','CO2','N2O'), 'emi'=c(6.34217e+6,	3.22736e+6,	1.75391e+6),
                        'unc.min'=8561406, 'unc.max'=14027350)
p2 <- ggplot(world.tot)+
  geom_bar(aes(x=country,y=emi,fill=GHG), stat='identity',position='stack' )+
  geom_errorbar(aes(x=country,  ymin=unc.min, ymax=unc.max), width=0.2)+#theme_hc() +
  theme(axis.title.x=element_blank(), axis.title.y=element_blank())+theme(legend.position='none')

p12 <- grid.arrange(p1, p2, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)

ggsave(filename=paste0(out.dir,'total_emission_stack_N2Omax250.png'),
       device='png', width = 12, height = 7.5, units = "in",
       dpi = 260, p12)
 
# plot by processes
# data <- read.csv(file='D:\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\total_GHG_by_gas_sector_radial.csv', stringsAsFactors = F)
data <- read.csv(file='D:\\work\\GhG_move\\EDGAR\\IPCC_food\\out\\total_GHG_by_gas_sector.csv', stringsAsFactors = F)
# above, GHG.sector[[2]] is written to file 'total_GHG_by_gas_sector.csv'. that file is open and a column added to 
# include the food compartment and luluc. the file is loaded back at this point foer plotting:

data1 <- data %>% group_by(Food_system_compartment) %>% 
  summarise(umin = f.aggregate_subcategory.tot(emi, unc.min, TRUE),
                                                     umax = f.aggregate_subcategory.tot(emi, unc.max, TRUE),
                                                     emit = sum(emi, na.rm=T))


p0 <-ggplot(data) + geom_bar(aes(x=Food_system_compartment, y=emi, fill=L1),position='stack', stat='identity') +
  
  geom_errorbar(data=data1, aes(x=Food_system_compartment, ymin=emit-umin*emit, ymax=emit+umax*emit), width=0.2, color='grey20')+
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
  ylab( paste0(' Food System DAta BAse emission 2015 (kTonnes/year)' ) )+ 
  #   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
  # coord_polar(start = 0)
  theme(legend.position=c(0.7,0.9)) 


# Save at png
ggsave(paste0(out.dir,'total_emission_processes.png'),
                  device='png', width = 12, height = 7.5, units = "in",
                  dpi = 260, p0)



#



