
# from: https://stats.stackexchange.com/questions/299135/calculate-confidence-intervals-for-lognormal-distribution

# mydat <- data.frame(value = rlnorm(1000, meanlog = ln(emi), sdlog = ln(unc)))
# elnormAlt(mydat$value, method = "mvue", ci = TRUE, ci.type = "two-sided", 
#           ci.method = "land", conf.level = 0.95)

f.aggregate_unc <- function (mean.a, mean.b, one_sigma.a, one_sigma.b, corr.ab) { 
  
#  mean.a <- 10
#  one_sigma.a <- 1 # +- sigma (68% CI))
#  
#  sigma.a <- 0.5*one_sigma.a
#  
#  mean.b  <- 24
#  one_sigma.b <- 12 # +- sigma (68% CI)
#  sigma.b <- 0.5*one_sigma.b
  
#  corr.ab <- 1 
  # the standard deviation for fully correlated variables is simply the sum of the standard deviation 0.5(u1+u2) =  0.5*(1+12)=6.5
  
  cov_matrix <- matrix(c(sigma.a^2, corr.ab*sigma.a*sigma.b, corr.ab*sigma.a*sigma.b, sigma.b^2), nrow=2)
  
  sample <- mvrnorm(10000, c(mean.a, mean.b), cov_matrix)
  
  sum <- rowSums(sample)
  
  unc.MC <- sqrt(var(sum))
  #[1] 6.5771 this is one sigma. the total uncertainty is +- sigma and the 95% CI is +-2*sigma = +- 13
  
  return(unc.MC)
}



f.comb_unc <- function(unc.EF, unc.AD) {
  if(!is.na(unc.EF) & !is.na(unc.AD)) {
    
    unc <- sqrt(unc.EF^2 + unc.AD^2) # eq3.1 IPCC guidelines 2006 (pag 3.28) )
  } else {
    unc <- NA
  }
  return(unc)
}


f.aggregate_subcategory <- function(emi,unc, bCountry, xFlag){
  unc.cat <- 0; unc.cat.x <-0; emi<-abs(emi)
  
  for (i in 1:length(unc)){
    if (is.na(emi[i]) | emi[i]==0.) {next()}
    if(emi[i] !=0 & is.na(unc[i])) {cat(' check i= ', i, '\n'); unc[i] <- 0}# {unc[i] <- 0} # mmhhh
 #   if(b.cat=='Margatita' & now_run =='CO2') {bCountry[i] <- F}
    #     bCountry[i] <- F # sensitivity case to see the effect of having implemented the bCountry flag option
    if (!xFlag[i]){ #exclude all biofuels
      if(bCountry[i]==T ){ #uncorrelated
        unc.cat <- sqrt((emi[i]*unc[i])^2 + unc.cat^2)
        
      } else if (bCountry[i]==F){ #correlated
        unc.cat <- (emi[i]*unc[i])+ unc.cat
      }
      
    } else { # do the same for biofuels
      if(bCountry[i]==T ){ #uncorrelated
        unc.cat.x <- sqrt((emi[i]*unc[i])^2 + unc.cat.x^2)
        
      } else if (bCountry[i]==F){ #correalted
        unc.cat.x <- (emi[i]*unc[i])+ unc.cat.x
      }
    } 
  }
  combined.unc <- f.comb_unc(unc.cat, unc.cat.x)
  rel.unc <- combined.unc/sum(emi, na.rm=T)
  
  return(rel.unc)
} # end function

# original before v5
# f.aggregate_subcategory <- function(emi,unc, bCountry){
#   unc.cat <- 0
# 
#   for (i in 1:length(unc)){
#     if (is.na(emi[i])) {next()}
#     #     bCountry[i] <- F # sensitivity case to see the effect of having implemented the bCountry flag option
#     if(bCountry[i]==T ){ #uncorrelated
#       unc.cat <- sqrt((emi[i]*unc[i])^2 + unc.cat^2)
# 
#     } else if (bCountry[i]==F){ #correalted
#       unc.cat <- (emi[i]*unc[i])+ unc.cat
# 
#     }
#   }
#   rel.unc <- unc.cat/sum(emi, na.rm=T)
# 
#   return(rel.unc)
# }
# end original
#------------------------------------------------------
f.aggregate_subcategory.tot <- function(emi,unc, bCountry){
  unc.cat <- 0
  
  emi=abs(emi)
  
  for (i in 1:length(unc)){
    if (is.na(emi[i])) {next()}
    if (is.na(unc[i])) {unc[i]<-0.} ##mhmhmhmhmh
    if(bCountry==T ){ #uncorrelated
      unc.cat <- sqrt((emi[i]*unc[i])^2 + unc.cat^2)

    } else if (bCountry==F){ #correalted
      unc.cat <- (emi[i]*unc[i])+ unc.cat
      
    }
  }
  rel.unc <- unc.cat/sum(emi, na.rm=T)

  return(rel.unc)
}
#----------------------------------------------------------

f.weight_unc <- function(unc.rel,unc.tot){
  # w.unc <- NULL

  # for (i in 1:length(unc.rel)){
    w.unc <- unc.rel/unc.tot
  
  return(w.unc)
  
}

#----------------------------------------------------------
#----------------------------------------------------------

f.asymmetric_unc_OLD <- function(min,max,mean){
  
  #min <- u.row$unc_tot_min  # debug
  #max <- u.row$unc_tot_max  # debug
  # mean <- emi.tmp # debug

  CI.range <- rep(NA,2)
  if (!is.na(mean) & !is.na(min) & !is.na(max)){
    min <- as.numeric(min) ; max<- as.numeric(max) ; mean <- as.numeric(mean)
    unc.tot.min <- min ;  unc.tot.max <- max
    
    if(bAsymmetricUnc){
      
      mu_g.min    <- exp(log(mean)-0.5*log(1+(unc.tot.min*100/200)^2) ) # geometric mean EQ 3.5 page 3.61
      mu_g.max    <- exp(log(mean)-0.5*log(1+(unc.tot.max*100/200)^2) )
      sigma_g.max <- exp(sqrt(log(1+(unc.tot.max*100/200)^2)))          # geometric standard deviation EQ 3.6 page 3.61
      sigma_g.min <- exp(sqrt(log(1+(unc.tot.min*100/200)^2)))
      
      
      CI.min <- (exp(log(mu_g.min)-1.96*log(sigma_g.min))-mean)/mean
      CI.max <- (exp(log(mu_g.max)+1.96*log(sigma_g.max))-mean)/mean   
      
      #    CI.range <- c(unc.tot.min/100 , unc.tot.max/100, CI.min, CI.max)
      CI.range <- c(CI.min, CI.max)

      
    } else { # case of symmetric uncertainty
      if (unc.tot.min >0.5) {
        unc.tot.min <- 1/(1+unc.tot.min) # see olivier et al 2002, bottom of table 9.
      }
     
      CI.range <- c(unc.tot.min, unc.tot.max)
    }#end if
#    browser()
  } 
  return(CI.range)
  
} # end function

f.asymmetric_unc <- function(min,max,mean){
  
  #min <- u.row$unc_tot_min  # debug
  #max <- u.row$unc_tot_max  # debug
  # mean <- emi.tmp # debug
  
  CI.range <- rep(NA,2)
  if (!is.na(mean) & !is.na(min) & !is.na(max)){
    min <- as.numeric(min) ; max<- as.numeric(max) ; mean <- as.numeric(mean)
    unc.tot.min <- min ;  unc.tot.max <- max
    CI.range <- c(unc.tot.min, unc.tot.max)
    
    if(bAsymmetricUnc){
      if (unc.tot.min >0.5) { # add this check on the 12 July. Asymmetric uncertainty is calculated only when lower bound is >=50%
        # as suggested by Margarita (mail 11 July 2019)
        mu_g.min    <- exp(log(mean)-0.5*log(1+(unc.tot.min*100/200)^2) ) # geometric mean EQ 3.5 page 3.61
        mu_g.max    <- exp(log(mean)-0.5*log(1+(unc.tot.max*100/200)^2) )
        sigma_g.max <- exp(sqrt(log(1+(unc.tot.max*100/200)^2)))          # geometric standard deviation EQ 3.6 page 3.61
        sigma_g.min <- exp(sqrt(log(1+(unc.tot.min*100/200)^2)))
        
        
        CI.min <- (exp(log(mu_g.min)-1.96*log(sigma_g.min))-mean)/mean
        CI.max <- (exp(log(mu_g.max)+1.96*log(sigma_g.max))-mean)/mean   
        
        #    CI.range <- c(unc.tot.min/100 , unc.tot.max/100, CI.min, CI.max)
        CI.range <- c(CI.min, CI.max)
      }# ends check on unc.min
      
    } else { # case of symmetric uncertainty
      if (unc.tot.min >0.5) { #original
        unc.tot.min <- 1/(1+unc.tot.min) # see olivier et al 2002, bottom of table 9.
        
      }   # ends check on unc.min
      
      
      CI.range <- c(unc.tot.min, unc.tot.max)
    } # ends symmetric vs unsymmetric
    
  } # ends chack on finite values of min, max ,mean
  
  return(CI.range)
  
} # end function
# ****************************************************************
f.unc_fact <- function(min, max){
  # min and max are the upper and lower uncertainties 
  
  if(bUncCorrFact){
    unc_fact_t <-rep(NA,2)
    
    if (!is.na(min) & !is.na(max)){
      min <- 100*as.numeric(min) ; max <- 100*as.numeric(max) 
      unc.tot.min <- min ;  unc.tot.max <- max
      
      
      if (min >=100 & min <=230) { 
        #     unc.min <- min*100 # transform in %
        FC <- ((-0.72+1.0921*min-0.00163*min^2+1.11*0.0000111*min^3)/min)^2
        unc.tot.min <- min*FC
        
      }
      if (max >=100 & max <=230) { 
        #      unc.max <- max*100 # transform in %
        FC <- ((-0.72+1.0921*max-0.00163*max^2+1.11*0.0000111*max^3)/max)^2
        unc.tot.max <- max*FC
        
      }
      unc_fact_t <- c(unc.tot.min/100, unc.tot.max/100) 
    }
  } else {
    unc_fact_t <- c(min,max)
  }
  return(as.numeric(unc_fact_t))
} # end function
#-----------------------------------------------------------------------
f.country_aggregation <- function(unc.table)
  
  # for aggregating to country level, this function selects all sectors to have the actual total
  # rather than a subset of important sectors
{
  
  emi.keys.0 <- c( '1', '2', '3',  '4', '5')
  
  
#  unc.table$xFlag <- ifelse(grepl('x',unc.table$ipccX),TRUE,FALSE) # Add a column of flags indicating
# the use of biofuels  
  
  g1 <- list()
  ## 1. aggregate by sector, for each country
  emi.keys <- paste0('^', emi.keys.0 )
  
  for (k in 1:length(emi.keys)){
    #  if(length(grep(emi.keys[k], unc.table$ipcc06)) >=1){
    g1[[k]] <- unc.table %>%   group_by(country) %>%  subset(  grepl(emi.keys[k], ipcc06)) %>%  
      summarise(emi.cat.country  = sum(emi, na.rm=T),
                emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
                emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
    cat('emi cat = ', emi.keys.0[k])
    
    # ***
    # NOW calculate asymmetric lognormal or normal CI
    # 
    CI.range <-  apply(g1[[k]],1,function(x){f.asymmetric_unc(as.numeric(x[3]),as.numeric(x[4]),as.numeric(x[2]))}) #passed arguments: min, max, mean
    #***
    #  original g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1]) #CI.range[1] should be negative for asymmetric
    minCI <- CI.range[1,]
    maxCI <- CI.range[2,]
    g1[[k]]$CImin <- g1[[k]][[2]]*(1- abs(minCI))
    #  g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1])
    g1[[k]]$CImax <- g1[[k]][[2]]*(1+ maxCI)
    g1[[k]]$CIminPerc <- as.numeric(minCI)
    g1[[k]]$CImaxPerc <- as.numeric(maxCI)
    CI.range <- NULL
    
  }
  
  #names(g1) <- emi.keys.0
  colnames <- c('country', 'tot.subcat','rel.unc.min','rel.unc.max','asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc')
  g.hold        <- lapply(g1, setNames, colnames)
  names(g.hold) <- emi.keys.0
  
  return(g.hold)
}
