
if(now_run=='CH4'){
  edgar.AD <- read.table(file=paste0(data.dir, "AD_CH4_EDGARv432.csv"), sep=',',header=T, na.strings='NULL',
                         colClasses=c('numeric',rep('character',2),'integer','factor',rep('numeric',45)))
  
  AD   <- subset(edgar.AD, select=c('Country_code_A3','ad_code','Y_2012')) # basic activity data for the year 2012; 
  
  # unc <-  read_excel_allsheets(file=paste0(data.dir,'CH4_compiled_uncertainties.xlsx'))
  u.AD <- read.table( file=paste0(data.dir,'CH4_AD_unc.csv'), sep=',', header=T, na.strings='NULL',
                      colClasses= c(rep('character',9), rep('numeric',2)  ) )
  
  u.EF <- read.table( file=paste0(data.dir,'CH4_EF_unc.csv'), sep=',', header=T, na.strings='NULL',
                      colClasses= c(rep('character',9), rep('numeric',5), 'character'  ) )   # unique EDGAR EF code
  
  # unique EF codes in EDGAR
  #unique.EF <- read.table( file=paste0(data.dir,'unique_EF_edgar_code.csv'), sep=',', header=T, na.strings='NULL',
  #                        colClasses= rep('character',6)  )
  
  # get the countries for which specific emission factors are provided
  country_by_code.EF <- read.table( file=paste0(data.dir,'CH4_get_specific_countries.csv'), sep=',', header=T, na.strings='NULL',
                                    colClasses= rep('character',4)  )
  
} else if (now_run == 'N2O'){
  
  edgar.AD <- read.table(file=paste0(data.dir.fix, "AD_v432_release.csv"), sep=',',header=T, na.strings='NULL',
                         colClasses=c(rep('character',3),  'numeric' ) )
  
  AD   <- subset(edgar.AD, select=c('Country_code_A3','ad_code','Y_2012')) # basic activity data for the year 2012; 
  
  # unc <-  read_excel_allsheets(file=paste0(data.dir,'CH4_compiled_uncertainties.xlsx'))
  u.AD <- read.table( file=paste0(data.dir,'AD_unc.csv'), sep=',', header=T, na.strings='NULL',
                      colClasses= c(rep('character',9), rep('numeric',2)  ) )
  
  u.EF <- read.table( file=paste0(data.dir,'N2O_EF_unc.csv'), sep=',', header=T, na.strings='NULL',
                      colClasses= c(rep('character',9), rep('numeric',4)) )#, rep('character',2)  ) )   # unique EDGAR EF code
  
  # unique EF codes in EDGAR
  #unique.EF <- read.table( file=paste0(data.dir,'unique_EF_edgar_code.csv'), sep=',', header=T, na.strings='NULL',
  #                        colClasses= rep('character',6)  )
  
  # get the countries for which specific emission factors are provided
  country_by_code.EF <- read.table( file=paste0(data.dir,'N2O_get_specific_countries.csv'), sep=',', header=T, na.strings='NULL',
                                    colClasses= rep('character',4)  )  
  
} else if (now_run == 'CO2'){
  edgar.AD <- read.table(file=paste0(data.dir.fix, "AD_v432_release.csv"), sep=',',header=T, na.strings='NULL',
                        colClasses=c(rep('character',3),  'numeric' ) )
 # edgar.AD <- read.table(file=paste0(data.dir.fix, "AD_v5_release.csv"), sep=',',header=T, na.strings='NULL',
#                       colClasses=c(rep('character',3),  'numeric' ) )
  
  AD   <- subset(edgar.AD, select=c('Country_code_A3','ad_code','Y_2012')) # basic activity data for the year 2012; 
  
  # unc <-  read_excel_allsheets(file=paste0(data.dir,'CH4_compiled_uncertainties.xlsx'))
  u.AD <- read.table( file=paste0(data.dir,'CO2_AD_unc.csv'), sep=',', header=T, na.strings='NULL',
                      colClasses= c(rep('character',9), rep('numeric',2)  ) )
  
  u.EF <- read.table( file=paste0(data.dir,'CO2_EF_unc.csv'), sep=',', header=T, na.strings='NULL',
                      colClasses= c(rep('character',5), rep('numeric',4)) )#, rep('character',2)  ) )   # unique EDGAR EF code
  
  # unique EF codes in EDGAR
  #unique.EF <- read.table( file=paste0(data.dir,'unique_EF_edgar_code.csv'), sep=',', header=T, na.strings='NULL',
  #                        colClasses= rep('character',6)  )
  
  # get the countries for which specific emission factors are provided
  country_by_code.EF <- read.table( file=paste0(data.dir,'CO2_get_specific_countries.csv'), sep=',', header=T, na.strings='NULL',
                                    colClasses= rep('character',4)  )
}


other_countries <- read.table(file=paste0(data.dir.fix, "other_countries.csv"), header=T, sep=',',colClasses=rep('character',2))

                            