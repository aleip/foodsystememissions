
loadRData <- function(fileName){
  # copied from http://stackoverflow.com/questions/5577221/how-can-i-load-an-object-into-a-variable-name-that-i-specify-from-an-r-data-file 
  #loads an RData file, and returns it
  load(fileName)
  get(ls()[ls() != "fileName"])
} # end function


f.emi_share_unc <- function(unc.summary)
  # E.solazzo 27 November 2019
  # to deal with additional unc introduced by food share emission
  
{
  food.dir <- 'D:\\work\\GhG_move\\EDGAR\\IPCC_food\\'
  data.emi <- paste0(food.dir, 'data\\')
  out.dir  <- paste0(food.dir, 'out\\') 
  processed_unc_dir <- 'D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\'
  GHG     <- c('CH4', 'N2O', 'CO2'); sYear <- '2015'
  now_run <- GHG[2]
 
  emi.share <- read.csv(file=paste0(data.emi,'sector_specific_uncertainty.csv'), header=T, sep=',', stringsAsFactors = F)
  # loop over unc.summary
  # load unc.summary
#  emi <- read.csv(file=paste0(data.emi,'N2O_emi_food_2015.csv'), sep=',', header=T)
#  unc.summary <- loadRData(file= "D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\N2O\\2015\\emi_by_category_EDGAR_UncCorr_N2O_2015_Emission_unc.Rdata")

  emi <- read.csv(file=paste0(data.emi,now_run,'_emi_food_2015.csv'), sep=',', header=T, stringsAsFactors = F)
  # now take the output of 'associate_unc2EM'
  if (now_run =='N2O'){
#  unc.summary <- loadRData(file= paste0(processed_unc_dir ,now_run, '\\',sYear,'\\emi_by_category_EDGAR_UncCorr_', now_run,'_', sYear,'_Emission_unc.Rdata' ))
  unc.summary <- loadRData(file= paste0(processed_unc_dir ,now_run, '\\',sYear,'\\emi_by_category_EDGAR_UncCorr_N2O_2015_Emission_unc_max250.Rdata'))
  } else {
   unc.summary <- loadRData(file= paste0(processed_unc_dir ,now_run, '\\',sYear,'\\emi_by_category_EDGAR_UncCorr_', now_run,'_Emission_unc.Rdata' ))
  }
  
    
#    emi <- read.csv(file=paste0(data.emi,'CO2_emi_food_2015.csv'), sep=',', header=T)
#    unc.summary <- loadRData(file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\out\\CO2\\2015\\emi_by_category_EDGAR_UncCorr_CO2_Emission_unc.Rdata')
  
  
  unc.summary.food <- data.frame(matrix(NA))# ,nrow=2*nrow(emi),ncol=10) )
  
  emi$processes <- substring(emi$Process.code,1,15)
  e4 <- emi %>% group_by(Country,processes) %>% mutate(emi4=sum(X2015,na.rm=T))
  emi4f <- e4 %>% group_by(Country) %>% distinct(processes,.keep_all=T)


  
  prog <- seq(1,length(emi4f$processes),500)
  #  idx <- which(grepl('TNR.DAT' ,emi$Process.code))
  #  for (p in idx ){
  k <- 0 #; proc0p <- '' ; emip <- -999 
  for (p in 1:length(emi4f$processes) ){
    proc0    <- as.character(emi4f$Process.code[p])
    country  <- emi4f$Country[p]; Scountry <- as.character(country)
    if( any(p==prog)) { cat('process ', as.character(proc0), 'for country ', as.character(country), ' *** ', round(100*p/length(emi4f$Process.code),2),'%','\n' )}
    #browser()
    proc <- substring(proc0, 1,15)
    proc <- as.character(proc)
#   u.row <- unc.summary[unc.summary$processes==proc  & unc.summary$country==country & !is.na(unc.summary$emi) ,]
    u.row <- filter(unc.summary, processes==proc  & country==Scountry )
    u.row.idx <- which(unc.summary$processes==proc  & unc.summary$country==country & !is.na(unc.summary$emi))
    
    k <- k+1
    if (dim(u.row)[1]>=1 &  !is.na(emi4f$emi4[p])){
      #     if(dim(u.row)[1] > 1) 
      #        {cat('dim u.row >1 ',' process ', proc, 'for country ', as.character(country),'\n')
      #        browser()
      #      }
      
      #      proc0p <- proc0 ; emip <- emi$X2015[p] # store current vlaues for comparison at next loop; 
      # this check is necessary to avoid overcounting rows
      #     for (j in 1:dim(u.row)[1]){
      #     k <- k+1 # original
      # deal with emission share uncertainty
      #    substr15 <- paste(paste0('^',substring(proc0, 1,7)), paste0(substring(proc0, 13,15), '$'), collapse='&')
      substr15a <- paste0('^',substring(proc0, 1,7) )
      substr15b <- paste0(substring(proc0, 13,15), '$')
      
      sbstr11 <- paste0('^',substring(proc0, 1,11),'$')
      sbstr7  <- paste0('^',substring(proc0, 1,7),'$')
      sbstr3  <- paste0('^',substring(proc0, 1,3),'$')
      sbstr <- c(sbstr11, sbstr7,sbstr3, substr15a)
      
      if (any(grepl(sbstr11, emi.share$process) | grepl(sbstr7, emi.share$process) | grepl(sbstr3, emi.share$process) |
              (grepl (substr15a, emi.share$process) & grepl(substr15b, emi.share$process)))){
        #         cat('process ', proc, ' for country ', as.character(country), '\n')
        #     browser()
        emi.share.row <- which(sapply(sbstr,function(x){grepl(x,emi.share$process )}), arr.ind=TRUE)[1]
        emi.share.min <- emi.share[emi.share.row,'min']/100
        emi.share.max <- emi.share[emi.share.row,'max']/100
        
        unc.comb.min <- sqrt(u.row[1,]$unc.min^2+ emi.share.min^2)
        unc.comb.max <- sqrt(u.row[1,]$unc.max^2+ emi.share.max^2)
        
        unc.emi.min <- emi4f$emi4[p]*(1-abs(unc.comb.min))
        unc.emi.max <- emi4f$emi4[p]*(1+unc.comb.max)
        
        unc.summary.food[k,1] <- u.row[1,]$processes
        unc.summary.food[k,2] <- u.row[1,]$ipcc06
        unc.summary.food[k,3] <- as.character(emi4f$IPCC06[p])
        unc.summary.food[k,4] <- u.row[1,]$country
        unc.summary.food[k,5] <- as.logical(u.row[1,]$iFlag)
        unc.summary.food[k,6] <- emi4f$emi4[p]
        unc.summary.food[k,7] <- unc.emi.min
        unc.summary.food[k,8] <- unc.emi.max
        unc.summary.food[k,9]  <-  unc.comb.min
        unc.summary.food[k,10] <-  unc.comb.max
        unc.summary.food[k,11] <- 'low_conf'
        
      } else { # u.row not empty: two possibilities: 1) needs extra unc due to food fraction
        #                                     2) fine as it is, no extra modification required 
        unc.summary.food[k,1]  <- u.row[1,]$processes
        unc.summary.food[k,2]  <- u.row[1,]$ipcc06
        unc.summary.food[k,3]  <- as.character(emi4f$IPCC06[p])
        unc.summary.food[k,4]  <- u.row[1,]$country
        unc.summary.food[k,5]  <- as.logical(u.row[1,]$iFlag)
        unc.summary.food[k,6]  <- emi4f$emi4[p]
        unc.summary.food[k,7]  <- unc.summary[u.row.idx[1], 'unc.emi.min']
        unc.summary.food[k,8]  <- unc.summary[u.row.idx[1], 'unc.emi.max']
        unc.summary.food[k,9]  <- unc.summary[u.row.idx[1], 'unc.min']
        unc.summary.food[k,10] <- unc.summary[u.row.idx[1], 'unc.max']
        unc.summary.food[k,11] <- 'high_conf'
        
      } 
      #        cat('j= ', j, 'of ',  dim(u.row)[1], '\n')
      #     } # end loop over dim u.row
    } else{
      u.row <- unc.summary[unc.summary$processes==proc & !is.na(unc.summary$emi) ,] # look up for same process in anothe country
      #    u.row <- na.omit(u.row)
      u.row.idx <- which(unc.summary$processes==proc  & !is.na(unc.summary$emi))
      if(dim(u.row)[1]>=1){
        #  next()
        unc.summary.food[k,1]  <- proc0 
        unc.summary.food[k,2]  <- u.row[1,]$ipcc06
        unc.summary.food[k,3]  <- as.character(emi4f$IPCC06[p])
        unc.summary.food[k,4]  <- country
        unc.summary.food[k,5]  <- as.logical(u.row[1,]$iFlag)
        unc.summary.food[k,6]  <- emi4f$emi4[p]
        unc.summary.food[k,7]  <- emi4f$emi4[p]*(1-abs(unc.summary[u.row.idx[1], 'unc.min']))
        unc.summary.food[k,8]  <- emi4f$emi4[p]*(1+unc.summary[u.row.idx[1], 'unc.max'])
        unc.summary.food[k,9]  <- unc.summary[u.row.idx[1], 'unc.min']
        unc.summary.food[k,10] <- unc.summary[u.row.idx[1], 'unc.max']
        unc.summary.food[k,11] <- 'unc_from_another_country'
      } else {
        proc_d <- substring(proc,1,3)
        u.row.idx <- which(grepl(paste0('^',proc_d), unc.summary$processes))[1]
        u.row <- unc.summary[u.row.idx,] # look up for same process in anothe country
        unc.summary.food[k,1]  <- proc0 
        unc.summary.food[k,2]  <- u.row[1,]$ipcc06
        unc.summary.food[k,3]  <- as.character(emi4f$IPCC06[p])
        unc.summary.food[k,4]  <- country
        unc.summary.food[k,5]  <- as.logical(u.row[1,]$iFlag)
        unc.summary.food[k,6]  <- emi4f$emi4[p]
        unc.summary.food[k,7]  <- emi4f$emi4[p]*(1-abs(unc.summary[u.row.idx[1], 'unc.min']))
        unc.summary.food[k,8]  <- emi4f$emi4[p]*(1+unc.summary[u.row.idx[1], 'unc.max'])
        unc.summary.food[k,9]  <- unc.summary[u.row.idx[1], 'unc.min']
        unc.summary.food[k,10] <- unc.summary[u.row.idx[1], 'unc.max']
        unc.summary.food[k,11] <- 'unc_low_agg_level'
        
      }
      #   cat(unc.summary.food[k,], '\n')
    }
  }
  names(unc.summary.food) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max','confidence')
  unc.summary.food.c <- unc.summary.food %>% filter(!is.na(emi) & !emi==0) #, .keep_all=T)
#   unc.summary.food.c <- unc.summary.food %>% group_by(Country)%>%summarise(emi=sum(emi,na.rm=T))
  # check
  
 # a <- merge(unc.summary.food,emi,by=c('Country','processes'),all.x=F)
#  b <- a %>% group_by(Country) %>% summarise(tot=sum(X2015.y, na.rm=T))
  
  
  
#  tot<-unc.summary.food.c %>% group_by(country)%>%summarise(emi=sum(emi))
#  tot.true <- emi %>% group_by(Country)%>%summarise(emi=sum(X2015, na.rm=T))
#  names(unc.summary.food.c)<-names(tot.true)
#  merge(unc.summary.food.c, tot.true, by='Country')
  
  
  save(unc.summary.food.c,      file=paste0(out.dir,now_run,'_Emission_unc_food_max250.Rdata'))
  write.csv(unc.summary.food.c, file=paste0(out.dir,now_run,'_Emission_unc_food_max250.csv'))
}# end function

#***************************************************************************************************************
# back to EDGAR_main
unc.table <- loadRData(file=paste0(out.dir,now_run,'_Emission_unc_food_max250.Rdata'))
unc.table$xFlag <- ifelse(grepl('x',unc.table$ipccX),TRUE,FALSE) # Add a column of flags indicating 

names(unc.table) <- c('processes', 'ipcc06', 'ipccX',  'country', 'iFlag','emi','unc.emi.min','unc.emi.max','unc.min','unc.max','confidence','xFlag')
k<-1
g1 <- list()
## 1. aggregate by sector, for each country
emi.keys <- paste0('^', emi.keys.0 )
for (k in 1:length(emi.keys)){
  if(length(grep(emi.keys[k], unc.table$processes)) >=1){
    #    if(length(grep(emi.keys[k], unc.table$ipcc06)) >=1){
    g1[[k]] <- unc.table %>%   group_by(country) %>%  subset(grepl(emi.keys[k], processes)) %>%  
      #      g1[[k]] <- unc.table %>%   group_by(country) %>%  subset(grepl(emi.keys[k], processes) & xFlag==F) %>%  # no biofuels
      #        subset(  grepl(emi.keys[k], ipcc06)) %>%  
      summarise(emi.cat.country  = sum(emi, na.rm=T),
                                   emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
                                   emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
    cat('emi cat = ', emi.keys.0[k])
    
    # ***
    # NOW calculate asymmetric lognormal or normal CI
    # 
    CI.range <-  apply(g1[[k]],1,function(x){f.asymmetric_unc(as.numeric(x[3]),as.numeric(x[4]),as.numeric(x[2]))}) #passed arguments: min, max, mean
    #***
    #  original g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1]) #CI.range[1] should be negative for asymmetric
    minCI <- CI.range[1,]
    maxCI <- CI.range[2,]
    g1[[k]]$CImin <- g1[[k]][[2]]*(1- abs(minCI))
    #  g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1])
    g1[[k]]$CImax <- g1[[k]][[2]]*(1+ maxCI)
    g1[[k]]$CIminPerc <- as.numeric(minCI)
    g1[[k]]$CImaxPerc <- as.numeric(maxCI)
    CI.range <- NULL
    
    
  } else {
    g1[[k]] <- rep(NA,8) # 8 is the number of columns set with colnames 
  }   #end if
} 

#names(g1) <- emi.keys.0
colnames <- c('country', 'tot.subcat','rel.unc.min','rel.unc.max','asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc')
g1.tot <- lapply(g1, setNames, colnames)
names(g1.tot) <- emi.keys.0
save(g1.tot, file=paste0(out.dir,now_run,'_emi_by_categories_max250.Rdata')) 

g2 <- do.call('rbind', g1.tot)
g2.tot <- g2 %>% group_by(country) %>% summarise(emi.tot.country = sum(tot.subcat, na.rm=T),
                                                 emi.unc.country.min = f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, TRUE), # TRUE = uncorrelated
                                                 emi.unc.country.max = f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, TRUE) )
# emi.weight.country <- f.weight_unc(rel.unc.max, 
#                                   f.aggregate_subcategory(emi.tot.country, as.numeric(rel.unc.max),  TRUE)) ))

CI.range <-  apply(g2.tot,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
minCI <- CI.range[1,]
maxCI <- CI.range[2,]
g2.tot$CImin <- g2.tot$emi.tot.country*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
g2.tot$CImax <- g2.tot$emi.tot.country*(1+ maxCI)
#  g1[[k]]$CIminPerc <- as.numeric(CI.range[1])
#  g1[[k]]$CImaxPerc <- as.numeric(CI.range[2])
names(g2.tot) <- c('country', 'tot.country', 'rel.unc.min','rel.unc.max','asym.unc.min', 'asym.unc.max')
save(g2.tot, file=paste0(out.dir,now_run,'_emi_tot_by_country_max250.Rdata') )
write.csv(g2.tot, file=paste0(out.dir,now_run,'_emi_tot_by_country_max250.csv'))
#--------

emi.glob <- g2.tot %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                 emi.unc.tot.min = f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # FALSE = correlated
                                 emi.unc.tot.max = f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
emi.glob <- as.data.frame(append(emi.glob, 'World', after=0))
CI.range <-  apply(emi.glob,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
minCI <- CI.range[1,]; maxCI <- CI.range[2,]
emi.glob$CImin <- emi.glob$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
emi.glob$CImax <- emi.glob$emi.tot*(1+ maxCI)

# add to g.tot for plotting
names(emi.glob) <- names(g2.tot)
g.tot <- merge (emi.glob,as.data.frame(g2.tot),all=T)
# if (bPlot) f.gvis_plot(g.tot)

EU28 <- g2.tot[g2.tot$country%in% EU28.cc,]
emi.EU28 <- EU28 %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                               emi.unc.tot.min = f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # FALSE = correlated
                               emi.unc.tot.max = f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
emi.EU28 <- as.data.frame(append(emi.EU28, 'EU28', after=0))
CI.range <-  apply(emi.EU28,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
minCI <- CI.range[1,] ; maxCI <- CI.range[2,]
emi.EU28$CImin <- emi.EU28$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
emi.EU28$CImax <- emi.EU28$emi.tot*(1+ maxCI)

# add to g.tot for plotting
names(emi.EU28) <- names(g2.tot)
g.tot <- merge (g.tot,as.data.frame(emi.EU28),all=T)


# Save the final table
#g.tot$unc.emi.min <- ifelse(g.tot$tot.country>(g.tot$tot.country*g.tot$rel.unc.min), 
#                            g.tot$tot.country-(g.tot$tot.country*g.tot$rel.unc.min),0)
#g.tot$unc.emi.max <- g.tot$tot.country+(g.tot$tot.country*g.tot$rel.unc.max)

# write.csv(g.tot, file=paste0(proc.dir, now_run,'_tot_emission_by_country_full_correlation.csv')) # when bCountry[i] <- F in function 'f.aggregate_subcategory'
write.csv(g.tot, file=paste0(out.dir, now_run,'_emission_by_country_', sYear,'_',Sys.Date(),'_max250.csv'))


