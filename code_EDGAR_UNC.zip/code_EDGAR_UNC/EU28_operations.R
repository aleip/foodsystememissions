
detach(package:plyr)
source('EU_28_functions.R')

emi.keys <- paste0('^', emi.keys.0 )
EU28_NS.cc <- f.get_country_code(EU28_NS)

#*************************************************
# generate the inventory for EU28, that is the emission from each fuel/category and associate the uncertanty from
# any EU28 country (set to Austria in function )
# starts from unc.table

#emi <- read.csv(file=paste0(data.dir,now_run,'_EMI_CHE_2015.csv'), sep=',', header=T)
#emi_EU28 <- emi[emi$Country %in%  EU28.cc,]

unc.table <- loadRData(file=paste0(proc.dir,sUncCorr,'unc.table.Rdata'))
ss  <- unc.table[unc.table$country %in% EU28.cc,]

# for CO2 group by fuel
# emi_EU28_fuel.tmp <- emi_EU28 %>% group_by(substring(Process.code, 1,11)) %>% summarise(tot=sum(X2015, na.rm=T)) %>% 'colnames<-' (c('processes','tot'))
# if(now_run == 'CO2' & b.cat == 'Margarita'){ # original
if( b.cat == 'Margarita' | b.cat == 'EDGAR'){
  emi_EU28_fuel.tmp <- ss %>% group_by(substring(processes, 1,11)) %>% summarise(tot=sum(emi, na.rm=T)) %>% 'colnames<-' (c('processes','tot'))

  } else {
  emi_EU28_fuel.tmp <- ss %>%  group_by(substring(ipcc06, 1,11)) %>%  summarise(tot=sum(emi, na.rm=T)) %>% 'colnames<-' (c('processes','tot'))
}
emi_EU28_fuel.tmp <- data.frame(emi_EU28_fuel.tmp)

unc.min <- NULL; unc.max <- NULL; ipcc06 <- NULL; ipccX <- NULL
for (i in 1:dim(emi_EU28_fuel.tmp)[1]){
  unc.min = rbind(unc.min, f.find_unc_EU28(ss,emi_EU28_fuel.tmp[i,1])[1])
  unc.max = rbind(unc.max, f.find_unc_EU28(ss,emi_EU28_fuel.tmp[i,1])[2])
  ipcc06  <- rbind(ipcc06, f.find_unc_EU28(ss,emi_EU28_fuel.tmp[i,1])[3])
  ipccX   <- rbind(ipccX,  f.find_unc_EU28(ss,emi_EU28_fuel.tmp[i,1])[4])
}

EU28_wrap <- data.frame('processes'= emi_EU28_fuel.tmp$process, 
                        'emi'    = emi_EU28_fuel.tmp$tot/1000, 'unc.min'= as.numeric(as.character(unc.min)),
                        'unc.max'= as.numeric(as.character(unc.max)) , 
                        'ipcc06' = as.character(ipcc06) , 'ipccX' = as.character(ipccX),
                        'iFlag'=rep(FALSE,length(emi_EU28_fuel.tmp$process)),
                        'xFlag'=ifelse(grepl('x',ipccX), TRUE, FALSE))


EU.tot <- EU28_wrap %>% summarise(emi.tot = sum(emi, na.rm=T),
                                  uncmin = f.aggregate_subcategory.tot(emi, unc.min, TRUE), # TRUE = uncorrelated
                                  uncmax = f.aggregate_subcategory.tot(emi, unc.max, TRUE) ) %>% 'colnames<-' (c('emi.tot','unc.min','unc.max'))

CI.range <-  f.asymmetric_unc(EU.tot[2],EU.tot[3],EU.tot[1])
minCI <- CI.range[1]
maxCI <- CI.range[2]
EU.tot$CImin <- EU.tot$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
EU.tot$CImax <- EU.tot$emi.tot*(1+ maxCI)
#**********************************************************
# finally, aggregate by sector for the EU28 as a whole
g1.EU28 <- f.cat_for_EU28(EU28_wrap,TRUE)

# ---------------------------------------------------------

rm(CI.range); rm(minCI); rm(maxCI)

#****now do the same for the individual country (correlated) case
# starting from unc.table generate EU total

#unc.table <- loadRData(file=paste0(proc.dir,sUncCorr,'unc.table.Rdata'))
#ss  <- unc.table[unc.table$country %in% EU28.cc,]
sss <- ss %>% group_by(substring(processes, 1,3)) %>% summarise(emi.tot = sum(emi, na.rm=T),
                                        uncmin = f.aggregate_subcategory.tot(emi, unc.min, FALSE), # 
                                        uncmax = f.aggregate_subcategory.tot(emi, unc.max, FALSE) ) %>% 'colnames<-' (c('emi.cat','emi.tot', 'unc.min','unc.max'))

EU.tot.corr <-  sss %>% summarise(emitot = sum(emi.tot, na.rm=T),
                           uncmin = f.aggregate_subcategory.tot(emi.tot, unc.min, TRUE), # 
                           uncmax = f.aggregate_subcategory.tot(emi.tot, unc.max, TRUE) ) %>% 'colnames<-' (c('emi.tot', 'unc.min','unc.max'))

CI.range <-  f.asymmetric_unc(EU.tot.corr[2],EU.tot.corr[3],EU.tot.corr[1])
minCI <- CI.range[1]
maxCI <- CI.range[2]
EU.tot.corr$CImin <- EU.tot.corr$emi.tot*(1- abs(minCI))/1000 #CI.range[1] should be negative for asymmetric distribution
EU.tot.corr$CImax <- EU.tot.corr$emi.tot*(1+ maxCI)/1000
rm(CI.range); rm(minCI); rm(maxCI); rm(sss)
#-----------------------------------------------------
# create unique dataframe for EU Total
EU.tot.hold <- data.frame('emi'=c(EU.tot$emi.tot, EU.tot$emi.tot),
                          'unc.min'= c(EU.tot$unc.min, EU.tot.corr$unc.min),
                          'unc.max'= c(EU.tot$unc.max, EU.tot.corr$unc.max),
                          'CImin'=c(EU.tot$CImin, EU.tot.corr$CImin),
                          'CImax' = c(EU.tot$CImax, EU.tot.corr$CImax),
                          'country' = 'EU28', 'group'= c('EU_as_whole', 'EU_by_country') )

#---------------------------------------------------------
# now generate EU.corr by category

# if(now_run=='CO2' & b.cat == 'Margarita'){ #original
  if(b.cat == 'Margarita' | b.cat == 'EDGAR'){ #original
  sss <- with (ss, data.frame('processes'= processes, 'emi'=emi/1000, 'unc.min'=unc.min,
                              'unc.max'=unc.max, 'ipcc06'=ipcc06, 'ipccX'=ipccX, 'iFlag'=iFlag,
                              'xFlag'=FALSE) )
}else{
  sss <- with (ss, data.frame('processes'= ipcc06, 'emi'=emi/1000, 'unc.min'=unc.min,
                              'unc.max'=unc.max, 'ipcc06'=ipcc06, 'ipccX'=ipccX, 'iFlag'=iFlag,
                              'xFlag'=FALSE) )
}

#sss <- with (ss, data.frame('processes'= processes, 'emi'=emi/1000, 'unc.min'=unc.min,
#                            'unc.max'=unc.max, 'ipcc06'=ipcc06, 'ipccX'=ipccX, 'iFlag'=iFlag,
#                             'xFlag'=FALSE) )

write.csv(sss, file=paste0(out.dir,'EU28_corr.csv' ))

EU_corr_cat <- f.cat_for_EU28(sss, FALSE)

 # prepare for plotting
  
if (now_run =='CO2' ) { 
  ymin <- 3200; ymax <- 3700
} else {
    ymin <-0; ymax <- NA
  }

 EU28.whole.cat <- do.call('rbind', g1.EU28) 
 EU28.corr.cat  <- do.call('rbind', EU_corr_cat) 
 
 EU28.whole.cat <- rownames_to_column(EU28.whole.cat, var="category") #%>% head  # that converts row names to an explicit variable
 EU28.corr.cat <- rownames_to_column(EU28.corr.cat, var="category")
 # names(EU28.corr) <- c('category','tot.subcat','asym.min.perc','asym.max.perc','asym.unc.min','asym.unc.max','country')
 EU28.corr.cat$cat <- rep('EU_by_country', dim(EU28.corr.cat)[1])
 EU28.whole.cat$cat <- rep('EU_as_whole', dim(EU28.whole.cat)[1])
 aa <- melt(merge(EU28.whole.cat, EU28.corr.cat, by= intersect(names(EU28.whole.cat), names(EU28.corr.cat)),all=T), 
            id.vars=c('category', 'tot.subcat', 'asym.min.perc', 'asym.max.perc', 'asym.unc.min','asym.unc.max','cat') )
#            id.vars = 'cat') 
 
 p <- 
   ggplot(data=aa, aes(x=category,y=tot.subcat, group=cat))+ 
   geom_pointrange(aes(ymin=tot.subcat*(1-abs(asym.min.perc)),# asym.unc.min/1000, 
                       ymax= tot.subcat*(1+asym.max.perc),color=cat), #asym.unc.max/1000 , color=cat)
                   position=position_dodge(width=0.6), size=1)      +
   theme(legend.position = 'bottom',
         legend.title = element_blank(),
         axis.title.x = element_blank(), axis.text.x=element_text(angle=90, hjust=1, vjust=0.5),
         text=element_text(size=18))+
   ylab( paste0(now_run,' emission (Tg)' ))+
   ggtitle(paste0(now_run, ' emission EU28 - ', sYear))

 w <-ggplot(data=EU.tot.hold, aes(x=country,y=emi))+
   geom_pointrange(aes(ymin=CImin,ymax=CImax,color=group), 
                   position=position_dodge(width=0.6), size=1) +
   ylim(ymin,ymax)+   xlab('') +
   theme(axis.title.y=element_blank(), text = element_text(size = 16),plot.title = element_text(size = 14, face = "bold"))+
   theme(legend.position = "none")
 
 
 pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.,2) )#, heights = 3)
 
 ggsave(filename=paste0(fig.dir, now_run, '_EU28_4_different_aggregation.png'),
               plot = pga ,dpi=150,type='cairo')
 
 
 #     id.vars=c('category', 'tot.subcat', 'asym.min.perc', 'asym.max.perc', 'cat') )
 
# # EU28.uncorr <- f.aggregate.EU28(g3, TRUE ) # TRUE = uncorrelated
# 
# # produce EU total as if EU was one country and use the median country uncertainty for each sector
#  EU28.one.entry.cat <- g3 %>% group_by(cat) %>% summarise(emi.tot = sum(tot.subcat, na.rm=T),
#                                                          unc.min <- median(asym.min.perc, na.rm=T),
#                                                          unc.max <- median(asym.max.perc, na.rm=T))
# 
# names(EU28.one.entry.cat) <- c('category','emission','unc.min.perc','unc.max.perc')
# 
# EU28.whole <- EU28.one.entry.cat %>% 
#               summarise('emission'= sum(emission, na.rm=T), 
#                         'unc.min' <- f.aggregate_subcategory.tot(emission, unc.min.perc, T),
#                         'unc.max' <- f.aggregate_subcategory.tot(emission, unc.max.perc, T)) %>% 'colnames<-'(names(EU28.one.entry.cat)[2:4])
# 
# EU28.one.entry.tot <- with(EU28.whole,data.frame( 'category'='EU28','emission'= emission, 'unc.min.perc'=unc.min.perc,'unc.max.perc'=unc.max.perc))
# 
# EU28.one.entry <- merge(EU28.one.entry.cat,EU28.one.entry.tot,all=T)
# #*******************************************************************************
# 
# EU.tot.corr   <- f.EU.total(g3, FALSE)
# EU.tot.uncorr <- f.EU.total(g3, TRUE)
# 
# EU.tot <- rbind(EU.tot.corr,EU.tot.uncorr)
# EU.tot$group <- c('corr','uncorr')
# EU.tot$country <- c('EU28', 'EU28')

# plotting
# EU28.corr$group='correlated' ; EU28.uncorr$group="uncorrelated"; 
# EU28.one.entry.cat$group<-'EU_as_whole'; 
# EU28.one.entry.cat <- data.frame(EU28.one.entry.cat)
# EU28.one.entry.cat$min <- EU28.one.entry.cat[,2]*(1-abs(EU28.one.entry.cat[,3]))
# EU28.one.entry.cat$max <- EU28.one.entry.cat[,2]*(1+abs(EU28.one.entry.cat[,4]))
# bb <-  rbind(EU28.corr, EU28.uncorr)
# bb$unc.emi.cat.min <- NULL
# bb$unc.emi.cat.max <- NULL
# bb$country <- NULL
# names(bb) <- c('category','emission', 'min','max','group')
# bb$max[9]  <- bb$emission[9]*bb$max[8]/bb$emission[8]
# bb$max[18] <- bb$emission[18]*bb$max[17]/bb$emission[17]
# 
# EU28.one.entry.cat$unc.min.perc <- NULL
# EU28.one.entry.cat$unc.max.perc <- NULL
# 
# bb <-rbind(bb,EU28.one.entry.cat)
# 
# p <- ggplot(data=bb, aes(x=category,y=emission, group=group))+
#   geom_pointrange(aes(ymin=min,ymax=max,color=group), position=position_dodge(width=0.6), size=1)+
#   theme(legend.position = 'bottom',
#         legend.title = element_blank(),
#         axis.title.x = element_blank(),
#         text=element_text(size=18))+
#   ggtitle('CH4 emission EU28 - 2012')
# 
# 
# w <-ggplot(data=EU.tot, aes(x=country,y=emi.tot.cat))+
#   geom_pointrange(aes(ymin=CImin,ymax=CImax,color=group), position=position_dodge(width=0.6), size=1) +
#   ylim(0,NA)+   xlab('') +
#   theme(axis.title.y=element_blank(), text = element_text(size = 16),plot.title = element_text(size = 14, face = "bold"))+
#   theme(legend.position = "none")
# 
# 
# pga <- grid.arrange(p, w, ncol = 2, nrow = 1, widths = c(8.,2) )#, heights = 3)
# 
# ggsave(filename=paste0(fig.dir, 'CH4_EU_28.png'),
#        plot = pga ,dpi=150,type='cairo')
# 
# rpivotTable(emi.EU28)
# 
# tmp<-data.frame(g3)

write.csv(tmp, file='D:\\work\\GhG_move\\VERIFY\\EDGAR\\roxana\\EU28_category_countries.csv')