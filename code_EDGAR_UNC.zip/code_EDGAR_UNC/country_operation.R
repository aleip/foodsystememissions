

f.country_operation <- function(){
  
  # country_info generated from init
  
  unique.group <- unique(country.info$group_ID)
  
  country.group <- vector(mode='list')
  
  for (g in unique.group){
    idx <- which(country.info$group_ID==g)
    gg  <- as.character(g)
    country.group[[gg]] <- country.info[idx,1]
    
  }
  
  
}


f.get_country_code <- function(country_group){
  country_code <- NULL
  for (c in country_group){
    idx <- which(country.info$country == c )
    country_code <- c(country_code,country.info$ISO3[idx])
  }
  if(!length(country_code)==length(country_group)){
    cat('error in function f.get_country_code','\n')
  }
  country_code <- country.info$ISO3[country_code]
  return(as.character(country_code))
}


EU28 <-c('Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czech Republic',
        'Denmark', 'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary',
        'Ireland', 'Italy', 'Latvia', 'Lithuania', 'Luxembourg','Malta', 'Netherlands',
        'Poland', 'Portugal', 'Romania', 'Slovakia', 'Slovenia', 'Spain', 'Sweden', 'United Kingdom')

EU28.cc <- f.get_country_code(EU28)

EU28_NS <- c(EU28, 'Norway', 'Switzerland')

EU28_NS.cc <- f.get_country_code(EU28_NS)

country.ind <- country.info[country.info$ind=='I',]
country.ind <- rbind(country.ind, country.info[country.info$ISO3=='CHN',])
country.ind <- rbind(country.ind, country.info[country.info$ISO3=='IDN',])

annex <- read.csv(file=paste0('E:\\D_extra\\work\\GhG_move\\VERIFY\\EDGAR\\data\\Annex_classification.csv'))




