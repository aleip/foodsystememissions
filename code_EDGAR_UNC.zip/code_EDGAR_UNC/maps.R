library(maps)
library(ggplot2)
world_map <- map_data("world")
library(viridis)


# <- subset(world_map, world_map$region=="Switzerland")
#Malta <- subset(world_map, world_map$region=="Malta")

#Switzerland
#Malta
p <- ggplot() + coord_fixed() +
  xlab("") + ylab("")

#Add map to base plot
base_world_messy <- p + geom_polygon(data=world_map, aes(x=long, y=lat, group=group), 
                                     colour="light green", fill="light green")

base_world_messy


cleanup <- 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_rect(fill = 'white', colour = 'white'), 
        axis.line = element_line(colour = "white"), legend.position="none",
        axis.ticks=element_blank(), axis.text.x=element_blank(),
        axis.text.y=element_blank())

base_world <- base_world_messy + cleanup



# starts here----

library(rgeos); library(countrycode)
library(rworldmap)

# get world map
wmap <- getMap(resolution="high")

# get centroids
centroids <- gCentroid(wmap, byid=TRUE)

# get a data.frame with centroids ----
df <- as.data.frame(centroids)
names(df)<- c( 'long', 'lat')
df$country <- rownames(df)
df$ISO <- countrycode(df$country, 'country.name','iso3c')
#  uu2 <- data.frame(u2); names(uu2) =c('ISO', 'emi.tot')
g2.EU.tot <- na.omit(unique(g2.EU.tot))
ux <- g2.EU.tot %>% group_by(country, L1) %>% summarise(unc.max = f.aggregate_subcategory.tot(emi,rel.unc.max, FALSE),
                                                        unc.min = f.aggregate_subcategory.tot(emi,rel.unc.min, FALSE),
                                                        emi = sum(emi, na.rm=T))

#  gh <- na.omit(unique(gh))
ux<- data.frame(ux); ux <- na.omit(unique(ux))

u1 <- ux %>% group_by(country) %>% summarise(comb_unc_max = f.tot_unc(emi,unc.max, T),
                                             comb_unc_min = f.tot_unc(emi,unc.min, T),
                                             emi.tot = sum(emi, na.rm=T)) 
u1 <- data.frame(u1); u1 <- na.omit(unique(u1))
u1$perc <- round(100*(u1$comb_unc_max+u1$comb_unc_min)/2,1)
u1$comb_unc_max <- NULL; u1$comb_unc_min <- NULL    
names(u1) <- c('ISO','emi.tot', 'unc' )

dfp <- merge(df,u1, by='ISO')
pop <- read.csv(file ='D:\\work\\GhG_move\\VERIFY\\EDGAR\\data\\population.csv' )
names(pop) <- c('ISO', 'pop2015')
dfp <- merge(dfp,pop,by='ISO' )


#dfp <- merge(dfp,u1, by='ISO')


map_data <- 
  base_world +
  geom_point(data=dfp, 
             aes(x=long, y=lat, size=perc, fill=emi.tot), colour="Deep Pink", 
             pch=21, alpha=I(0.7))+
  scale_fill_viridis(discrete = F, name="Emission (kT)") +
  theme(legend.position="bottom" ) 
  

map_data

dfp$emipercapita <- dfp$emi.tot/dfp$pop2015
d1 <- dfp %>% dplyr::arrange(emipercapita)
d2 <- d1[-(1:69),]
d2 <- d1[-(1:90),]
#require(plotrix)
#par(ps=4)
#radial.plot(d2$emi.tot, labels=d2$country,rp.type="p",
#            main="Emission Total", line.col="blue")

df <- d2
# ur <- c('0-5%', '5-10%', '10-15%', '15-30%','30-100%')
df$unc <- cut(df$perc, breaks=c(5, 10, 20, 30, 50, 75,100), right = FALSE)#rep(ur,length(df$country)/length(ur))

colors <- RColorBrewer::brewer.pal(length(unique(df$unc)), "Spectral")
unc <- unique(df$unc)

df$colors <- df$unc

for(i in 1:length(unc)){
  idx <- df$colors %in% unc[i]   
  df$colors[idx] <- colors[i]
}

# Get incremental angle value
n <- nrow(df) + 20
dtheta <- 2*pi / n
theta <- pi / 2

# Initialise
x <- c()
y <- c()
xend <- c()
yend <- c()

# This is for the white - circle in the middle
adjust <- 25
# Calculate x and y coordinates
for(ctr in 1:nrow(df)){
  
  a <- df$emipercapita[ctr] + adjust
  
  x[ctr] <- adjust * cos(theta)
  y[ctr] <- adjust * sin(theta)
  
  xend[ctr] <- a * cos(theta)
  yend[ctr] <- a * sin(theta)
  
  theta <- theta + dtheta
}


plot.df <- data.frame(x, y, xend, yend, unc = df$unc)

p <- plot_ly(plot.df, 
             x = ~x, y = ~y,
             xend = ~xend, yend = ~yend,
             color = ~unc) %>% 
  add_segments(line = list(width = 5))

# Add layout options, shapes etc
p <- layout(p,
            xaxis = list(domain = c(0, 0.5), title = "", showgrid = F, zeroline = F, showticklabels = F),
            yaxis = list(title = "", showgrid = F, zeroline = F, showticklabels = F),
            shapes = list(
              list(type = "circle",
                   x0 = (-5 - adjust),
                   y0 = (-5 - adjust),
                   x1 = (5 + adjust),
                   y1 = (5 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2)),
              
              list(type = "circle",
                   x0 = (-15 - adjust),
                   y0 = (-15 - adjust),
                   x1 = (15 + adjust),
                   y1 = (15 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2)),
              
              list(type = "circle",
                   x0 = (-25 - adjust),
                   y0 = (-25 - adjust),
                   x1 = (25 + adjust),
                   y1 = (25 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2)),
              
              list(type = "circle",
                   x0 = (-35 - adjust),
                   y0 = (-35 - adjust),
                   x1 = (35 + adjust),
                   y1 = (35 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2))),
            
            legend = list(x = 0.15, y = 0.47, font = list(size = 10)))

# Add annotations for country names
theta <- pi / 2
textangle <- 90

for(ctr in 1:nrow(df)){
  
  a <- df$emipercapita[ctr] + adjust
  a <- a + a/12
  
  x <- a * cos(theta)
  y <- a * sin(theta)
  
  if(ctr < 41) {xanchor <- "right"; yanchor <- "bottom"}
  if(ctr > 41 & ctr < 74) {xanchor <- "right"; yanchor <- "top"}
  if(ctr > 74) {xanchor <- "left"; yanchor <- "top"}
  
  p$x$layout$annotations[[ctr]] <- list(x = x, y = y, showarrow = F,
                                        text = ifelse(ctr %in% seq(1,nrow(df),3),
                                                        paste0(df$country[ctr], 
                                                      ' (', as.character(round(df$emipercapita[ctr],1)), ')'),
                                                      paste0(df$country[ctr]) ),
                                        textangle = textangle,
                                        xanchor = xanchor,
                                        yanchor = yanchor,
                                        font = list(family = "serif", size = 10),
                                        borderpad = 0,
                                        borderwidth = 0)
  theta <- theta + dtheta
  textangle <- textangle - (180 / pi * dtheta)
  
  if(textangle < -90) textangle <- 90
}

# Titles and some other details
p$x$layout$annotations[[121]] <- list(xref = "paper", yref = "paper",
                                      x = 0, y = 1, showarrow = F,
                                      xanxhor = "left", yanchor = "top",
                                      align = "left",
                                      text = "<em>EDGAR V5 Total GHG emissions </em><br><sup>(metric tons per capita)</sup>",
                                      font = list(size = 25, color = "black"))

p$x$layout$annotations[[122]] <- list(xref = "paper", yref = "paper",
                                      x = 0, y = 0.9, showarrow = F,
                                      xanxhor = "left", yanchor = "top",
                                      align = "left",
                                      text = "CO2 eq emissions from human activities 2015",
                                      font = list(size = 18, color = "#808080"))

p$x$layout$annotations[[123]] <- list(xref = "paper", yref = "paper",
                                      x = 0.15, y = 0.60, showarrow = F,
                                      xanxhor = "left", yanchor = "top",
                                      align = "left",
                                      text = "<b>Uncertainty <br> ranges (%)</b> ",
                                      font = list(size = 15, color = "black"))
p



#---- original ----

# inspired by 
# https://s-media-cache-ak0.pinimg.com/736x/22/1a/d0/221ad079e362ba13969b1bef30b6a5f2.jpg

library(plotly)

# read in data
df <- read.csv("https://cdn.rawgit.com/plotly/datasets/master/Emissions%20Data.csv", stringsAsFactors = F)

# Show only 2011 values
df <- subset(df, Year == "2011")

# Arrange in increasing order of emissions
df <- df %>% dplyr::arrange(Emission)
df <- df[-(1:50),]

#  Add colors
colors <- RColorBrewer::brewer.pal(length(unique(df$Continent)), "Spectral")
continent <- unique(df$Continent)

df$colors <- df$Continent

for(i in 1:length(continent)){
  idx <- df$colors %in% continent[i]   
  df$colors[idx] <- colors[i]
}

# Get incremental angle value
n <- nrow(df) + 20
dtheta <- 2*pi / n
theta <- pi / 2

# Initialise
x <- c()
y <- c()
xend <- c()
yend <- c()

# This is for the white - circle in the middle
adjust <- 20

# Calculate x and y coordinates
for(ctr in 1:nrow(df)){
  
  a <- df$Emission[ctr] + adjust
  
  x[ctr] <- adjust * cos(theta)
  y[ctr] <- adjust * sin(theta)
  
  xend[ctr] <- a * cos(theta)
  yend[ctr] <- a * sin(theta)
  
  theta <- theta + dtheta
}


plot.df <- data.frame(x, y, xend, yend, continent = df$Continent)

p <- plot_ly(plot.df, 
             x = ~x, y = ~y,
             xend = ~xend, yend = ~yend,
             color = ~continent) %>% 
  add_segments(line = list(width = 5))

# Add layout options, shapes etc
p <- layout(p,
            xaxis = list(domain = c(0, 0.5), title = "", showgrid = F, zeroline = F, showticklabels = F),
            yaxis = list(title = "", showgrid = F, zeroline = F, showticklabels = F),
            shapes = list(
              list(type = "circle",
                   x0 = (-5 - adjust),
                   y0 = (-5 - adjust),
                   x1 = (5 + adjust),
                   y1 = (5 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2)),
              
              list(type = "circle",
                   x0 = (-15 - adjust),
                   y0 = (-15 - adjust),
                   x1 = (15 + adjust),
                   y1 = (15 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2)),
              
              list(type = "circle",
                   x0 = (-25 - adjust),
                   y0 = (-25 - adjust),
                   x1 = (25 + adjust),
                   y1 = (25 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2)),
              
              list(type = "circle",
                   x0 = (-35 - adjust),
                   y0 = (-35 - adjust),
                   x1 = (35 + adjust),
                   y1 = (35 + adjust),
                   fillcolor = "transparent",
                   line = list(color = "white", width = 2))),
            
            legend = list(x = 0.20, y = 0.47, font = list(size = 18)))

# Add annotations for country names
theta <- pi / 2
textangle <- 90

for(ctr in 1:nrow(df)){
  
  a <- df$Emission[ctr] + adjust
  a <- a + a/12
  
  x <- a * cos(theta)
  y <- a * sin(theta)
  
  if(ctr < 51) {xanchor <- "right"; yanchor <- "middle"}
  if(ctr > 51 & ctr < 84) {xanchor <- "right"; yanchor <- "middle"}
  if(ctr > 84) {xanchor <- "left"; yanchor <- "middle"}
  
  p$x$layout$annotations[[ctr]] <- list(x = x, y = y, showarrow = F,
                                        text = paste0(df$Country[ctr]),
                                        textangle = textangle,
                                        xanchor = xanchor,
                                        yanchor = yanchor,
                                        font = list(family = "serif", size = 9),
                                        borderpad = 0,
                                        borderwidth = 0)
  theta <- theta + dtheta
  textangle <- textangle - (180 / pi * dtheta)
  
  if(textangle < -90) textangle <- 90
}

# Titles and some other details
p$x$layout$annotations[[148]] <- list(xref = "paper", yref = "paper",
                                      x = 0, y = 1, showarrow = F,
                                      xanxhor = "left", yanchor = "top",
                                      align = "left",
                                      text = "<em>Carbon dioxide emissions</em><br><sup>(metric tons per capita)</sup>",
                                      font = list(size = 25, color = "black"))

p$x$layout$annotations[[149]] <- list(xref = "paper", yref = "paper",
                                      x = 0, y = 0.9, showarrow = F,
                                      xanxhor = "left", yanchor = "top",
                                      align = "left",
                                      text = "Emissions from burning of solid, liquid and <br>gas fuels and the manufacture of cement.",
                                      font = list(size = 18, color = "#808080"))

p$x$layout$annotations[[150]] <- list(xref = "paper", yref = "paper",
                                      x = 0.20, y = 0.60, showarrow = F,
                                      xanxhor = "left", yanchor = "top",
                                      align = "left",
                                      text = "<b>Annual CO<sub>2</sub> emissions</b><br><b>for 147 countries.</b>",
                                      font = list(size = 15, color = "black"))
p


# library('sf')
# ggplot(data = world) +
#   geom_sf(aes(fill = pop_est)) +
#   scale_fill_viridis_c(option = "plasma", trans = "sqrt")
# 
# ggplot(data = world) + 
#   geom_sf(color = "black", fill = "lightgreen")


