
f.extract_country_var <- function(g2.EU.tot, sCountry) {
  
  if (!sCountry=='world'){
    tmp1 <- g2.EU.tot[g2.EU.tot$country==sCountry,] # extract country
    tmp <- na.omit(unique(tmp1))
  } else {
    
    tmp <- na.omit(unique(g2.EU.tot))
  }
    GHG.tmp <- tmp %>% group_by(sector) %>% 
      summarise(emi.tot.sector = sum(emi, narm=T), 
                comb_unc_max = f.tot_unc(emi, rel.unc.max, T ),
                comb_unc_min = f.tot_unc(emi, rel.unc.min, T ) )# 
    ## finally aggreagte all together (since all sectors and gases are uncorrelated, the latter two calculatons could have been merged)
    GHG.tot <- GHG.tmp %>% summarise(emi.tot = sum(emi.tot.sector, na.rm=T), 
                                     comb_unc_max = f.aggregate_subcategory.tot(emi.tot.sector,comb_unc_max, TRUE),
                                     comb_unc_min = f.aggregate_subcategory.tot(emi.tot.sector,comb_unc_min, TRUE ))
    CI.range <-  f.asymmetric_unc(GHG.tot[3],GHG.tot[2],GHG.tot[1])
    minCI <- CI.range[1]
    maxCI <- CI.range[2]
    GHG.tot$CImin <- EU28.GHG.tot$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
    GHG.tot$CImax <- EU28.GHG.tot$emi.tot*(1+ maxCI)
  
  return(GHG.tot)
}

f.prepare_data <- function(g1, sAgg)
{
  if (sAgg == 'magnitude'){
    hold <- reshape2::melt(g1, id.vars=c('country','tot.subcat','asym.unc.min','asym.unc.max'))
    #  hold <- do.call('rbind', g1)
    #  hold$rel.unc.min <- NULL ;     hold$rel.unc.max   <- NULL
    #    hold$asym.min.perc <- NULL ; hold$asym.min.perc <- NULL 
    hold$value <- NULL; hold$variable <- NULL
    names(hold) <- c('country','emi','asym.unc.min','asym.unc.max','sector')
  } else if (sAgg == 'perc'){
    hold <- reshape2::melt(g1, id.vars=c('country','tot.subcat','rel.unc.min','rel.unc.max'))
    hold$value <- NULL; hold$variable <- NULL
    names(hold) <- c('country','emi','rel.unc.min','rel.unc.max','sector')
  }
  
  hold <- unique(hold)
  return(hold)
  
}

# f.prepare_data_EU <- function(g1)
# {
#   hold <- melt(g1, id.vars=c('country','tot.subcat','rel.unc.min','rel.unc.max'))
#   #  hold <- do.call('rbind', g1)
#   #  hold$rel.unc.min <- NULL ;     hold$rel.unc.max   <- NULL
#   #    hold$asym.min.perc <- NULL ; hold$asym.min.perc <- NULL 
#   hold$value <- NULL; hold$variable <- NULL
#   names(hold) <- c('country','emi','rel.unc.min','rel.unc.max','sector')
#   return(hold)
#   
# }
f.tot_unc <- function(E, U, bNorm) # combine unc from N2O, CO2, CH4
{
  # browser()
  
  if (any(is.na(U)) & !all(is.na(U))) {
    if (is.na(U[1])) {U[1] <- 0; E[1]=0}
    if (is.na(U[2])) {U[2] <- 0; E[2]=0}
    if (is.na(U[3])) {U[3] <- 0; E[3]=0}
  } 
  if (any(is.na(E)) & !all(is.na(E))) {
    if (is.na(E[1])) {E[1] <- 0; U[1]=0}
    if (is.na(E[2])) {U[2] <- 0; E[2]=0}
    if (is.na(E[3])) {U[3] <- 0; E[3]=0}
  } 
  if (length(E)==2){ 
    E[3] <- 0; U[3] <- 0
    
  } else if (length(E)==1){
    E[2] <- 0; U[2] <- 0
    E[3] <- 0; U[3] <- 0
  }
  #  sigma_tot <- sqrt(U[1]^2 *(25*U[2])^2+ (298*U[3])^2)#/(E[1]+(25*E[2])+(298*E[3]))
  # sigma_tot <- sqrt(U[1]^2 +U[2]^2+ U[3]^2)/(E[1]+E[2]+E[3])
  
  
  if (bNorm){ # case of normal distribution (opassed the rel.unc in %)
    sigma_tot <- sqrt( ((U[1]*E[1]))^2 +((U[2]*E[2]))^2+ ((U[3]*E[3]))^2 ) /(E[1]+E[2]+E[3]) # gives the percentage
  } else { # passed the asym.unc as absolute value
    sigma_tot <- sqrt( ((U[1]-E[1]))^2 +((U[2]-E[2]))^2+ ((U[3]-E[3]))^2 ) /(E[1]+E[2]+E[3]) # gives the percentage
  }
  return(sigma_tot)
}
#-------------------------------------------------------
f.plot_all_countries <- function(g2.tot){
  g2.EU.tot <- na.omit(unique(g2.EU.tot))
  ux <- g2.EU.tot %>% group_by(country, L1) %>% summarise(unc.max = f.aggregate_subcategory.tot(emi,rel.unc.max, FALSE),
                                                           unc.min = f.aggregate_subcategory.tot(emi,rel.unc.min, FALSE),
                                                           emi = sum(emi, na.rm=T))
  
#  gh <- na.omit(unique(gh))
  ux<- data.frame(ux); ux <- na.omit(unique(ux))
  
  u1 <- ux %>% group_by(country) %>% summarise(comb_unc_max = f.tot_unc(emi,unc.max, T),
                                            comb_unc_min = f.tot_unc(emi,unc.min, T),
                                                 emi.tot = sum(emi, na.rm=T)) 
  u1 <- data.frame(u1); u1 <- na.omit(unique(u1))
  u1$perc <- paste(as.character(round(100*(u1$comb_unc_max+u1$comb_unc_min)/2,1)), '%')
#  tot_country <- uf %>% group_by(country) %>% summarise(emi.tot = sum(emi.tot, na.rm=T))
  
#  ux$sector <- NULL
  gh <- u1[order(-u1$emi.tot),] 

  ggplot(data=ux[ux$country %in% gh$country[1:25],])+
  geom_bar( aes(x=country ,y=emi,  fill=L1),position='stack', stat='identity') +
  geom_errorbar(data=u1[u1$country %in% gh$country[1:25],], aes(x=country , ymin=emi.tot*(1-comb_unc_min), ymax=emi.tot*(1+comb_unc_max)))  +
    geom_text(data=u1[u1$country %in% gh$country[1:25],], aes(label= perc, x= country,  y=4.e+06, color=emi.tot), label.size = 0.35, angle=90 ) + 
    scale_colour_continuous(guide = FALSE) +
   theme_hc() + ylim(0, 4e+6)+
   theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5), legend.title = element_blank(), axis.title.x=element_blank())+
   ylab( paste0(' EDGAR GHG emission 2015 (kTonnes/year)' ) )+ 
   #   plot.margin = unit(rep(-2,4), "cm")) +    # This remove unnecessary margin around plot
   # coord_polar(start = 0)
   theme(legend.position="bottom")
  
}

f.EU28_calc <- function (g2.EU28, sTier){
  EU28.GHG <- unique(g2.EU28)
#  write.csv(EU28.GHG, file=paste0(out.dir, 'GHG\\EU28_GHG_',sYear,'_',sTier,'_sector_country.csv'))
  if (sTier == 'Tier1'){
    
    # first: for each sector calculate the emission and uncertainty by GHG gas (three entry for each sector) (sectors are correalted)
    
    
    EU28.GHG.sector <- EU28.GHG %>% group_by(sector, L1) %>% 
      summarise(unc.max = f.aggregate_subcategory.tot(emi,rel.unc.max, FALSE),
                unc.min = f.aggregate_subcategory.tot(emi,rel.unc.min, FALSE),
                emi = sum(emi, na.rm=T))
  } else {
    EU28.GHG.sector <- EU28.GHG %>% group_by(sector, L1) %>% 
      summarise(unc.max = f.aggregate_subcategory.tot(emi,rel.unc.max, TRUE),
                unc.min = f.aggregate_subcategory.tot(emi,rel.unc.min, TRUE),
                emi = sum(emi, na.rm=T))
  }
  EU28.GHG.sector <- data.frame(EU28.GHG.sector)
  CI.range <-  apply(EU28.GHG.sector,1, function(x){f.asymmetric_unc(x[4],x[3],x[5])})
  #minCI <- CI.range[1]
  #maxCI <- CI.range[2]
  EU28.GHG.sector$asym.unc.min <- EU28.GHG.sector$emi*(1- abs(CI.range[1,])) #CI.range[1] should be negative for asymmetric distribution
  EU28.GHG.sector$asym.unc.max <- EU28.GHG.sector$emi*(1+ CI.range[2,])
#  write.csv(EU28.GHG.sector, file=paste0(out.dir, 'GHG\\EU28_GHG_',sYear,'_sector.csv'))
  
  # then, calculate the EU28 as a whole: aggregate the sectors relative to different gases (uncorrelated). 
  ## aggregate gas for each sector (uncorrelated)
  EU28.GHG.tmp <- EU28.GHG.sector %>% group_by(sector) %>% 
    summarise(emi.tot.sector = sum(emi, narm=T), 
              comb_unc_max = f.tot_unc(emi, unc.max, T ),
              comb_unc_min = f.tot_unc(emi, unc.min, T ) )# 
  ## finally aggreagte all together (since all sectors and gases are uncorrelated, the latter two calculatons could have been merged)
  EU28.GHG.tot <- EU28.GHG.tmp %>% summarise(emi.tot = sum(emi.tot.sector, na.rm=T), 
                                             comb_unc_max = f.aggregate_subcategory.tot(emi.tot.sector,comb_unc_max, TRUE),
                                             comb_unc_min = f.aggregate_subcategory.tot(emi.tot.sector,comb_unc_min, TRUE ))
  CI.range <-  f.asymmetric_unc(EU28.GHG.tot[3],EU28.GHG.tot[2],EU28.GHG.tot[1])
  minCI <- CI.range[1]
  maxCI <- CI.range[2]
  EU28.GHG.tot$CImin <- EU28.GHG.tot$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
  EU28.GHG.tot$CImax <- EU28.GHG.tot$emi.tot*(1+ maxCI)
  return(list(EU28.GHG.tot,EU28.GHG.sector))
}




# ## principal component analysis of variance ----
# unc.n <- EU28.GHG.sector %>% mutate(sigma2 = (emi*unc.max)^2)
# 
# unc.n$unc.max <- NULL; unc.n$unc.min <- NULL; unc.n$asym.unc.min <- NULL;unc.n$asym.unc.max <- NULL;unc.n$tier <- NULL; unc.n$emi<-NULL
# unc.n.PCA <- dcast(unc.n, sector~L1, fill=NA)
# 
# rownames(unc.n.PCA) <- unc.n.PCA$sector
# unc.n.PCA$sector <- NULL
# unc.n.PCA <- t(unc.n.PCA)
# 
# unc.n.PCA <- data.frame(unc.n.PCA)
# pca <- prcomp(na.omit(unc.n.PCA), scale=T) 
# 
# pca$x %>% 
#   as.data.frame %>%
#   
#   ggplot(aes(x=PC1,y=PC2)) + geom_point(aes(color=continent),size=4) +
#   theme_bw(base_size=32) + 
#   labs(x=paste0("PC1: ",round(var_explained[1]*100,1),"%"),
#        y=paste0("PC2: ",round(var_explained[2]*100,1),"%")) +
#   theme(legend.position="top")
# 
# # https://www.analyticsvidhya.com/blog/2016/03/practical-guide-principal-component-analysis-python/
# biplot(pca, scale = 0)
# std_dev <- pca$sdev
# pr_var <- std_dev^2
# prop_varex <- pr_var/sum(pr_var)
# plot(prop_varex, xlab = "Principal Component",
#      ylab = "Proportion of Variance Explained",
#      type = "b")
# plot(cumsum(prop_varex), xlab = "Principal Component",
#      ylab = "Cumulative Proportion of Variance Explained",
#      type = "b")
# 
