library(compareDF)
library(dataCompareR)
library(Ipaper)

ad.dir <- 'D:\\work\\GhG_move\\VERIFY\\EDGAR\\compare_AD\\'

AD.v5   <- read.csv(file=paste0(ad.dir, 'AD_v5.csv'))
AD.v432 <- read.csv(file=paste0(ad.dir, 'AD_v432.csv'))
country_group <- read.csv(file=paste0(ad.dir, 'EDGAR_country.csv'), header=T, sep=',', stringsAsFactors = F)

a <- compare_df(AD.v5, AD.v432, group_col='Country')
print(a$html_output)

#idx.out <- which(AD.v432$Process.code %in% AD.v5$Process.code)
#idx.in  <- which(AD.v5$Process.code %in% AD.v432$Process.code)
#idx.in1 <- which(AD.v432$Process.code %in% AD.v5$Process.cod)

#length(idx.out)+dim(AD.v432)[1]

mergeAD <- merge(AD.v432, AD.v5, by=c('Country','Process.code')) #only common AD

write.csv(mergeAD, file=paste0(ad.dir, 'merge.AD.csv'))
year <- as.character(seq(2000, 2012))
compAD <- data.frame(matrix(NA, nrow = nrow(mergeAD), ncol = length(year)))

for (i in 1: 13) {
  k <- grep(year[i],names(mergeAD))  
  compAD[,i] <- abs(mergeAD[,k[1]] - mergeAD[,k[2]])/mergeAD[,k[1]]
}

is.na(compAD)<-sapply(compAD, is.infinite)
compAD[is.na(compAD)]<-NA

names(compAD) <- year
compAD$Country <- mergeAD$Country
# compAD$Process.code <- mergeAD$Process.code
compAD$process <- substr(mergeAD$Process.code,1,3)


aa <- melt(compAD, id.vars=c('process','Country'))
names(aa) <- c( 'process', 'Country', 'year','diff')
names(country_group) <- c('Country','country_name','group','ind','group_ID','group_name')


aaa <- merge(aa,country_group, by='Country',all=T)


aa.y <- aaa[aaa$year=='2010' ,] #& aa$process=='ENE',]

aa.yy <- aaa[aaa$process=='ENE',]
# aa.y <- aa[aa$process=='ENE' & aa$Country=='RUS',]

# ylim1 = boxplot.stats(aa.y$diff)$stats[c(1, 5)]
aa.y$diff <- as.numeric(aa.y$diff)
aa.y %>% group_by(Country,process) %>% summarise(mean=mean(diff,na.rm=T), median=median(diff, na.rm=T)) %>%

  ggplot(.) + geom_point(aes(Country, mean))+ facet_wrap(process~., scale='free')


aa.yy %>% group_by(group_name,year) %>% summarise(mean=mean(diff,na.rm=T), median=median(diff, na.rm=T)) %>%
  ggplot(.) + geom_point(aes(group_name, median))+ facet_wrap(year~., scale='free')+
 ggtitle("v432 vs v5 median difference - sector ENE")


aaa$diff<-as.numeric(aaa$diff)
for (proc in unique(aaa$process)){
  p <- aaa[aaa$process==proc,] %>% group_by(year, group_name, process) %>% summarise(median=100*median(diff,na.rm=T) ) %>%  
    ggplot(.) + geom_point(aes(year,median, color=group_name, shape=group_name), size=2.5)+
    scale_shape_manual(values=seq(0,25))+ggtitle(paste0(proc, " - v432 vs v5 median difference")) +
    labs(color  = "group name", shape = "group name")+
    ylab('|ADv432-AD.v5|/ADv432 (%)') +  xlab('')    + #ylim(c(0,0.02)) +
    
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5),axis.title.x = element_blank(),
          text = element_text(size = 13), 
          plot.title = element_text(size = 14, face = "bold")) 
  
  ggsave(filename=paste0(paste0(ad.dir, 'figs\\'),proc, '_median_diff.png'), plot = p ,dpi=150,type='cairo')
  
}

# they are the same


#a <-ifelse((AD.T.v432[sapply(AD.T.v432,is.numeric)] >0 & !is.na(AD.T.v432[sapply(AD.T.v432,is.numeric)])), 
#          (AD.T.v5[sapply(AD.T.v5,is.numeric)] - AD.T.v432[sapply(AD.T.v432,is.numeric)])/AD.T.v432[sapply(AD.T.v432,is.numeric)],
#              NA)

# a <- (AD.T.v5[sapply(AD.T.v5,is.numeric)] - AD.T.v432[sapply(AD.T.v432,is.numeric)])/AD.T.v432[sapply(AD.T.v432,is.numeric)]
#            
# compAD <- cbind(a,AD.T.v5$Process.code, AD.T.v5$Country) 
# 
# names(compAD) <- c(as.character(seq(2000,2015)),'Process.code','Country')
# aa<- melt(compAD, id.vars=c('Process.code','Country'))
# names(aa) <- c( 'Process.code', 'Country', 'year','diff')
# 
# comp <- aa %>% group_by(year) %>% ggplot(.,aes(x=Country,diff)) + geom_boxplot(stat = "boxplot", na.rm = T) + facet_wrap(year~.)
