sUncCorr <-'UncCorr_' ; bAsymmetricUnc <- T
sUncCorr <-'UncNorm_';  bAsymmetricUnc <- F

unc.table <- loadRData (file=paste0(proc.dir,sUncCorr,'unc.table.Rdata'))

subset(unc.table, (country=='USA'& grepl('1B2',ipccX))) #copied in excel


a <- unc.table %>%   group_by(country) %>%  subset(country=='USA'& grepl('1B2', ipccX)) %>%  
  summarise(emi.cat.country  = sum(emi, na.rm=T),
            emi.unc.cat.country.min <- f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag) ),
            emi.unc.cat.country.max <- f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag)))

a <- as.numeric(a)
f.asymmetric_unc(a[3],a[4],a[2])


# case of 1b2 for USA
#ns <- 10000
x<-seq(0,20000,100)
# normal distribution from excel
sum_emi <- 7.77E+03
min_perc <- 0.253 # (25%)
max_perc <- 0.47  # (47%)

sd <- (sum_emi*(1+max_perc)-sum_emi*(1-min_perc))/2.

norm <- rnorm(ns, mean=sum_emi, sd=sd)
# normal distribution asymmetric

sum_emi <- 7.77E+03
min_perc <- 0.225 # (22.5%)
max_perc <- 0.54  # (54%)
sd <- (sum_emi*(1+max_perc)-sum_emi*(1-min_perc))/2.
param <- f.lognomal_parameters(sum_emi, sd)
lmean <- param[1] # <- log(edgar.mean^2 / sqrt(sd_edgar^2 + edgar.mean^2)) 
lsd  <- param[2] # sqrt(log(1 + (sd_edgar^2 / edgar.mean^2)))
ldist <- rlnorm(n=ns, meanlog = lmean, sdlog = lsd)

#x <- seq(0,20000,100)
#y <- dnorm(x,mean=sum_emi, sd=sd)
#plot(x,y, type='l')
plot(density(norm), xlim=c(-5000,20000), ylim=c(0,0.0002), lwd=1); 
par(new=T)
plot(density(ldist), xlim=c(-5000,20000), ylim=c(0,0.0002), col='blue')

f.lognomal_parameters <- function(mean, sd){
  lmean   <- log(mean^2 / sqrt(sd^2 + mean^2)) 
  lsd    <- sqrt(log(1 + (sd^2 / mean^2)))
  return(c(lmean,lsd))
}

ModifiedCox_efi <- function(x){ # based on bond et al paper
  n <- length(x)
  y <- log(x)
  y.m <- mean(y)
  y.sd <- sqrt(var(y))
  
  my.t <- qt(0.975, df = n-1) # 95% Confidence interval
  
  my.mean <- mean(x)
  # upper <- y.m + (y.sd/sqrt(n-1))*my.t   #   y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  #  lower <-  y.m - (y.sd/sqrt(n-1))*my.t 
  upper <- y.m + (y.sd)*my.t   #   y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  lower <-  y.m - (y.sd)*my.t 
  
  return(list(upper = exp(upper), mean = my.mean, lower = exp(lower)))
  
}