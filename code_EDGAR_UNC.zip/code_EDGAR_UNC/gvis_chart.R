

f.gvis_plot <- function(g1) {
  
 if(bCountryTot) {
   ens.df <- data.frame(g1)
   ens.df$tot.subcat.interval.1 <- ifelse(ens.df$tot.country>(ens.df$tot.country*ens.df$rel.unc.min), 
                                               ens.df$tot.country-(ens.df$tot.country*ens.df$rel.unc.min), 0)
   ens.df$tot.subcat.interval.2 <- ens.df$tot.country+(ens.df$tot.country*ens.df$rel.unc.max)
   ens.df$countryC<- countrycode(ens.df$country, 'iso3c','country.name')
   ens.df$countryC[which(is.na(ens.df$countryC))] <- ens.df$country[which(is.na(ens.df$countryC))] #fill NA with 3 letter codes
   
   
   # sort

     sorted_ens.df <- ens.df[order(ens.df$tot.country),] 
   
   sorted_ens.df <- sorted_ens.df[(lengths(sorted_ens.df)[1]-50):lengths(sorted_ens.df)[1],]
   
   s.df <-list()
   s.df[[1]] <- sorted_ens.df
   f.make_gvis_plot(s.df,1)
   
   
   
   }else{
   
 
  for (h in 1:length(emi.keys.0)){
 # for (h in 1:1){
    # c('country', 'tot.subcat','rel.unc.min','rel.unc.max')
    ens.df <- lapply(g1, function(x){data.frame(x)})
    ens.df[[h]]$tot.subcat.interval.1 <- ifelse(ens.df[[h]]$tot.subcat>(ens.df[[h]]$tot.subcat*ens.df[[h]]$rel.unc.min), 
                                          ens.df[[h]]$tot.subcat-(ens.df[[h]]$tot.subcat*ens.df[[h]]$rel.unc.min), 0)
    ens.df[[h]]$tot.subcat.interval.2 <- ens.df[[h]]$tot.subcat+(ens.df[[h]]$tot.subcat*ens.df[[h]]$rel.unc.max)
    ens.df[[h]]$countryC<- countrycode(ens.df[[h]]$country, 'iso3c','country.name')
    ens.df[[h]]$countryC[which(is.na(ens.df[[h]]$countryC))] <- ens.df[[h]]$country[which(is.na(ens.df[[h]]$countryC))] #fill NA with 3 letter codes
    
    
    # sort
    sorted_ens.df <- lapply(ens.df, function(df){
      df[order(df$tot.subcat),] })
    
    sorted_ens.df <- lapply(sorted_ens.df, function(x){x[(lengths(x)[1]-50):lengths(x)[1],]})
    f.make_gvis_plot_unc(sorted_ens.df,h)
  #  f.make_gvis_plot(ens.df)
  }
   
}

  
f.make_gvis_plot<-function(df,h){
  
  emi.string <- f.get_emi_cat(emi.keys.0)
  if(!bCountryTot) {
    title.plot <-  paste0(' EDGAR emission for IPCC category ',emi.keys.0[h], ' - ',emi.string[h] )
    sCat <- "tot.subcat"
  } else {
    title.plot <-  ' EDGAR emission total by country ' 
    sCat <- 'tot.country'
  }
    P.hold <- list()
    if (bUnc){ # case of uncertainty fraction  pie charts
      sorted.country <- rev(unique(df[[h]]$country))
      sorted.country <- sorted.country[!sorted.country=='world']
      weight.unc<-loadRData(file=paste0(out.dir,'CH4_weighted_tot_unc.Rdata'))
      for (cc in sorted.country){
        
        a <- weight.unc[which(weight.unc$country==cc),]
        a$L1<-f.get_emi_cat(a$L1)
        aa <-data.frame(a$L1, a$weights.unc.tot)
       
        P.hold <- list.append(P.hold, gvisPieChart(aa, options = list(
          title=a$country[1],
          tooltip = "{text:'percentage'}",
          width = 200, height=200
        )) 
        )
      }
    }  
    kk1<-gvisMerge(gvisMerge(gvisMerge(gvisMerge(gvisMerge(
      P.hold[[1]], P.hold[[2]], horizontal=T), P.hold[[3]], horizontal=T),P.hold[[4]], horizontal=T),
      P.hold[[5]], horizontal = T),  P.hold[[6]],horizontal=T)
    kk2<-gvisMerge(gvisMerge(gvisMerge(gvisMerge(gvisMerge(
      P.hold[[7]], P.hold[[8]], horizontal=T), P.hold[[9]], horizontal=T),P.hold[[10]], horizontal=T),
      P.hold[[11]], horizontal = T),  P.hold[[12]],horizontal=T)
      
    kk <- gvisMerge(kk1,kk2,horizontal=F)
      
        
            
   # Reduce(gvisMerge, P.hold, horizontal=T)
  #  plot(kk)
    
    ss <- df[[h]][df[[h]]$country=='world',] # only the world total
    ww <- df[[h]][-which(df[[h]]$country=='world'),] # only the world total
    df[[h]] <- ww
    
    
    G <- gvisGeoChart(df[[h]], locationvar="countryC", colorvar=sCat,#"min","MAX"), 
                      hovervar = 'countryC',
                      options=list(region="world", 
                                   colorAxis="{colors:['green', 'yellow',  'red', 'purple']}",
                                   backgroundColor="white",
                                   gvis.editor='Click to edit',
                                   width=450, height=325))
    
    T <- gvisTable(df[[h]], options=list(width=450, height=575))
    
    GT <- gvisMerge(G,T, horizontal=FALSE) 
    
    #M <- gvisMotionChart(df, 'country', c("Mean"),#"min","MAX"),
    #                     option=list(width=600, height=950))
    
    M <- gvisLineChart(df[[h]], xvar='country', 
                       yvar=c(sCat, 'tot.subcat.interval.1','tot.subcat.interval.2'),
                       options=list(
                         title= title.plot,
                         series="[{color:'purple'}]",
                         lineWidth = 4,
                         
                         #         intervals="{ 'color':'series-color' }",
                         #         interval="{
                         #       'i1': { 'color': '#E49307', 'style':'line', 'barWidth':0, 'lineWidth':3, 'pointSize':5, 'fillOpacity':0.85 },
                         #       'i2': { 'color': '#E49307', 'style':'line', 'barWidth':0, 'lineWidth':3, 'pointSize':5, 'fillOpacity':0.85  },
                         #       }",
                         
                         #   legend= 'none',
                         #   legend= "{'visibleInLegend': 'true'}",
                         legend="{ position: 'top', maxLines: 1 }",
                         vAxes="[{title:'CH4 emission',
                         titleTextStyle: {color: 'blue'},
                         textStyle:{color: 'blue'},
                         textPosition: 'out'}]",
                         hAxes="[{direction:'-1',
                         slantedText:'true',
                         slantedTextAngle:'90', showTextEvery:1, maxAlternation:3}]",
                         #     legend='none',
                         width=1100, height=450
                       )
    )
    
    M1 <- gvisLineChart(ss, xvar='country',
                           yvar=c(sCat, 'tot.subcat.interval.1','tot.subcat.interval.2'),
                           options=list(
                             title= 'global CH4 emission',
                             series="[{color:'blue'}]",
                             lineWidth = 4,
                             pointSize=15,
                            width=150, height=450
                           ) )
    
    MM1 <-  gvisMerge(M,M1, horizontal=TRUE,
                      tableOptions="bgcolor=\"#CCCCCC\" cellspacing=1") 
    MK <- gvisMerge(MM1,kk, horizontal=FALSE,
                    tableOptions="bgcolor=\"#CCCCCC\" cellspacing=1") 
    
    GTM <- gvisMerge(GT,MK, horizontal=TRUE,
                     tableOptions="bgcolor=\"#CCCCCC\" ") 
    
    plot(GTM)
    # print(GMT)
    
    htmlstring <- paste(c(GTM$html$header,paste(GTM$html$chart,collapse = ""),GTM$html$caption,GTM$html$footer),collapse = "\n")
    if(bCountryTot){
      write(htmlstring, file=paste0(w.dir,  'country_total_CH4_weight.html') )
    }else{
      write(htmlstring, file=paste0(w.dir, emi.keys.0[h], '_CH4.html') )
    }
  }
}


#-------------------------------------------------
f.prepare_gvis_plot <- function(g1) {
  

    ens.df <- data.frame(g1)
    ens.df$tot.interval.1 <- ifelse(ens.df$tot.emi.country>(ens.df$tot.emi.country*ens.df$rel.unc.tot.min), 
                                           ens.df$tot.emi.country-(ens.df$tot.emi.country*ens.df$rel.unc.tot.min), 0)
    ens.df$tot.interval.2  <- ens.df$tot.emi.country+(ens.df$tot.emi.country*ens.df$rel.unc.tot.max)
    ens.df$countryC<- countrycode(ens.df$country, 'iso3c','country.name')
    ens.df$countryC[which(is.na(ens.df$countryC))] <- ens.df$country[which(is.na(ens.df$countryC))] #fill NA with 3 letter codes
    
    
    # sort
    
    sorted_ens.df <- ens.df[order(ens.df$tot.emi.country),] 
    
    sorted_ens.df <- sorted_ens.df[(lengths(sorted_ens.df)[1]-50):lengths(sorted_ens.df)[1],]
    
    s.df <-list()
    s.df[[1]] <- sorted_ens.df
    f.make_gvis_plot_unc(s.df,1)
    
   
  }
#-------------------------------------------  
f.make_gvis_plot_unc <- function(df,h){
  # this function is the same as the above but adds the weighted uncertainty piecharts
  
  emi.string <- f.get_emi_cat(emi.keys.0)
  if(!bCountryTot) {
    title.plot <-  paste0(' EDGAR emission for IPCC category ',emi.keys.0[h], ' - ',f.get_emi_cat(emi.keys.0[h]) )
    sCat <- "tot.subcat"
  } else {
    title.plot <-  ' EDGAR emission total by country ' 
    sCat <- 'tot.country'
  }
  
  
  G <- gvisGeoChart(df[[h]], locationvar="countryC", colorvar=sCat,#"min","MAX"), 
                    hovervar = 'countryC',
                    options=list(region="world", 
                                 colorAxis="{colors:['green', 'yellow',  'red', 'purple']}",
                                 backgroundColor="white",
                                 gvis.editor='Click to edit',
                                 width=450, height=300))
  
  T <- gvisTable(df[[h]], options=list(width=450, height=650))
  
  GT <- gvisMerge(G,T, horizontal=FALSE) 
  
  #M <- gvisMotionChart(df, 'country', c("Mean"),#"min","MAX"),
  #                     option=list(width=600, height=950))
  
  M <- gvisLineChart(df[[h]], xvar='country', 
                     yvar=c(sCat, 'tot.subcat.interval.1','tot.subcat.interval.2'),
                     options=list(
                       title= title.plot,
                       series="[{color:'purple'}]",
                       lineWidth = 4,
                       
                       #         intervals="{ 'color':'series-color' }",
                       #         interval="{
                       #       'i1': { 'color': '#E49307', 'style':'line', 'barWidth':0, 'lineWidth':3, 'pointSize':5, 'fillOpacity':0.85 },
                       #       'i2': { 'color': '#E49307', 'style':'line', 'barWidth':0, 'lineWidth':3, 'pointSize':5, 'fillOpacity':0.85  },
                       #       }",
                       
                       #   legend= 'none',
                       #   legend= "{'visibleInLegend': 'true'}",
                       legend="{ position: 'top', maxLines: 1 }",
                       vAxes="[{title:'CH4 emission',
                       titleTextStyle: {color: 'blue'},
                       textStyle:{color: 'blue'},
                       textPosition: 'out'}]",
                       hAxes="[{direction:'-1',
                       slantedText:'true',
                       slantedTextAngle:'90', showTextEvery:1, maxAlternation:3}]",
                       #     legend='none',
                       width=1500, height=950
                     )
  )
  
  
  GTM <- gvisMerge(GT,M, horizontal=TRUE,
                   tableOptions="bgcolor=\"#CCCCCC\" cellspacing=10") 
  
  plot(GTM)
  # print(GMT)
  
  htmlstring <- paste(c(GTM$html$header,paste(GTM$html$chart,collapse = ""),GTM$html$caption,GTM$html$footer),collapse = "\n")

 #   write(htmlstring, file=paste0(fig.dir,  'country_total_CH4_unc.html') )

    write(htmlstring, file=paste0(fig.dir, sCatAgg, sCatEmi, '_', emi.keys.0[h], '_', now_run,'.html') )
  }



