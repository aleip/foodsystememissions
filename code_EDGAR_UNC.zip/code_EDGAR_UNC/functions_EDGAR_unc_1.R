# ****************************************************************************

#' Title
#'
#' @param filename 
#'
#' @return
#' @export
#'
#' @examples
read_excel_allsheets <- function(filename) {
  
  
  sheets <- readxl::excel_sheets(filename)
  x <-    lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  names(x) <- sheets
  x
}

# =======================================================================
f.get_AD_unc <- function(proc,country) {
  
  # determine if country is annex 1 or non-annex 1
  fdev <- country.info$ind[which(country.info$ISO3 == country) ]
  
  u.AD.row <- grep(proc,u.AD$Process.Code )[1]
  
  sProc <- substring(proc, 1,3)
  # if ENE 
  if (sProc == 'ENE'){
    if(fdev=='I') {
      unc <- 0.05
    } else {
      unc <- 0.10  
    }
  } else if (sProc == 'ENF' | substring(proc, 1,3) == 'MNM') {
    unc <- 0.20
#  } else if (substring(proc, 1,3) == 'WWT') { # case of waste water treatment
    
#    unc <- f.WWT_unc(proc, country)
    
  } else { #all other cases
    if(fdev=='I' | fdev=='0'){
      unc <- u.AD$A1_countries[u.AD.row]
    }else{
      unc <- ifelse(u.AD$A2_countries[u.AD.row]>0, u.AD$A2_countries[u.AD.row],u.AD$A1_countries[u.AD.row])
      
    }
    unc <- unc/100.
    if(country  %in% other_countries$country_iso){ # in the case the country is part of the set of countries 
                                                   # for which activity data are retrieved for some aggregate statistics
                                                   # then unc is enhanced by 5%
      if(sProc == 'ENE' | sProc == 'TRO' | sProc == 'PRO' | sProc == 'RCO' |
         sProc == 'REF' | sProc == 'TNR'){
        
      unc <- unc*1.05
      }
    } 
    return(unc)
  }
  
  
 #  # if rice
 #  if (substring(proc, 1,7) == 'AGS.RIC'){
 #    # case of rice a value +-0.2 to the scaling factor is suggested. the scaling factor varies between 0 and 1, and thus the 
 #    # uncertainty between 100% and 20%. an averaged value of 50% is assumed
 # #   unc <- 0.5
 #    unc <- f.rice_activity(proc,country)
 #  }
  
  return(unc)
  
  
}
#-----------------------------------------------------------
f.get_AD_unc_rice <- function(procs,country){
  
  
  # match country and tech code (expanded country calculated in the init file)
  ## get tech
  tech       <- substring(procs, 13,15) #== levels(factor(act.in$tech.code))){
  act.in.tmp <- subset(act.in, tech.code==tech)
  
  ## is country defined in the file
  
  if (country %in% act.in.tmp$Country){
    unc <- act.in.tmp[which(country == act.in.tmp$Country), ncol(act.in.tmp)]
    unc <- ifelse(unc>0.2,0.2/unc,1) # assign 100% uncertainty for fraction between 0 and 0.2.
  } else if (country %in% unlist(countries.in.group)){
    idx.l <- grep(country , countries.in.group) # in which element of the list
    # get country group
    country.group <- as.numeric(names(countries.in.group)[idx.l])
    if (country.group %in% act.in.tmp$Country){
      unc <- act.in.tmp[which(act.in.tmp$Country == country.group), ncol(act.in.tmp)]
      unc <- ifelse(unc>0.2,0.2/unc,1)
    } else{ #case of gropu not defined in tech file
      #use AAA value
      unc <- act.in.tmp[which(act.in.tmp$Country == 'AAA'), ncol(act.in.tmp)]
      unc <- ifelse(unc>0.2,0.2/unc,1)
    }
    
  }else{
    #use AAA value
    unc <- act.in.tmp[which(act.in.tmp$Country == 'AAA'), ncol(act.in.tmp)]
    unc <- ifelse(unc>0.2,0.2/unc,1)
  }

  rm(act.in.tmp)
  return(unc)
}
#-----------------------------------------------------------
f.get_EF_unc_1 <- function(process,country){
  
  fdev     <- country.info$ind[which(country.info$ISO3 == country) ]
  u.EF.row <- grep(process,u.EF$Process.Code ) #can return several values  
  
  if (length(u.EF.row)==0) {   # case of AD not in the EF
    return(NULL) 
  }  
  
  ipcc06 <- u.EF$IPCC.2006[u.EF.row][1]
  
  #  Now assign 
  ## A1min to Annex 1 countries
  ## A2min to Annex 2 countries if available
  ## if Annex 2 not available, use A1max
  
  if(fdev=='I' | fdev=='0') { # case of developed countries ('D'), air or sea('0)
    u.EF.country.min <- u.EF$T1_A1_countries_min[u.EF.row]
    u.EF.country.max <- u.EF$T1_A1_countries_max[u.EF.row]
  } else  if (fdev=='D'){
    if (!anyNA (u.EF$T1_A2_countries_min[u.EF.row]) & 
        u.EF$T1_A2_countries_min[u.EF.row]> 0. ) {  # mmmmhh
      u.EF.country.min <-  u.EF$T1_A2_countries_min[u.EF.row]
      u.EF.country.max <-  u.EF$T1_A2_countries_max[u.EF.row]
    } else {
      u.EF.country.min <-  u.EF$T1_A1_countries_max[u.EF.row]
      u.EF.country.max <-  u.EF.country.min
    }
    
  }
  iFlag <- F # iFlag holds the specificity of the country, i.e. id the EF is definied ad-hoc for that country only
  hold.codes <- u.EF$Process.Code[u.EF.row]
  # check each line with the complete EF database
  k <-1; hold0 <- NULL
  for (pp in u.EF$Process.Code[u.EF.row]){  # pp is a four-group code 'aaa.xxx.yyy.uuu'            
    #      pp<-  u.EF$Process.Code[u.EF.row][1]

    if (process == 'AGS.RIC.ARE'){ # case of rice, all countries the same,no need to flag

      if (pp == 'AGS.RIC.ARE.UPL') {
        uEF.r.min <- 0.
        uEF.r.max <- 0.
      } else  { #cases of IRR, DWE, RNF
        uEF.r.min <- 0.43
        uEF.r.max <- 0.74
      }
      store.tmp <- c(country, ipcc06, hold.codes[k], FALSE, uEF.r.min, uEF.r.max)

      hold0     <- rbind (hold0, store.tmp)                        
      k <- k+1; store.tmp <- NULL
    
      } else { #all other cases
      # is country defined for that processes?
      hold.tmp <- grep(pp, country_by_code.EF$Process.Code)
      if (length(hold.tmp) > 1) {  # more than one country
        
        sCountry <- country_by_code.EF$Country[hold.tmp] 
        
        
        if ( any(country_by_code.EF$Country[hold.tmp] == country) ) {

          if(!is.null(u.EF$EF_unc_T2[u.EF.row]) ){
            if (!is.na(u.EF$EF_unc_T2[u.EF.row] & u.EF$EF_unc_T2[u.EF.row] >0)){

            u.EF.country.min <-  as.numeric(u.EF$EF_unc_T2[u.EF.row])
            u.EF.country.max <-  as.numeric(u.EF$EF_unc_T2[u.EF.row])
            }
           } else{
          u.EF.country.min <-  u.EF$T1_A1_countries_min[u.EF.row]
          u.EF.country.max <-  u.EF$T1_A1_countries_max[u.EF.row]
           }
          iFlag <- T
        }  # else if (country_by_code.EF$Country[hold.tmp] == c('I','D') ){  # this case is dealt with by the fdev flag
        #      if (fdev == 'I')
        #      }
      }                                                                 # min                               #max
      store.tmp <- c(country, ipcc06, hold.codes[k], as.logical(iFlag), as.numeric(u.EF.country.min[k]/100), as.numeric(u.EF.country.max[k]/100) )
      hold0     <- rbind (hold0, store.tmp)                        
      k <- k+1; store.tmp <- NULL
      
    }
  }
  
  #  hold <- list( country, u.EF.country, iFlag, hold.codes )
  ret.list <- as.list(hold0)
  
  return( hold0 )
}
#---------------------------------------------------------------------


f.comb_unc_rice <- function(u.AD.rice, proc.r) {
  
  u.EF.row <- grep(proc.r,u.EF$Process.Code )
  if (proc.r == 'AGS.RIC.ARE.UPL') {
    utot.r.min <- 0.
    utot.r.max <- 0.
    
    
  } else { # case of 'IRR','DWE+RNF'
    
    utot.r.min <- f.comb_unc (0.44, unc.AD)
    utot.r.max <- f.comb_unc (0.74, unc.AD)
  }  
  u.r <- cbind.data.frame( utot.r.min,  utot.r.max )
  return(u.r)
}
  
  

