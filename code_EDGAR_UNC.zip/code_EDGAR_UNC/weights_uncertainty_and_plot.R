## the following code deals with producing the composition of the uncertainty. 
## the code is very ugly and convoluted becasue the summary sunction does not support multiple rows
## uncertainty fraction: contribution of each sector to total uncertainty
## all this part is used in the gvis plotting

tot.emi.country <- loadRData(file=paste0(out.dir,sCatAgg,sCatEmi, '_', now_run, '_',sUncCorr, 'emi_tot_by_country.Rdata')  ) # load the file generated when bCountryTot==T
cat.emi.country <- loadRData(file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr,'emi_by_categories.Rdata') )  # 

# all this part deals with finding the relative contribution of each sectors to the overall uncertainty
g.hold <- list() 
for (t in 1:length(cat.emi.country)){
  g.tmp <- NULL
  for (c in tot.emi.country$country){
    # c<-tot.emi.country$country[10]
    
    
    idx <- which(cat.emi.country[[t]]$country==c  )
    #    browser()
    
    if (length(idx) == 0) {next()}
    idx1 <- which(tot.emi.country$country==c  )
    #   browser()
    g.tmp <- rbind(g.tmp,
                   cbind(
                     cat.emi.country[[t]][idx,], tot.emi.country[idx1,2:4],
                     ( as.numeric(cat.emi.country[[t]][idx,4])*as.numeric(cat.emi.country[[t]][idx,2])/
                         (as.numeric(tot.emi.country[idx1,4])*as.numeric(tot.emi.country[idx1,2]) ) )
                   ) 
    )
    
  }
  
  g.hold[[t]]<-g.tmp
  rm(g.tmp); gc()
}

colnames <- c('country','tot.subcat', 'rel.unc.cat.min', 'rel.unc.cat.max', 
              'tot.emi.country', 'rel.unc.tot.min', 'rel.unc.tot.max','weight.unc.max')
g.hold <- lapply(g.hold, setNames, colnames)
names(g.hold) <- emi.keys.0

## g.tmp and g.hold do not produce weights that summ up to one, because of non-linearity. need to be rescaled to unity

gg <- melt(g.hold, id.vars=colnames)
gg <- gg[order(gg$country),]

## now normalise the weight ot one 
dt <- data.table(gg)
dt <-cbind(dt, dt[,list(weights.unc.tot=weight.unc.max/sum(weight.unc.max, na.rm=T)),by=country])
dt <- data.frame(dt)
dt <- dt[,!duplicated(colnames(dt))]

# Check the sum returns one
# gg1 <- dt %>% group_by(country) %>% summarise(weight.tot.country <- sum(unc.tot, na.rm=T))

save(dt, file=paste0(out.dir,sCatAgg,sCatEmi, '_CH4_weighted_tot_unc.Rdata')) # dt contains the weights of each category to the country uncertainty


## export table
# clean some columns
# dt<- loadRData(file=paste0(out.dir,'CH4_weighted_tot_unc.Rdata'))
 dt[,c('rel.unc.cat.min', 'rel.unc.cat.max','weight.unc.max', 'country.1')] <-  list(NULL)
 
 ###************************************************************************************************
 if (bCountryTot){ # this code does the plot for the country total i.e. all categories summed up for each country
#   dt<- loadRData(file=paste0(out.dir,sCatAgg,sCatEmi, '_CH4_weighted_tot_unc.Rdata'))
   dt[,c('rel.unc.cat.min', 'rel.unc.cat.max','weight.unc.max', 'country.1')] <-  list(NULL)
dt<- dt[order(dt$tot.emi.country, decreasing=T),]
dt$ipcc <- f.get_emi_cat_vector(dt$L1)
dt$tot.subcat      <- dt$tot.subcat/1000.     # convert from kt to Tg
dt$tot.emi.country <- dt$tot.emi.country/1000.# convert from kt to Tg
write.csv(dt, file=paste0(proc.dir,sCatAgg, sCatEmi,'_',  now_run, '_', sUncCorr,'_emission_summary_table.csv'))

dt.f = dt[!duplicated(dt$country),]

q <- ggplot(data=dt.f[1:35,])+
  geom_pointrange(aes(x=reorder(country,-tot.emi.country), y=tot.emi.country, 
                      ymin=tot.emi.country-tot.emi.country*rel.unc.tot.min, 
                      ymax=tot.emi.country+tot.emi.country*rel.unc.tot.max)) + 
  ylab(' CH4 EDGAR emission (Tg)' ) +  xlab('')    +
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5)) +
  ggtitle(paste0('EDGAR CH4 emission 2012 ' )) +
  labs(color='n-sub') 


# now load world total
tot.world <- read.csv(file=paste0(proc.dir, now_run,'_tot_emission_by_country.csv'), sep=',')
tot.world <- tot.world[tot.world$country=='world',]

tot.world$tot.country <- tot.world$tot.country/1000.
tot.world$unc.emi.min <- tot.world$unc.emi.min/1000.
tot.world$unc.emi.max <- tot.world$unc.emi.max/1000.



w <- ggplot(data=tot.world)+
  geom_pointrange(aes(x=country, y=tot.country, 
                      ymin=unc.emi.min , 
                      ymax=unc.emi.max), color='blue' )+ 
                      ylim(0,600)+
                      xlab('') +theme(axis.title.y=element_blank()   )

pga <- grid.arrange(q, w, ncol = 2, nrow = 1, widths = c(8.5,1.5) )#, heights = 3)

ggsave(filename=paste0(fig.dir, now_run, sCatAgg, sCatEmi,'_total_emission_by_country.tiff'), device='tiff', width = 12, height = 7.5, units = "in",
       dpi = 200, pga)


###
 } else {
   # this code does the plots for the category total i.e. each category for each country
   
#    dt<- loadRData(file=paste0(out.dir,sCatAgg,sCatEmi, '_CH4_weighted_tot_unc.Rdata'))
   dt[,c('rel.unc.tot.min', 'rel.unc.tot.max','weight.unc.max', 'country.1')] <-  list(NULL)
   for (h in 1:length(emi.keys.0)){
     idx <- which(dt$L1==emi.keys.0[h])
     dt.f <- dt[idx,]
     
     
     
     dt.f<- dt.f[order(dt.f$tot.subcat, decreasing=TRUE),]
     q <- ggplot(data=dt.f[1:35,])+
       geom_pointrange(aes(x=reorder(country,-tot.subcat), y=tot.subcat/1000., 
                           ymin=(tot.subcat-tot.subcat*rel.unc.cat.min)/1000., 
                           ymax=(tot.subcat+tot.subcat*rel.unc.cat.max)/1000.) ) + 
       ylab(' CH4 EDGAR emission (Tg)' ) +  xlab('')    +
       theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5)) +
       ggtitle(paste0('EDGAR CH4 emission 2012 - ' , emi.keys.0[h], ': ',f.get_emi_cat(emi.keys.0[h]))) +
       labs(color='n-sub') 
     ggsave(filename=paste0(fig.dir, now_run, sCatAgg, sCatEmi,'_category_emission_',emi.keys.0[h], '.tiff'), device='tiff', width = 12, height = 7.5, units = "in",
            dpi = 200, q)
   } 
   
}





