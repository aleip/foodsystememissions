
#' Title
#'
#' @param g1.tot 
#'
#' @return
#' @export
#'
#' @examples
f.aggregate_for_CHE <- function(g1.tot){
  
  lapply(1:length(g1.tot), function(i) write.csv(g1.tot[[i]], 
                                                 file = paste0(out.dir,names(g1.tot[i]), ".csv"),
                                                 row.names = FALSE))
  
  gg2 <- melt(g1.tot, id=c('country',  'tot.subcat','rel.unc.min','rel.unc.max',
                           'asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc'))
  write.csv(gg2, file = paste0(out.dir, "CO2_aggregation_for_CHE_2.csv"),       row.names = FALSE)
  
  return(gg2)
  
}