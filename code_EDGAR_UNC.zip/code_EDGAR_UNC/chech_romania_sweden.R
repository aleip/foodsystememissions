

g1.CO2 <- loadRData(file=paste0(out.dir,'CO2\\','emi_by_category_EDGAR__CO2_UncCorr_2015_emi_by_categories.Rdata'))

unc.Table <- loadRData('D:\\work\\GhG_move\\VERIFY\\EDGAR\\proc\\CO2\\2015\\UncCorr_unc.table.Rdata')

rou.ene <- unc.Table[unc.Table$country=='ROU' & startsWith(unc.Table$processes,'ENE.'), ]
rou.ene <- na.omit(rou.ene)

swe.ene <- unc.Table[unc.Table$country=='SWE' & startsWith(unc.Table$processes,'ENE.'), ]
swe.ene <- na.omit(swe.ene)

swe.fuel <-swe.ene %>% group_by(substr(processes,9,11)) %>% summarise(n=n(), emi=sum(emi), unc=mean(unc.max)) ; swe.fuel <- data.frame(swe.fuel) 
rou.fuel <-rou.ene %>% group_by(substr(processes,9,11)) %>% summarise(n=n(), emi=sum(emi), unc=mean(unc.max)) ; rou.fuel <- data.frame(rou.fuel)

colnames(swe.fuel)=c('proc','count','emi','unc') 
colnames(rou.fuel)=c('proc','count','emi','unc') 

swe.ene[grepl('BFG',swe.ene$processes),]


# 
## merge(swe.fuel,rou.fuel, by=intersect(names(swe.fuel), names(rou.fuel)), all=T)
# 
# swe.fuel[order(swe.fuel$count, decreasing=T),]
# rou.fuel[order(rou.fuel$count, decreasing=T),]
# 
# rou.emiunc <- apply(rou.fuel, 1, function(x){a=as.numeric(x[3])*as.numeric(x[4])})
# sqrt(sum(rou.emiunc^2))/sum(rou.fuel$emi)
# 
# swe.emiunc <- apply(swe.fuel, 1, function(x){a=as.numeric(x[3])*as.numeric(x[4])})
# sqrt(sum(swe.emiunc^2))/sum(swe.fuel$emi)
