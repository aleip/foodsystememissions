

install.packages("plot3D")

library("plot3D")
install.packages("ggridges")
library(ggridges)
theme_set(theme_ridges())

ns <- 10000
mean <- c(150,250,175,110, 125, 210)
sd   <- c(20,9,11,30,5,15)

lmean <- log(mean^2 / sqrt(sd^2 + mean^2)) #https://gist.github.com/msalganik/7d8762e69b3954b3a5a2ec437f62d6e9
lsd <- sqrt(log(1 + (sd^2 / mean^2)))

#norm.mat<-mapply(function(x,y){rnorm(x,y,n=500)},x=mean,y=sd)
norm.mat <- mapply(function(x,y){rlnorm(x,y,n=ns)},x=lmean, y=lsd)
norm.mat <- data.frame(norm.mat)
colnames(norm.mat) <- paste0('emi',as.character(seq(1:ncol(norm.mat))) )

dd <- melt(norm.mat)

# do the combination

sorted.mat <- apply(norm.mat,2, sort, decreasing=F)
 mean_comb <- apply(sorted.mat, 1, median) # returns a column whose row are the mean over each row: sum(norm.mat[1,])/6
sd_comb <- (var(mean_comb))^0.5
median_comb <- median(mean_comb)
sd_var_comb <- abs(diff(range(sd)))
                    
lmean_comb   <- log(median_comb^2 / sqrt(sd_comb^2 + median_comb^2)) 
lsd_comb     <- sqrt(log(1 + (sd_comb^2 / median_comb^2)))
lsd_var_comb <-  sqrt(log(1 + (sd_var_comb^2 / median_comb^2)))

lcomb <- rlnorm(n=ns,meanlog=lmean_comb, sdlog=lsd_comb) 
lcomb_var <- rlnorm(n=ns,meanlog=lmean_comb, sdlog=lsd_var_comb) 
lcomb <- data.frame(lcomb, lcomb_var); 
lcomb$variable <- rep('comb', ns); names(lcomb) <- c('value_unc', 'value_var' ,'variable0')
lcomb <-melt(lcomb)

summary_stats <- ModifiedCox(lcomb$value)
# end combination

p <- ggplot(dd, aes(x = value, y = variable)) +
  geom_density_ridges_gradient(
    aes(fill = ..x..), scale = 3, size = 0.3
  ) + xlim(-50,300) + 
  scale_fill_gradientn(
    colours = c("#0D0887FF", "#CC4678FF"),
    name = "prob"
  )+
  labs(title = 'uncertainty vs variability') +
  xlab('uncertainty') + ylab('variability')


w <-  ggplot(data=lcomb, aes(x=value, fill=variable)) + #geom_histogram(aes(y=..density..), binwidth=2, colour="#0D0887FF", fill="#CC4678FF", alpha=0.4) +
  geom_density(alpha=.2 ) + geom_vline(xintercept=as.numeric(summary_stats), colour='black' ) + xlim(-70,280) + 
  xlab('') +theme(axis.title.y=element_blank()) #+theme(legend.position="bottom")   

# w <- ggplot(data=lcomb, aes(x=value, y=variable)) +
#   geom_density_ridges_gradient(
#     aes(fill = ..x..), scale = 3, size = 0.3
#   ) + xlim(-50,300) + 
#     + xlab('') +theme(axis.title.y=element_blank()   )+ geom_vline(xintercept=as.numeric(summary_stats), colour='black' ) #+ theme(legend.position = "none")

    

pga <- grid.arrange(p, w, ncol = 1, nrow = 2, heights = c(8.25,1.75) )#, heights = 3)


#mean_se(log(lcomb$value))
#
#w+geom_point()+stat_summary(fun.y='median', fun.ymin = min, fun.ymax = max) ,
#                                                        colour = c("red", 'black', 'green' ) )

ModifiedCox <- function(x){ #https://tonyladson.wordpress.com/2016/02/05/confidence-interval-for-the-mean-of-non-normal-data/
  n <- length(x)
  y <- log(x)
  y.m <- median(y)
  y.var <- var(y)
  
  my.t <- qt(0.975, df = n-1) # 95% Confidence interval
  
  my.mean <- median(x)
  upper <- y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  lower <- y.m + y.var/2 - my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  
  return(list(upper = exp(upper), mean = my.mean, lower = exp(lower)))
  
}

ModifiedCox_efi <- function(x){ # based on bond et al paper
  n <- length(x)
  y <- log(x)
  y.m <- mean(y)
  y.sd <- sqrt(var(y))
  
  my.t <- qt(0.975, df = n-1) # 95% Confidence interval
  
  my.mean <- mean(x)
 # upper <- y.m + (y.sd/sqrt(n-1))*my.t   #   y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
#  lower <-  y.m - (y.sd/sqrt(n-1))*my.t 
  upper <- y.m + (y.sd)*my.t   #   y.m + y.var/2 + my.t*sqrt(y.var/n + y.var^2/(2*(n - 1)))
  lower <-  y.m - (y.sd)*my.t 
  
  return(list(upper = exp(upper), mean = my.mean, lower = exp(lower)))
  
}



# 
# set.seed(123)
# draws1 <- rlnorm(n = 1000000, mean = 7, sd = 75)
# mean(draws1)
# sd(draws1)
# 
# draws2 <- rlnorm(n = 1000000, meanlog = log(7), sdlog = log(75))
# mean(draws2)
# sd(draws2)
# 
# m <- 7
# s <- 75
# location <- log(m^2 / sqrt(s^2 + m^2))
# shape <- sqrt(log(1 + (s^2 / m^2)))
# print(paste("location:", location))
# print(paste("shape:", shape))
# draws3 <- rlnorm(n = 1000000, location, shape)
# mean(draws3)
# sd(draws3)
# plot(density(draws3[draws3 < 20]))





