##sensitivity to having flagged EF for ad-hoc countreies

# reference case
rc <- loadRData(file=paste0(out.dir,'CH4_emi_by_categories.Rdata'))

# full correaltion case


fc<- loadRData(file=paste0(proc.dir,'CH4_emi_by_categories_ful_correlation.Rdata'))


#rc.sort <- lapply(rc, function(x){x[order(x$tot.subcat, decreasing = T),]})
#fc.sort <- lapply(fc, function(x){x[order(x$tot.subcat, decreasing = T),]})

# rc.sort1 <-melt(rc.sort, id=names(rc.sort[[1]])); rc.sort1$corr <- rep('ref.corr',lengths(rc.sort1)[1])
# fc.sort1 <-melt(fc.sort, id=names(rc.sort[[1]])); fc.sort1$corr <- rep('full.corr',lengths(rc.sort1)[1])


rc.sort1 <-melt(rc, id=names(rc[[1]]))#; rc$corr <- rep('ref.corr',lengths(rc)[1])
fc.sort1 <-melt(fc, id=names(rc[[1]]))#; fc$corr <- rep('full.corr',lengths(rc)[1])
rc.sort1$corr <- rep('ref.corr',lengths(rc.sort1)[1])
fc.sort1$corr <- rep('full.corr',lengths(rc.sort1)[1])

prep.plot <- merge(rc.sort1, fc.sort1, all=T) #by='corr') #c('country','L1','tot.subcat'))
names(prep.plot) <- c('country','emi.cat', 'rel.unc.min','rel.unc.max','ipcc.cat',  'corr')

prep.plot <- prep.plot[order(prep.plot$emi.cat,decreasing = T),][1:100,]
prep.plot$emi.cat <- prep.plot$emi.cat/1000. # convert to Tg
prep.plot$ipcc.cat <- f.get_emi_cat_vector(prep.plot$ipcc.cat)


q <- ggplot(data=prep.plot)+
  geom_pointrange(aes(x=country, y=emi.cat, ymin=emi.cat-emi.cat*rel.unc.min, ymax=emi.cat+emi.cat*rel.unc.max, color=factor(corr)),
                    position= position_dodge(width = 0.9), alpha=0.7) + 
  facet_grid(ipcc.cat~., scales='free' ) +
  ylab(' CH4 EDGAR emission (Tg)' ) +  xlab('')    +
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=0.5)) +
  ggtitle(paste0('CH4 emission 2012 ' )) +
  labs(color='n-sub') 
  ggsave(filename=paste0(fig.dir, 'sensitivity_2_bCountyr_flag.tiff'), device='tiff', width = 12, height = 7.5, units = "in",
         dpi = 600, q)
  
                   