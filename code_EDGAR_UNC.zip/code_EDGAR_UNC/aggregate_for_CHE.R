#' Title
#'
#' @param summary_unc 
#'
#' @return
#' @export
#' this function was written on the 23d July 2019 to replace the one below.
#' the difference is that this function does a further step in aggregating by fuel type
#' first aggregate by country, sector and fuel type, getting the uncertainty based on iFlag (typically FALSE: correlation)
#' and then aggregate by countryall fule for a given sector (flag set to TRUE: uncorrelation)
#' 
#' @examples
f.aggregate_for_CHE_fuel <- function(summary_unc){
  
  # debug
  # summary_unc <- unc.table
  
  g1 <- list()
  ## 1. aggregate by sector, for each country
  emi.keys <- paste0('^', emi.keys.0 )
  
  kempty <- NULL
  
  
  for (k in 1:length(emi.keys)){
    #  if(length(grep(emi.keys[k], unc.table$ipcc06)) >=1){
    if (b.cat == 'EDGAR'){
       if(b.cat == 'Margarita'){
    #   if (emi.keys.0[k] == 'TNR.AIR') emi.keys[k] <- paste(c('^TNR.DAT','^TNR.IAT'), collapse="|")
    #   if (emi.keys.0[k] == 'REF_TRF') emi.keys[k] <- paste(c('^REF','^TRF'), collapse="|")
    #   if (emi.keys.0[k] == 'PRU_SOL') emi.keys[k] <- paste(c('^PRU','^SOL'), collapse="|")
    #   if (emi.keys.0[k] == 'TNR.OTH') emi.keys[k] <- paste(c('^TNR.OTH','^TNR.PIP','^TNR.RAI'), collapse="|")
    # }
      #  c('ENE','MANUFACTURING','RCO','AVIATION','TRANSPORT','OTHER','SWD.INC')
      if (emi.keys.0[k] == 'AVIATION')      emi.keys[k] <- paste(c('^TNR.DAT','^TNR.IAT'), collapse="|")
      if (emi.keys.0[k] == 'MANUFACTURING') emi.keys[k] <- paste(c('^IND','^IRO','^NFE','^NEU','^NMM','^CHE'), collapse="|")
      if (emi.keys.0[k] == 'OTHER')         emi.keys[k] <- paste(c('^PRO','^AGS','^REF','^TRF','^PRU','^SOL'), collapse="|")
      if (emi.keys.0[k] == 'TRANSPORT')     emi.keys[k] <- paste(c('^TRO','^TNR.ILW','^TNR.SEA', '^TNR.OTH','^TNR.PIP','^TNR.RAI'), collapse="|")
      
    }
    
    if(dim(subset(summary_unc,  grepl(emi.keys[k], processes)))[1] ==0)  {
      kempty <- c(kempty,k)
      next()}
    
    tpm <- summary_unc %>%   group_by(country) %>%  subset(  grepl(emi.keys[k], processes)) %>% group_by(substr(processes, 9,11), add=T) %>% 
      summarise(tpm.emi  = sum(emi, na.rm=T),
                tpm.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
                tpm.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
    
    } else if (b.cat == 'b.cat.CO2'){
      if(dim(subset(summary_unc,  grepl(emi.keys[k], ipcc06)))[1] ==0)  {
        kempty <- c(kempty,k)
        next()}
      
      tpm <- summary_unc %>%   group_by(country) %>%  subset(  grepl(emi.keys[k], ipcc06)) %>% group_by(substr(processes, 9,11), add=T) %>% 
        summarise(tpm.emi  = sum(emi, na.rm=T),
                  tpm.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
                  tpm.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
    }
    
    g1[[k]] <- tpm  %>%   group_by(country) %>%  
      summarise(emi.cat.country  = sum(tpm.emi, na.rm=T),
                emi.unc.cat.country.min = f.aggregate_subcategory(tpm.emi, as.numeric(tpm.min), rep(TRUE, length(tpm.min)), rep(FALSE, length(tpm.min))),
                emi.unc.cat.country.max = f.aggregate_subcategory(tpm.emi, as.numeric(tpm.max), rep(TRUE, length(tpm.min)), rep(FALSE, length(tpm.min))))
    
    cat('emi cat = ', emi.keys.0[k], ' *** ')
    
    # ***
    # NOW calculate asymmetric lognormal or normal CI
    # 
    CI.range <-  apply(g1[[k]],1,function(x){f.asymmetric_unc(as.numeric(x[3]),as.numeric(x[4]),as.numeric(x[2]))}) #passed arguments: min, max, mean
    #***
    #  original g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1]) #CI.range[1] should be negative for asymmetric
    minCI <- CI.range[1,]
    maxCI <- CI.range[2,]
    g1[[k]]$CImin <- g1[[k]][[2]]*(1- abs(minCI))
    #  g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1])
    g1[[k]]$CImax <- g1[[k]][[2]]*(1+ maxCI)
    g1[[k]]$CIminPerc <- as.numeric(minCI)
    g1[[k]]$CImaxPerc <- as.numeric(maxCI)
    CI.range <- NULL
    
  }
  g1 <- g1[!sapply(g1, is.null)] # remove empty list elements
  #names(g1) <- emi.keys.0
  colnames <- c('country', 'tot.subcat','rel.unc.min','rel.unc.max','asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc')
  g1.tot <- lapply(g1, setNames, colnames)
  
  if( !is.null(kempty) ){
    names(g1.tot) <- emi.keys.0[-kempty] 
  } else {
    names(g1.tot) <- emi.keys.0
  }
  
  
#  lapply(1:length(g1.tot), function(i) write.csv(g1.tot[[i]], 
#                                                 file = paste0(out.dir,names(g1.tot[i]), ".csv"),
#                                                 row.names = FALSE))
  
  gg2 <- reshape2::melt(g1.tot, id=c('country',  'tot.subcat','rel.unc.min','rel.unc.max',
                           'asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc'))
  write.csv(gg2, file = paste0(out.dir, "CO2_aggregation_for_", sCatEmi,Sys.Date(),".csv"),       row.names = FALSE)
  
  return(g1.tot)
} # end function
#***********************************************************************
#' Title
#'
#' @param summary_unc 
#'
#' @return
#' @export
#'
#' @examples
f.aggregate_for_CHE <- function(summary_unc){
  
  g1 <- list()
  ## 1. aggregate by sector, for each country
  emi.keys <- paste0('^', emi.keys.0 )
  
 
  for (k in 1:length(emi.keys)){
    #  if(length(grep(emi.keys[k], unc.table$ipcc06)) >=1){
    if (emi.keys.0[k] == 'TNR.AIR') emi.keys[k] <- paste(c('^TNR.DAT','^TNR.IAT'), collapse="|")
    if (emi.keys.0[k] == 'REF_TRF') emi.keys[k] <- paste(c('^REF','^TRF'), collapse="|")
    if (emi.keys.0[k] == 'PRU_SOL') emi.keys[k] <- paste(c('^PRU','^SOL'), collapse="|")
    
    g1[[k]] <- summary_unc %>%   group_by(country) %>%  subset(  grepl(emi.keys[k], processes)) %>%  
      summarise(emi.cat.country  = sum(emi, na.rm=T),
                emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
                emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
    cat('emi cat = ', emi.keys.0[k], ' *** ')
    
    # ***
    # NOW calculate asymmetric lognormal or normal CI
    # 
    CI.range <-  apply(g1[[k]],1,function(x){f.asymmetric_unc(as.numeric(x[3]),as.numeric(x[4]),as.numeric(x[2]))}) #passed arguments: min, max, mean
    #***
    #  original g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1]) #CI.range[1] should be negative for asymmetric
    minCI <- CI.range[1,]
    maxCI <- CI.range[2,]
    g1[[k]]$CImin <- g1[[k]][[2]]*(1- abs(minCI))
    #  g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1])
    g1[[k]]$CImax <- g1[[k]][[2]]*(1+ maxCI)
    g1[[k]]$CIminPerc <- as.numeric(minCI)
    g1[[k]]$CImaxPerc <- as.numeric(maxCI)
    CI.range <- NULL
    
  }
  
  #names(g1) <- emi.keys.0
  colnames <- c('country', 'tot.subcat','rel.unc.min','rel.unc.max','asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc')
  g1.tot <- lapply(g1, setNames, colnames)
  names(g1.tot) <- emi.keys.0
  
#  lapply(1:length(g1.tot), function(i) write.csv(g1.tot[[i]], 
#                                                 file = paste0(out.dir,names(g1.tot[i]), ".csv"),
#                                                 row.names = FALSE))
  
  gg2 <- melt(g1.tot, id=c('country',  'tot.subcat','rel.unc.min','rel.unc.max',
                           'asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc'))
  write.csv(gg2, file = paste0(out.dir, "CO2_aggregation_for_CHE_2.csv"),       row.names = FALSE)
  
  return(g1.tot)
} # end function





