# PROGRAM mAIN

# modification '_v5' of the 09 Feb 2019 
# includes the split up of buifules in the unc.table before the aggregation

rm(list=ls(all=TRUE)) ; gc()# clear workspace
# check countries: 
##   a. the EF is ONLY defined for a group of countries (say AAA)
####     then get the countries in that group and retrieve the AD
##   b. the EF is defined for a groud pf countries and also for
####     some individula countries. 
####     then overwrite the EF for those latter countries. 

####    * FLAG each country: must know if default or specific emission factor used *

# 3.
# get the uncertainties and combine them. no aggregation at this time, so utot = sqrt(uad^2+uEF^2)

# 4. attach uncertainty to emission
# the uncertainty is in percentage, so need to retrieve also the emission  
source('EDGAR_init.R')
# Read in files
source('read_in_files.R')
#edgar.EF <- read_excel_allsheets(paste0(w.dir, "CH4_EF.xlsx")) # emission factors


# for a given code, get EF, AD, country, uEF, uAD
# do it by IPCC group code

# 1.
#  read first code from EF records 
#AGS.RIC.ARE (.DWE)   # 
#ENE.AEL.BDS (.GT0) # ? not found in ENE activity data

t.hold <- data.frame()
prog <- seq(1,length(AD$ad_code),500)
ric.idx <- grep('AGS.RIC',AD$ad_code)

# start looking for processes in the AD codes
for (p in 1:length(AD$ad_code) ){
#     for (p in ric.idx){

  u.AD.country.proc <- vector()
  
  bRice <- F
  proc    <- AD$ad_code[p]
  if (substring(proc, 1,7) == 'AGS.RIC') bRice <- T
  country <-  AD$Country_code_A3[p]
  # if (country == 'SEA' | country == 'AIR') next()
  
  # u.AD.country.proc <- f.get_AD_unc(proc,country) #returns the percentage uncertainty 
  if(any(p==prog)) {
    cat('process ', proc, ' for country ', country,' ; ', p, ' of ', length(AD$ad_code), '*** ',round(100*p/length(AD$ad_code),2),'%', '\n')
  }
  # get EF unc
  t.hold.tmp        <- f.get_EF_unc_1(proc,country)
  
  
  # the next line of code has been added to dela with N2O, was not necessary for methane
  if (length(t.hold.tmp)==0) {
 #   message('waning: f.get_EF_unc_1 for ', proc, ' and country  ', country)
    next()                           # can be that the code 
  }                                  # is in the activity data but not in the EF
  
  
  
  # get AD uncertainty
  ## rice is done differently as it needs to read in the tech file
#  if (bRice){
#    for (j in 1:length(t.hold.tmp[,3])){
#      u.AD.country.proc[j] <- f.get_AD_unc_rice(as.character(t.hold.tmp[j,3]),country) #returns the percentage uncertainty  
#    }
#  } else { # all other cases

    u.AD.country.proc <- f.get_AD_unc(proc,country) #returns the percentage uncertainty 
#  }
  
  
  u.EF.country.proc.min <- as.numeric(t.hold.tmp[,5])
  u.EF.country.proc.max <- as.numeric(t.hold.tmp[,6])
  
  for (i in 1:length(u.EF.country.proc.min)){
    # combine uncertainties AD*EF
    if(bRice){
      unc.tot.min   <- f.comb_unc(u.EF.country.proc.min[i], u.AD.country.proc) #[i])
      unc.tot.max   <- f.comb_unc(u.EF.country.proc.max[i], u.AD.country.proc) #[i])
      
    } else { 
      if(now_run == 'N2O'){  # modification introduced on the 7th January 2020
        
        # if (u.EF.country.proc.max[i] > 2.50) {u.EF.country.proc.max[i] <- 2.50 }  # limit max uncertainty to 250%
        # if (u.EF.country.proc.min[i] > 2.50) {u.EF.country.proc.min[i] <- 2.50 }  # limit min uncertainty to 250%                               
      }
      
      unc.tot.min   <- f.comb_unc(u.EF.country.proc.min[i], u.AD.country.proc)
      unc.tot.max   <- f.comb_unc(u.EF.country.proc.max[i], u.AD.country.proc)
    }
  
 
    t.hold.tmp[,5] <- ifelse(length(unc.tot.min)>0,unc.tot.min, NA)
    t.hold.tmp[,6] <- ifelse(length(unc.tot.max)>0,unc.tot.max, NA)
    # calculate the correction for unc.min and unc.max according to EQ 3.3 IPCC
    # from this point  forward (call to f.associate_unc2EM) the effect of the boost factor to uncertainty kicks in, 
    # thus all files needs to be written and stored with the string 'sUncCorr'
    # ***
    unc.Fact <- f.unc_fact(t.hold.tmp[1,5], t.hold.tmp[1,6])# do the call regardless of bUncCorrFact, 
                                                            # the check on the flag is done within the function
    
 #   t.hold.tmp[,7] <- unc.Fact[1]
#    t.hold.tmp[,8] <- unc.Fact[2]
    if(unc.tot.min <= unc.tot.max & unc.Fact[1] > unc.Fact[2]) message( 'cazzi per ', proc, ' and country  ', country)
    
    # now append the uncertainty with the correction factor and AD and EF uncertainties for info
    t.hold.tmp1       <- c(t.hold.tmp[i,], unc.Fact[1], unc.Fact[2], u.AD.country.proc, u.EF.country.proc.min[i],u.EF.country.proc.max[i])
    
    t.hold <- rbind.data.frame(t.hold, t.hold.tmp1, stringsAsFactors = F) #, ipcccode, country, proc3, proc4,  u.AD.country.proc, u.EF.country.proc, u.comb, iflag)
    t.hold.tmp1 <- NULL
  }
}

names(t.hold) <- c('country','ipcc06', 'process', 'cFlag','unc_tot_min','unc_tot_max',
                   'unc_tot_min_fact','unc_tot_max_fact', 'unc_AD', 'unc_EF_min', 'unc_EF_max')

# store intermediate file 
# write.csv(t.hold, file=paste0(out.dir,sUncCorr,sYear,'_out_max250.csv')) 
# save(t.hold,      file=paste0(out.dir,sUncCorr,sYear,'_full_unc_max250.Rdata'))
write.csv(t.hold, file=paste0(out.dir,sUncCorr,sYear,'_out.csv')) 
save(t.hold,      file=paste0(out.dir,sUncCorr,sYear,'_full_unc.Rdata'))


# produce the full uncertainty table for methane (also write and save)
# load(file=paste0(out.dir,sUncCorr,'full_unc.Rdata')) # debug
sDate <- format(Sys.time(), "%a_%b_%d_%Y")
if (now_run =='CH4') unc.table <- f.associate_unc2EM_CH4(t.hold, sDate) # unc are still symmetric about the mean
if (now_run =='N2O') unc.table <- f.associate_unc2EM_N2O(t.hold,sDate)  # unc are still symmetric about the mean
if (now_run =='CO2') unc.table <- f.associate_unc2EM_CO2(t.hold,sDate)  # unc are still symmetric about the mean


# for N2O: unc.table <- f.associate_unc2EM_1(t.hold)
# save(unc.table, file=paste0(proc.dir,sUncCorr,sYear,'_unc.table_max250.Rdata'))
save(unc.table, file=paste0(proc.dir,sUncCorr,sYear,'_unc.table.Rdata'))

bSens <- F
# load t.hold:
# load(file=paste0(out.dir,sUncCorr,sYear,'_full_unc.Rdata')) # debug
if (now_run == 'CH4' & bSens) {
  b1Ax <- F;       if (b1Ax)       {sSens <- '1Ax'}
  b1A  <- F;       if (b1A)        {sSens <- '1A' }
  b1A_fuel  <- T;  if (b1A_fuel)   {sSens <- '1A_fuel' }
  b1a3b <-F;       if (b1a3b)      {sSens <- 'Road'}
  bRice_sens <- F; if (bRice_sens) {sSens <- 'Rice'}
  bEnf <- F;       if (bEnf)       {sSens <- '3A1'}
  bMnm <- F;       if (bMnm)       {sSens <- '3A2'}
  b1B2 <- F;       if (b1B2)       {sSens <- 'Fugitive_Gas'}
  sDate <- format(Sys.time(), "%a_%b_%d_%Y")
  unc.table <- f.associate_unc2EM_bSens(t.hold, b1Ax, b1A, b1a3b, b1A_fuel, bRice_sens, bEnf, bMnm, b1B2, sSens)
  save(unc.table, file=paste0(proc.dir,now_run,'_unc.table_',sSens,'_',sYear, '.Rdata'))
}

bSens <- F
if (now_run == 'N2O' & bSens) {
  # load t.hold:
  # load(file=paste0(out.dir,sUncCorr,'full_unc.Rdata')) # debug
  for (flag in 2:8){
    bx <- F; b1A <- F; bAir <- F; bSea <- F; b1B2 <- F; b2B <- F; b3C4 <- F; b4D1 <- F
    if (flag==1) { bx   <- T;      sSens <- 'biofuels'}
    if (flag==2) { b1A  <- T;      sSens <- '1A' }
    if (flag==3) { bAir <- T;      sSens <- 'Air'}
    if (flag==4) { bSea <- T;      sSens <- 'Sea'}
    if (flag==5) { b2B  <- T;      sSens <- 'Chem'}
    if (flag==6) { b3C4 <- T;      sSens <- 'Direct N2O'}
    if (flag==7) { b1B2 <- T;      sSens <- 'Fugitive'}
    if (flag==8) { b4D1 <- T;      sSens <- 'Domestic Wastewater'}
    unc.table <- f.associate_unc2EM_bSens_N2O(t.hold, bx, b1A, bAir, bSea, b1B2, b2B, b3C4, b4D1,sSens)
    message('saving case ',sSens)
    save(unc.table, file=paste0(proc.dir,now_run,'_unc.table_',sSens, '.Rdata'))
  }
}


# now aggregate

## country and sector 
# unc.table <- loadRData (file=paste0(proc.dir,sUncCorr,sYear,'_unc.table.Rdata'))
# unc.table <- loadRData(file=paste0(proc.dir,now_run,'_unc.table_',sSens, '.Rdata'))
#*************************************************

unc.table$xFlag <- ifelse(grepl('x',unc.table$ipccX),TRUE,FALSE) # Add a column of flags indicating 
                                                                 # the use of biofuels  

# detach(package:plyr)
# if(now_run=='CO2' &  ( b.cat=='Margarita' | b.cat == 'EDGAR')) {
if(now_run=='CO2') {
  g1.tot <- f.aggregate_for_CHE_fuel(unc.table) #write to file
#  f.aggregate_for_CHE(g1.tot) 
  
}else{ # all other cases
  
#  g1.tot <- f.country_aggregation(unc.table) # good option if only need to get to country total, 
  
  g1 <- list()
  ## 1. aggregate by sector, for each country
  emi.keys <- paste0('^', emi.keys.0 )
  
  for (k in 1:length(emi.keys)){
#   if(length(grep(emi.keys[k], unc.table$processes)) >=1){
    if(length(grep(emi.keys[k], unc.table$ipcc06)) >=1){
#      g1[[k]] <- unc.table %>%   group_by(country) %>%  subset(grepl(emi.keys[k], processes)) %>%  
#      g1[[k]] <- unc.table %>%   group_by(country) %>%   subset(grepl(emi.keys[k], processes) & xFlag==F) %>%  # no biofuels
      g1[[k]] <- unc.table %>%   group_by(country) %>%  subset(  grepl(emi.keys[k], ipcc06) & xFlag==F) %>%  
        summarise(emi.cat.country  = sum(emi, na.rm=T),
                  emi.unc.cat.country.min = f.aggregate_subcategory(emi, as.numeric(unc.min), as.logical(iFlag), as.logical(xFlag)),
                  emi.unc.cat.country.max = f.aggregate_subcategory(emi, as.numeric(unc.max), as.logical(iFlag), as.logical(xFlag)))
      cat('emi cat = ', emi.keys.0[k])
      
      # ***
      # NOW calculate asymmetric lognormal or normal CI
      # 
      CI.range <-  apply(g1[[k]],1,function(x){f.asymmetric_unc(as.numeric(x[3]),as.numeric(x[4]),as.numeric(x[2]))}) #passed arguments: min, max, mean
      #***
      #  original g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1]) #CI.range[1] should be negative for asymmetric
      minCI <- CI.range[1,]
      maxCI <- CI.range[2,]
      g1[[k]]$CImin <- g1[[k]][[2]]*(1- abs(minCI))
      #  g1[[k]]$CImin <- g1[[k]][[2]]*(1+ CI.range[1])
      g1[[k]]$CImax <- g1[[k]][[2]]*(1+ maxCI)
      g1[[k]]$CIminPerc <- as.numeric(minCI)
      g1[[k]]$CImaxPerc <- as.numeric(maxCI)
      CI.range <- NULL
      
      
    } else {
      g1[[k]] <- rep(NA,8) # 8 is the number of columns set with colnames 
    }   #end if
  } 
  #names(g1) <- emi.keys.0
  colnames <- c('country', 'tot.subcat','rel.unc.min','rel.unc.max','asym.unc.min','asym.unc.max','asym.min.perc','asym.max.perc')
  g1.tot <- lapply(g1, setNames, colnames)
  names(g1.tot) <- emi.keys.0
  # ***
} # end check on bMargarita
# g.tot at this point contains all info for plotting
if(bSens){
  save(g1.tot, file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr,'_', sYear, '_', sSens,'.Rdata')) 
} else {
  save(g1.tot, file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr, '_', sYear,'emi_by_categories.Rdata')) 
  
}

g1.tot.w <- melt(g1.tot, id.vars=c('country','tot.subcat','asym.unc.min','asym.unc.max'))
write.csv(g1.tot.w, file=paste0(out.dir,sCatAgg, sCatEmi, '_', now_run, '_', sUncCorr, '_', sYear,'emi_by_EDGAR_processes.csv'))
# **
# plotting and saving (also calculates the world total)
if (bPlot) f.plot_cat(g1.tot, TRUE)



#************************************************************
## 2. aggregate all sectors and give the total for each country
## unc is supposed to be uncorrelated when aggregating different sectors
# if(bCountryTot){
  # g2    <- melt(g1.tot, id.vars=c('country', 'tot.subcat','rel.unc.min','rel.unc.max')) 

#
# do you want to aggregate the categories most relevant, or all of them to get the total from all sources?
# 
if (sCatEmi != 'total_cat_') {g1.tot <- f.country_aggregation(unc.table);  sCatEmi <- 'total_cat_'} # sAgg0 <- sAgg[1]} # all categories to calculating the aggregated country total
# or just skeep the previous line and use g1.tot from specific sectors

# total of all sectors
  g2 <- do.call('rbind', g1.tot)
  # g2 <- g1.tot$AGS # do the aggregation for one sector only
  g2.tot <- g2 %>% group_by(country) %>% summarise(emi.tot.country = sum(tot.subcat, na.rm=T),
                                                  emi.unc.country.min = f.aggregate_subcategory.tot(tot.subcat, rel.unc.min, TRUE), # TRUE = uncorrelated
                                                  emi.unc.country.max = f.aggregate_subcategory.tot(tot.subcat, rel.unc.max, TRUE) )
                                                 # emi.weight.country <- f.weight_unc(rel.unc.max, 
                                                  #                                   f.aggregate_subcategory(emi.tot.country, as.numeric(rel.unc.max),  TRUE)) ))
  
  CI.range <-  apply(g2.tot,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
  minCI <- CI.range[1,]
  maxCI <- CI.range[2,]
  g2.tot$CImin <- g2.tot$emi.tot.country*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
  g2.tot$CImax <- g2.tot$emi.tot.country*(1+ maxCI)
#  g1[[k]]$CIminPerc <- as.numeric(CI.range[1])
#  g1[[k]]$CImaxPerc <- as.numeric(CI.range[2])
  names(g2.tot) <- c('country', 'tot.country', 'rel.unc.min','rel.unc.max','asym.unc.min', 'asym.unc.max')
  save(g2.tot, file=paste0(out.dir,sCatEmi, '_', now_run, '_',sUncCorr,sYear, '_emi_tot_by_country.Rdata') )
#  save(g2.tot, file=paste0(out.dir,sCatEmi, '_', now_run, '_',sUncCorr,sYear, '_emi_tot_by_country_no_biofuels.Rdata') )
#  g.tot<-lapply(g.tot, setNames, colnames) 

  
if (bPlot) f.plot_country(g2.tot) # f.gvis_plot(g2.tot)

#*******************************************************
## 3. aggregate all countries to give the global emission

emi.glob <- g2.tot %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                             emi.unc.tot.min = f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # FALSE = correlated
                             emi.unc.tot.max = f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
emi.glob <- as.data.frame(append(emi.glob, 'World', after=0))
CI.range <-  apply(emi.glob,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
minCI <- CI.range[1,]; maxCI <- CI.range[2,]
emi.glob$CImin <- emi.glob$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
emi.glob$CImax <- emi.glob$emi.tot*(1+ maxCI)

# add to g.tot for plotting
names(emi.glob) <- names(g2.tot)
g.tot <- merge (emi.glob,as.data.frame(g2.tot),all=T)
# if (bPlot) f.gvis_plot(g.tot)

EU28 <- g2.tot[g2.tot$country%in% EU28.cc,]
emi.EU28 <- EU28 %>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                 emi.unc.tot.min = f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # FALSE = correlated
                                 emi.unc.tot.max = f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
emi.EU28 <- as.data.frame(append(emi.EU28, 'EU28', after=0))
CI.range <-  apply(emi.EU28,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
minCI <- CI.range[1,] ; maxCI <- CI.range[2,]
emi.EU28$CImin <- emi.EU28$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
emi.EU28$CImax <- emi.EU28$emi.tot*(1+ maxCI)

# add to g.tot for plotting
names(emi.EU28) <- names(g2.tot)
g.tot <- merge (g.tot,as.data.frame(emi.EU28),all=T)


# Save the final table
g.tot$unc.emi.min <- ifelse(g.tot$tot.country>(g.tot$tot.country*g.tot$rel.unc.min), 
                            g.tot$tot.country-(g.tot$tot.country*g.tot$rel.unc.min),0)
g.tot$unc.emi.max <- g.tot$tot.country+(g.tot$tot.country*g.tot$rel.unc.max)

# write.csv(g.tot, file=paste0(proc.dir, now_run,'_tot_emission_by_country_full_correlation.csv')) # when bCountry[i] <- F in function 'f.aggregate_subcategory'
write.csv(g.tot, file=paste0(out.dir, now_run,'_emission_by_country_', sYear,'_',Sys.Date(),'.csv'))




# calc for Gabril's paper
g2.tot<- loadRData(file='E:\\D_extra\\work\\GhG_move\\VERIFY\\EDGAR\\out\\CO2\\2015\\EDGAR__CO2_UncCorr_2015_emi_tot_by_country.Rdata')
annex <- read.csv(file='E:\\D_extra\\work\\GhG_move\\VERIFY\\EDGAR\\data\\Annex_classification.csv')

a <- merge(g2.tot,annex ,by='country', all=T)
na1 <- a %>% filter(Classification=='Annex_I')%>% summarise(emi.tot = sum(tot.country, na.rm=T),
                                                                emi.unc.tot.min = f.aggregate_subcategory.tot(tot.country, rel.unc.min, FALSE), # FALSE = correlated
                                                                emi.unc.tot.max = f.aggregate_subcategory.tot(tot.country, rel.unc.max, FALSE) )
emi.glob <- as.data.frame(append(emi.glob, 'World', after=0))
CI.range <-  apply(emi.glob,1,function(x){f.asymmetric_unc(x[3],x[4],x[2])})
minCI <- CI.range[1,]; maxCI <- CI.range[2,]
emi.glob$CImin <- emi.glob$emi.tot*(1- abs(minCI)) #CI.range[1] should be negative for asymmetric distribution
emi.glob$CImax <- emi.glob$emi.tot*(1+ maxCI)


